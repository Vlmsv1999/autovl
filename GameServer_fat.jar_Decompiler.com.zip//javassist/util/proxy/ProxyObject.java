package javassist.util.proxy;

public interface ProxyObject {
   void setHandler(MethodHandler var1);

   MethodHandler getHandler();
}
