package javassist.tools.rmi;

public interface Proxy {
   int _getObjectId();
}
