package antlr.collections.impl;

class LLCell {
   Object data;
   LLCell next;

   public LLCell(Object var1) {
      this.data = var1;
   }
}
