package antlr.collections;

public interface ASTEnumeration {
   boolean hasMoreNodes();

   AST nextNode();
}
