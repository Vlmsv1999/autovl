package antlr.debug;

public class ParserAdapter implements ParserListener {
   public void doneParsing(TraceEvent var1) {
   }

   public void enterRule(TraceEvent var1) {
   }

   public void exitRule(TraceEvent var1) {
   }

   public void parserConsume(ParserTokenEvent var1) {
   }

   public void parserLA(ParserTokenEvent var1) {
   }

   public void parserMatch(ParserMatchEvent var1) {
   }

   public void parserMatchNot(ParserMatchEvent var1) {
   }

   public void parserMismatch(ParserMatchEvent var1) {
   }

   public void parserMismatchNot(ParserMatchEvent var1) {
   }

   public void refresh() {
   }

   public void reportError(MessageEvent var1) {
   }

   public void reportWarning(MessageEvent var1) {
   }

   public void semanticPredicateEvaluated(SemanticPredicateEvent var1) {
   }

   public void syntacticPredicateFailed(SyntacticPredicateEvent var1) {
   }

   public void syntacticPredicateStarted(SyntacticPredicateEvent var1) {
   }

   public void syntacticPredicateSucceeded(SyntacticPredicateEvent var1) {
   }
}
