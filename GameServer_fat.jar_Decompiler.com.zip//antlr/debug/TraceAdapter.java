package antlr.debug;

public class TraceAdapter implements TraceListener {
   public void doneParsing(TraceEvent var1) {
   }

   public void enterRule(TraceEvent var1) {
   }

   public void exitRule(TraceEvent var1) {
   }

   public void refresh() {
   }
}
