package antlr.debug;

public class ParserTokenAdapter implements ParserTokenListener {
   public void doneParsing(TraceEvent var1) {
   }

   public void parserConsume(ParserTokenEvent var1) {
   }

   public void parserLA(ParserTokenEvent var1) {
   }

   public void refresh() {
   }
}
