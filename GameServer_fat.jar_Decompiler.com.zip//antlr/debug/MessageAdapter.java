package antlr.debug;

public class MessageAdapter implements MessageListener {
   public void doneParsing(TraceEvent var1) {
   }

   public void refresh() {
   }

   public void reportError(MessageEvent var1) {
   }

   public void reportWarning(MessageEvent var1) {
   }
}
