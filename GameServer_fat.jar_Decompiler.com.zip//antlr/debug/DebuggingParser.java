package antlr.debug;

public interface DebuggingParser {
   String getRuleName(int var1);

   String getSemPredName(int var1);
}
