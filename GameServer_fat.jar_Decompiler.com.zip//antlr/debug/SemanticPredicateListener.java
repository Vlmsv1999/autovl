package antlr.debug;

public interface SemanticPredicateListener extends ListenerBase {
   void semanticPredicateEvaluated(SemanticPredicateEvent var1);
}
