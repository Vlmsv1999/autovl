package antlr.debug;

public class ParserMatchAdapter implements ParserMatchListener {
   public void doneParsing(TraceEvent var1) {
   }

   public void parserMatch(ParserMatchEvent var1) {
   }

   public void parserMatchNot(ParserMatchEvent var1) {
   }

   public void parserMismatch(ParserMatchEvent var1) {
   }

   public void parserMismatchNot(ParserMatchEvent var1) {
   }

   public void refresh() {
   }
}
