package antlr.debug;

public class SyntacticPredicateAdapter implements SyntacticPredicateListener {
   public void doneParsing(TraceEvent var1) {
   }

   public void refresh() {
   }

   public void syntacticPredicateFailed(SyntacticPredicateEvent var1) {
   }

   public void syntacticPredicateStarted(SyntacticPredicateEvent var1) {
   }

   public void syntacticPredicateSucceeded(SyntacticPredicateEvent var1) {
   }
}
