package antlr;

public class CharStreamException extends ANTLRException {
   public CharStreamException(String var1) {
      super(var1);
   }
}
