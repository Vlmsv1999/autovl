package antlr;

import java.io.IOException;

class FileCopyException extends IOException {
   public FileCopyException(String var1) {
      super(var1);
   }
}
