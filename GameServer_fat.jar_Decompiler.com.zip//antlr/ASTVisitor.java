package antlr;

import antlr.collections.AST;

public interface ASTVisitor {
   void visit(AST var1);
}
