package antlr;

public class TreeParserSharedInputState {
   public int guessing = 0;
}
