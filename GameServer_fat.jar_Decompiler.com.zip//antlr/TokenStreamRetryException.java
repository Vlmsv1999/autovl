package antlr;

public class TokenStreamRetryException extends TokenStreamException {
}
