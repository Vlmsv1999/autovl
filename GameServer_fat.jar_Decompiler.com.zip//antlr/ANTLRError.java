package antlr;

public class ANTLRError extends Error {
   public ANTLRError() {
   }

   public ANTLRError(String var1) {
      super(var1);
   }
}
