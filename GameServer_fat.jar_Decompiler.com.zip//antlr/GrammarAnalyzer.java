package antlr;

public interface GrammarAnalyzer {
   int NONDETERMINISTIC = Integer.MAX_VALUE;
   int LOOKAHEAD_DEPTH_INIT = -1;
}
