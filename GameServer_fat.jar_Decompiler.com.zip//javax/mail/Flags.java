package javax.mail;

import java.io.Serializable;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

public class Flags implements Cloneable, Serializable {
   private int system_flags = 0;
   private Hashtable user_flags = null;
   private static final int ANSWERED_BIT = 1;
   private static final int DELETED_BIT = 2;
   private static final int DRAFT_BIT = 4;
   private static final int FLAGGED_BIT = 8;
   private static final int RECENT_BIT = 16;
   private static final int SEEN_BIT = 32;
   private static final int USER_BIT = Integer.MIN_VALUE;
   private static final long serialVersionUID = 6243590407214169028L;

   public Flags() {
   }

   public Flags(Flags var1) {
      this.system_flags = var1.system_flags;
      if (var1.user_flags != null) {
         this.user_flags = (Hashtable)var1.user_flags.clone();
      }

   }

   public Flags(Flags.Flag var1) {
      this.system_flags |= var1.bit;
   }

   public Flags(String var1) {
      this.user_flags = new Hashtable(1);
      this.user_flags.put(var1.toLowerCase(), var1);
   }

   public void add(Flags.Flag var1) {
      this.system_flags |= var1.bit;
   }

   public void add(String var1) {
      if (this.user_flags == null) {
         this.user_flags = new Hashtable(1);
      }

      this.user_flags.put(var1.toLowerCase(), var1);
   }

   public void add(Flags var1) {
      this.system_flags |= var1.system_flags;
      if (var1.user_flags != null) {
         if (this.user_flags == null) {
            this.user_flags = new Hashtable(1);
         }

         Enumeration var2 = var1.user_flags.keys();

         while(var2.hasMoreElements()) {
            String var3 = (String)var2.nextElement();
            this.user_flags.put(var3, var1.user_flags.get(var3));
         }
      }

   }

   public void remove(Flags.Flag var1) {
      this.system_flags &= ~var1.bit;
   }

   public void remove(String var1) {
      if (this.user_flags != null) {
         this.user_flags.remove(var1.toLowerCase());
      }

   }

   public void remove(Flags var1) {
      this.system_flags &= ~var1.system_flags;
      if (var1.user_flags != null) {
         if (this.user_flags == null) {
            return;
         }

         Enumeration var2 = var1.user_flags.keys();

         while(var2.hasMoreElements()) {
            this.user_flags.remove(var2.nextElement());
         }
      }

   }

   public boolean contains(Flags.Flag var1) {
      return (this.system_flags & var1.bit) != 0;
   }

   public boolean contains(String var1) {
      return this.user_flags == null ? false : this.user_flags.containsKey(var1.toLowerCase());
   }

   public boolean contains(Flags var1) {
      if ((var1.system_flags & this.system_flags) != var1.system_flags) {
         return false;
      } else {
         if (var1.user_flags != null) {
            if (this.user_flags == null) {
               return false;
            }

            Enumeration var2 = var1.user_flags.keys();

            while(var2.hasMoreElements()) {
               if (!this.user_flags.containsKey(var2.nextElement())) {
                  return false;
               }
            }
         }

         return true;
      }
   }

   public boolean equals(Object var1) {
      if (!(var1 instanceof Flags)) {
         return false;
      } else {
         Flags var2 = (Flags)var1;
         if (var2.system_flags != this.system_flags) {
            return false;
         } else if (var2.user_flags == null && this.user_flags == null) {
            return true;
         } else if (var2.user_flags != null && this.user_flags != null && var2.user_flags.size() == this.user_flags.size()) {
            Enumeration var3 = var2.user_flags.keys();

            while(var3.hasMoreElements()) {
               if (!this.user_flags.containsKey(var3.nextElement())) {
                  return false;
               }
            }

            return true;
         } else {
            return false;
         }
      }
   }

   public int hashCode() {
      int var1 = this.system_flags;
      if (this.user_flags != null) {
         for(Enumeration var2 = this.user_flags.keys(); var2.hasMoreElements(); var1 += ((String)var2.nextElement()).hashCode()) {
         }
      }

      return var1;
   }

   public Flags.Flag[] getSystemFlags() {
      Vector var1 = new Vector();
      if ((this.system_flags & 1) != 0) {
         var1.addElement(Flags.Flag.ANSWERED);
      }

      if ((this.system_flags & 2) != 0) {
         var1.addElement(Flags.Flag.DELETED);
      }

      if ((this.system_flags & 4) != 0) {
         var1.addElement(Flags.Flag.DRAFT);
      }

      if ((this.system_flags & 8) != 0) {
         var1.addElement(Flags.Flag.FLAGGED);
      }

      if ((this.system_flags & 16) != 0) {
         var1.addElement(Flags.Flag.RECENT);
      }

      if ((this.system_flags & 32) != 0) {
         var1.addElement(Flags.Flag.SEEN);
      }

      if ((this.system_flags & Integer.MIN_VALUE) != 0) {
         var1.addElement(Flags.Flag.USER);
      }

      Flags.Flag[] var2 = new Flags.Flag[var1.size()];
      var1.copyInto(var2);
      return var2;
   }

   public String[] getUserFlags() {
      Vector var1 = new Vector();
      if (this.user_flags != null) {
         Enumeration var2 = this.user_flags.elements();

         while(var2.hasMoreElements()) {
            var1.addElement(var2.nextElement());
         }
      }

      String[] var3 = new String[var1.size()];
      var1.copyInto(var3);
      return var3;
   }

   public Object clone() {
      return new Flags(this);
   }

   public static final class Flag {
      public static final Flags.Flag ANSWERED = new Flags.Flag(1);
      public static final Flags.Flag DELETED = new Flags.Flag(2);
      public static final Flags.Flag DRAFT = new Flags.Flag(4);
      public static final Flags.Flag FLAGGED = new Flags.Flag(8);
      public static final Flags.Flag RECENT = new Flags.Flag(16);
      public static final Flags.Flag SEEN = new Flags.Flag(32);
      public static final Flags.Flag USER = new Flags.Flag(Integer.MIN_VALUE);
      private int bit;

      private Flag(int var1) {
         this.bit = var1;
      }
   }
}
