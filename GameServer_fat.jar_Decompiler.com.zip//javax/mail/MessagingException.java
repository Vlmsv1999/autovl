package javax.mail;

public class MessagingException extends Exception {
   private Exception next;
   private static final long serialVersionUID = -7569192289819959253L;

   public MessagingException() {
      this.initCause((Throwable)null);
   }

   public MessagingException(String var1) {
      super(var1);
      this.initCause((Throwable)null);
   }

   public MessagingException(String var1, Exception var2) {
      super(var1);
      this.next = var2;
      this.initCause((Throwable)null);
   }

   public synchronized Exception getNextException() {
      return this.next;
   }

   public synchronized Throwable getCause() {
      return this.next;
   }

   public synchronized boolean setNextException(Exception var1) {
      Object var2;
      for(var2 = this; var2 instanceof MessagingException && ((MessagingException)var2).next != null; var2 = ((MessagingException)var2).next) {
      }

      if (var2 instanceof MessagingException) {
         ((MessagingException)var2).next = var1;
         return true;
      } else {
         return false;
      }
   }

   public synchronized String toString() {
      String var1 = super.toString();
      Exception var2 = this.next;
      if (var2 == null) {
         return var1;
      } else {
         StringBuffer var3 = new StringBuffer(var1 == null ? "" : var1);

         while(var2 != null) {
            var3.append(";\n  nested exception is:\n\t");
            var3.append(var2.toString());
            if (var2 instanceof MessagingException) {
               MessagingException var4 = (MessagingException)var2;
               var2 = var4.next;
            } else {
               var2 = null;
            }
         }

         return var3.toString();
      }
   }
}
