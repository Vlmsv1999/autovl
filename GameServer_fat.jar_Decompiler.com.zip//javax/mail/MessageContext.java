package javax.mail;

public class MessageContext {
   private Part part;

   public MessageContext(Part var1) {
      this.part = var1;
   }

   public Part getPart() {
      return this.part;
   }

   public Message getMessage() {
      try {
         return getMessage(this.part);
      } catch (MessagingException var2) {
         return null;
      }
   }

   private static Message getMessage(Part var0) throws MessagingException {
      while(var0 != null) {
         if (var0 instanceof Message) {
            return (Message)var0;
         }

         BodyPart var1 = (BodyPart)var0;
         Multipart var2 = var1.getParent();
         if (var2 == null) {
            return null;
         }

         var0 = var2.getParent();
      }

      return null;
   }

   public Session getSession() {
      Message var1 = this.getMessage();
      return var1 != null ? var1.session : null;
   }
}
