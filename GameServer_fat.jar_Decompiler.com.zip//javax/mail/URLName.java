package javax.mail;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.BitSet;

public class URLName {
   protected String fullURL;
   private String protocol;
   private String username;
   private String password;
   private String host;
   private InetAddress hostAddress;
   private boolean hostAddressKnown;
   private int port;
   private String file;
   private String ref;
   private int hashCode;
   private static boolean doEncode = true;
   static BitSet dontNeedEncoding;
   static final int caseDiff = 32;

   public URLName(String var1, String var2, int var3, String var4, String var5, String var6) {
      this.hostAddressKnown = false;
      this.port = -1;
      this.hashCode = 0;
      this.protocol = var1;
      this.host = var2;
      this.port = var3;
      int var7;
      if (var4 != null && (var7 = var4.indexOf(35)) != -1) {
         this.file = var4.substring(0, var7);
         this.ref = var4.substring(var7 + 1);
      } else {
         this.file = var4;
         this.ref = null;
      }

      this.username = doEncode ? encode(var5) : var5;
      this.password = doEncode ? encode(var6) : var6;
   }

   public URLName(URL var1) {
      this(var1.toString());
   }

   public URLName(String var1) {
      this.hostAddressKnown = false;
      this.port = -1;
      this.hashCode = 0;
      this.parseString(var1);
   }

   public String toString() {
      if (this.fullURL == null) {
         StringBuffer var1 = new StringBuffer();
         if (this.protocol != null) {
            var1.append(this.protocol);
            var1.append(":");
         }

         if (this.username != null || this.host != null) {
            var1.append("//");
            if (this.username != null) {
               var1.append(this.username);
               if (this.password != null) {
                  var1.append(":");
                  var1.append(this.password);
               }

               var1.append("@");
            }

            if (this.host != null) {
               var1.append(this.host);
            }

            if (this.port != -1) {
               var1.append(":");
               var1.append(Integer.toString(this.port));
            }

            if (this.file != null) {
               var1.append("/");
            }
         }

         if (this.file != null) {
            var1.append(this.file);
         }

         if (this.ref != null) {
            var1.append("#");
            var1.append(this.ref);
         }

         this.fullURL = var1.toString();
      }

      return this.fullURL;
   }

   protected void parseString(String var1) {
      this.protocol = this.file = this.ref = this.host = this.username = this.password = null;
      this.port = -1;
      int var2 = var1.length();
      int var3 = var1.indexOf(58);
      if (var3 != -1) {
         this.protocol = var1.substring(0, var3);
      }

      if (var1.regionMatches(var3 + 1, "//", 0, 2)) {
         String var4 = null;
         int var5 = var1.indexOf(47, var3 + 3);
         if (var5 != -1) {
            var4 = var1.substring(var3 + 3, var5);
            if (var5 + 1 < var2) {
               this.file = var1.substring(var5 + 1);
            } else {
               this.file = "";
            }
         } else {
            var4 = var1.substring(var3 + 3);
         }

         int var6 = var4.indexOf(64);
         if (var6 != -1) {
            String var7 = var4.substring(0, var6);
            var4 = var4.substring(var6 + 1);
            int var8 = var7.indexOf(58);
            if (var8 != -1) {
               this.username = var7.substring(0, var8);
               this.password = var7.substring(var8 + 1);
            } else {
               this.username = var7;
            }
         }

         int var12;
         if (var4.length() > 0 && var4.charAt(0) == '[') {
            var12 = var4.indexOf(58, var4.indexOf(93));
         } else {
            var12 = var4.indexOf(58);
         }

         if (var12 != -1) {
            String var13 = var4.substring(var12 + 1);
            if (var13.length() > 0) {
               try {
                  this.port = Integer.parseInt(var13);
               } catch (NumberFormatException var10) {
                  this.port = -1;
               }
            }

            this.host = var4.substring(0, var12);
         } else {
            this.host = var4;
         }
      } else if (var3 + 1 < var2) {
         this.file = var1.substring(var3 + 1);
      }

      int var11;
      if (this.file != null && (var11 = this.file.indexOf(35)) != -1) {
         this.ref = this.file.substring(var11 + 1);
         this.file = this.file.substring(0, var11);
      }

   }

   public int getPort() {
      return this.port;
   }

   public String getProtocol() {
      return this.protocol;
   }

   public String getFile() {
      return this.file;
   }

   public String getRef() {
      return this.ref;
   }

   public String getHost() {
      return this.host;
   }

   public String getUsername() {
      return doEncode ? decode(this.username) : this.username;
   }

   public String getPassword() {
      return doEncode ? decode(this.password) : this.password;
   }

   public URL getURL() throws MalformedURLException {
      return new URL(this.getProtocol(), this.getHost(), this.getPort(), this.getFile());
   }

   public boolean equals(Object var1) {
      if (!(var1 instanceof URLName)) {
         return false;
      } else {
         URLName var2 = (URLName)var1;
         if (var2.protocol != null && var2.protocol.equals(this.protocol)) {
            InetAddress var3 = this.getHostAddress();
            InetAddress var4 = var2.getHostAddress();
            if (var3 != null && var4 != null) {
               if (!var3.equals(var4)) {
                  return false;
               }
            } else if (this.host != null && var2.host != null) {
               if (!this.host.equalsIgnoreCase(var2.host)) {
                  return false;
               }
            } else if (this.host != var2.host) {
               return false;
            }

            if (this.username == var2.username || this.username != null && this.username.equals(var2.username)) {
               String var5 = this.file == null ? "" : this.file;
               String var6 = var2.file == null ? "" : var2.file;
               if (!var5.equals(var6)) {
                  return false;
               } else {
                  return this.port == var2.port;
               }
            } else {
               return false;
            }
         } else {
            return false;
         }
      }
   }

   public int hashCode() {
      if (this.hashCode != 0) {
         return this.hashCode;
      } else {
         if (this.protocol != null) {
            this.hashCode += this.protocol.hashCode();
         }

         InetAddress var1 = this.getHostAddress();
         if (var1 != null) {
            this.hashCode += var1.hashCode();
         } else if (this.host != null) {
            this.hashCode += this.host.toLowerCase().hashCode();
         }

         if (this.username != null) {
            this.hashCode += this.username.hashCode();
         }

         if (this.file != null) {
            this.hashCode += this.file.hashCode();
         }

         this.hashCode += this.port;
         return this.hashCode;
      }
   }

   private synchronized InetAddress getHostAddress() {
      if (this.hostAddressKnown) {
         return this.hostAddress;
      } else if (this.host == null) {
         return null;
      } else {
         try {
            this.hostAddress = InetAddress.getByName(this.host);
         } catch (UnknownHostException var2) {
            this.hostAddress = null;
         }

         this.hostAddressKnown = true;
         return this.hostAddress;
      }
   }

   static String encode(String var0) {
      if (var0 == null) {
         return null;
      } else {
         for(int var1 = 0; var1 < var0.length(); ++var1) {
            char var2 = var0.charAt(var1);
            if (var2 == ' ' || !dontNeedEncoding.get(var2)) {
               return _encode(var0);
            }
         }

         return var0;
      }
   }

   private static String _encode(String var0) {
      byte var1 = 10;
      StringBuffer var2 = new StringBuffer(var0.length());
      ByteArrayOutputStream var3 = new ByteArrayOutputStream(var1);
      OutputStreamWriter var4 = new OutputStreamWriter(var3);

      for(int var5 = 0; var5 < var0.length(); ++var5) {
         char var6 = var0.charAt(var5);
         if (dontNeedEncoding.get(var6)) {
            if (var6 == ' ') {
               var6 = '+';
            }

            var2.append((char)var6);
         } else {
            try {
               var4.write(var6);
               var4.flush();
            } catch (IOException var10) {
               var3.reset();
               continue;
            }

            byte[] var7 = var3.toByteArray();

            for(int var8 = 0; var8 < var7.length; ++var8) {
               var2.append('%');
               char var9 = Character.forDigit(var7[var8] >> 4 & 15, 16);
               if (Character.isLetter(var9)) {
                  var9 = (char)(var9 - 32);
               }

               var2.append(var9);
               var9 = Character.forDigit(var7[var8] & 15, 16);
               if (Character.isLetter(var9)) {
                  var9 = (char)(var9 - 32);
               }

               var2.append(var9);
            }

            var3.reset();
         }
      }

      return var2.toString();
   }

   static String decode(String var0) {
      if (var0 == null) {
         return null;
      } else if (indexOfAny(var0, "+%") == -1) {
         return var0;
      } else {
         StringBuffer var1 = new StringBuffer();

         for(int var2 = 0; var2 < var0.length(); ++var2) {
            char var3 = var0.charAt(var2);
            switch(var3) {
            case '%':
               try {
                  var1.append((char)Integer.parseInt(var0.substring(var2 + 1, var2 + 3), 16));
               } catch (NumberFormatException var6) {
                  throw new IllegalArgumentException();
               }

               var2 += 2;
               break;
            case '+':
               var1.append(' ');
               break;
            default:
               var1.append(var3);
            }
         }

         String var7 = var1.toString();

         try {
            byte[] var4 = var7.getBytes("8859_1");
            var7 = new String(var4);
         } catch (UnsupportedEncodingException var5) {
         }

         return var7;
      }
   }

   private static int indexOfAny(String var0, String var1) {
      return indexOfAny(var0, var1, 0);
   }

   private static int indexOfAny(String var0, String var1, int var2) {
      try {
         int var3 = var0.length();

         for(int var4 = var2; var4 < var3; ++var4) {
            if (var1.indexOf(var0.charAt(var4)) >= 0) {
               return var4;
            }
         }

         return -1;
      } catch (StringIndexOutOfBoundsException var5) {
         return -1;
      }
   }

   static {
      try {
         doEncode = !Boolean.getBoolean("mail.URLName.dontencode");
      } catch (Exception var1) {
      }

      dontNeedEncoding = new BitSet(256);

      int var0;
      for(var0 = 97; var0 <= 122; ++var0) {
         dontNeedEncoding.set(var0);
      }

      for(var0 = 65; var0 <= 90; ++var0) {
         dontNeedEncoding.set(var0);
      }

      for(var0 = 48; var0 <= 57; ++var0) {
         dontNeedEncoding.set(var0);
      }

      dontNeedEncoding.set(32);
      dontNeedEncoding.set(45);
      dontNeedEncoding.set(95);
      dontNeedEncoding.set(46);
      dontNeedEncoding.set(42);
   }
}
