package javax.mail;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Vector;

public abstract class Multipart {
   protected Vector parts = new Vector();
   protected String contentType = "multipart/mixed";
   protected Part parent;

   protected Multipart() {
   }

   protected void setMultipartDataSource(MultipartDataSource var1) throws MessagingException {
      this.contentType = var1.getContentType();
      int var2 = var1.getCount();

      for(int var3 = 0; var3 < var2; ++var3) {
         this.addBodyPart(var1.getBodyPart(var3));
      }

   }

   public String getContentType() {
      return this.contentType;
   }

   public int getCount() throws MessagingException {
      return this.parts == null ? 0 : this.parts.size();
   }

   public BodyPart getBodyPart(int var1) throws MessagingException {
      if (this.parts == null) {
         throw new IndexOutOfBoundsException("No such BodyPart");
      } else {
         return (BodyPart)this.parts.elementAt(var1);
      }
   }

   public boolean removeBodyPart(BodyPart var1) throws MessagingException {
      if (this.parts == null) {
         throw new MessagingException("No such body part");
      } else {
         boolean var2 = this.parts.removeElement(var1);
         var1.setParent((Multipart)null);
         return var2;
      }
   }

   public void removeBodyPart(int var1) throws MessagingException {
      if (this.parts == null) {
         throw new IndexOutOfBoundsException("No such BodyPart");
      } else {
         BodyPart var2 = (BodyPart)this.parts.elementAt(var1);
         this.parts.removeElementAt(var1);
         var2.setParent((Multipart)null);
      }
   }

   public synchronized void addBodyPart(BodyPart var1) throws MessagingException {
      if (this.parts == null) {
         this.parts = new Vector();
      }

      this.parts.addElement(var1);
      var1.setParent(this);
   }

   public synchronized void addBodyPart(BodyPart var1, int var2) throws MessagingException {
      if (this.parts == null) {
         this.parts = new Vector();
      }

      this.parts.insertElementAt(var1, var2);
      var1.setParent(this);
   }

   public abstract void writeTo(OutputStream var1) throws IOException, MessagingException;

   public Part getParent() {
      return this.parent;
   }

   public void setParent(Part var1) {
      this.parent = var1;
   }
}
