package javax.mail.util;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import javax.mail.internet.SharedInputStream;

public class SharedFileInputStream extends BufferedInputStream implements SharedInputStream {
   private static int defaultBufferSize = 2048;
   protected RandomAccessFile in;
   protected int bufsize;
   protected long bufpos;
   protected long start;
   protected long datalen;
   private boolean master;
   private SharedFileInputStream.SharedFile sf;

   private void ensureOpen() throws IOException {
      if (this.in == null) {
         throw new IOException("Stream closed");
      }
   }

   public SharedFileInputStream(File var1) throws IOException {
      this(var1, defaultBufferSize);
   }

   public SharedFileInputStream(String var1) throws IOException {
      this(var1, defaultBufferSize);
   }

   public SharedFileInputStream(File var1, int var2) throws IOException {
      super((InputStream)null);
      this.start = 0L;
      this.master = true;
      if (var2 <= 0) {
         throw new IllegalArgumentException("Buffer size <= 0");
      } else {
         this.init(new SharedFileInputStream.SharedFile(var1), var2);
      }
   }

   public SharedFileInputStream(String var1, int var2) throws IOException {
      super((InputStream)null);
      this.start = 0L;
      this.master = true;
      if (var2 <= 0) {
         throw new IllegalArgumentException("Buffer size <= 0");
      } else {
         this.init(new SharedFileInputStream.SharedFile(var1), var2);
      }
   }

   private void init(SharedFileInputStream.SharedFile var1, int var2) throws IOException {
      this.sf = var1;
      this.in = var1.open();
      this.start = 0L;
      this.datalen = this.in.length();
      this.bufsize = var2;
      this.buf = new byte[var2];
   }

   private SharedFileInputStream(SharedFileInputStream.SharedFile var1, long var2, long var4, int var6) {
      super((InputStream)null);
      this.start = 0L;
      this.master = true;
      this.master = false;
      this.sf = var1;
      this.in = var1.open();
      this.start = var2;
      this.bufpos = var2;
      this.datalen = var4;
      this.bufsize = var6;
      this.buf = new byte[var6];
   }

   private void fill() throws IOException {
      int var1;
      if (this.markpos < 0) {
         this.pos = 0;
         this.bufpos += (long)this.count;
      } else if (this.pos >= this.buf.length) {
         if (this.markpos > 0) {
            var1 = this.pos - this.markpos;
            System.arraycopy(this.buf, this.markpos, this.buf, 0, var1);
            this.pos = var1;
            this.bufpos += (long)this.markpos;
            this.markpos = 0;
         } else if (this.buf.length >= this.marklimit) {
            this.markpos = -1;
            this.pos = 0;
            this.bufpos += (long)this.count;
         } else {
            var1 = this.pos * 2;
            if (var1 > this.marklimit) {
               var1 = this.marklimit;
            }

            byte[] var2 = new byte[var1];
            System.arraycopy(this.buf, 0, var2, 0, this.pos);
            this.buf = var2;
         }
      }

      this.count = this.pos;
      this.in.seek(this.bufpos + (long)this.pos);
      var1 = this.buf.length - this.pos;
      if (this.bufpos - this.start + (long)this.pos + (long)var1 > this.datalen) {
         var1 = (int)(this.datalen - (this.bufpos - this.start + (long)this.pos));
      }

      int var3 = this.in.read(this.buf, this.pos, var1);
      if (var3 > 0) {
         this.count = var3 + this.pos;
      }

   }

   public synchronized int read() throws IOException {
      this.ensureOpen();
      if (this.pos >= this.count) {
         this.fill();
         if (this.pos >= this.count) {
            return -1;
         }
      }

      return this.buf[this.pos++] & 255;
   }

   private int read1(byte[] var1, int var2, int var3) throws IOException {
      int var4 = this.count - this.pos;
      if (var4 <= 0) {
         this.fill();
         var4 = this.count - this.pos;
         if (var4 <= 0) {
            return -1;
         }
      }

      int var5 = var4 < var3 ? var4 : var3;
      System.arraycopy(this.buf, this.pos, var1, var2, var5);
      this.pos += var5;
      return var5;
   }

   public synchronized int read(byte[] var1, int var2, int var3) throws IOException {
      this.ensureOpen();
      if ((var2 | var3 | var2 + var3 | var1.length - (var2 + var3)) < 0) {
         throw new IndexOutOfBoundsException();
      } else if (var3 == 0) {
         return 0;
      } else {
         int var4 = this.read1(var1, var2, var3);
         if (var4 <= 0) {
            return var4;
         } else {
            while(var4 < var3) {
               int var5 = this.read1(var1, var2 + var4, var3 - var4);
               if (var5 <= 0) {
                  break;
               }

               var4 += var5;
            }

            return var4;
         }
      }
   }

   public synchronized long skip(long var1) throws IOException {
      this.ensureOpen();
      if (var1 <= 0L) {
         return 0L;
      } else {
         long var3 = (long)(this.count - this.pos);
         if (var3 <= 0L) {
            this.fill();
            var3 = (long)(this.count - this.pos);
            if (var3 <= 0L) {
               return 0L;
            }
         }

         long var5 = var3 < var1 ? var3 : var1;
         this.pos = (int)((long)this.pos + var5);
         return var5;
      }
   }

   public synchronized int available() throws IOException {
      this.ensureOpen();
      return this.count - this.pos + this.in_available();
   }

   private int in_available() throws IOException {
      return (int)(this.start + this.datalen - (this.bufpos + (long)this.count));
   }

   public synchronized void mark(int var1) {
      this.marklimit = var1;
      this.markpos = this.pos;
   }

   public synchronized void reset() throws IOException {
      this.ensureOpen();
      if (this.markpos < 0) {
         throw new IOException("Resetting to invalid mark");
      } else {
         this.pos = this.markpos;
      }
   }

   public boolean markSupported() {
      return true;
   }

   public void close() throws IOException {
      if (this.in != null) {
         try {
            if (this.master) {
               this.sf.forceClose();
            } else {
               this.sf.close();
            }
         } finally {
            this.sf = null;
            this.in = null;
            this.buf = null;
         }

      }
   }

   public long getPosition() {
      if (this.in == null) {
         throw new RuntimeException("Stream closed");
      } else {
         return this.bufpos + (long)this.pos - this.start;
      }
   }

   public InputStream newStream(long var1, long var3) {
      if (this.in == null) {
         throw new RuntimeException("Stream closed");
      } else if (var1 < 0L) {
         throw new IllegalArgumentException("start < 0");
      } else {
         if (var3 == -1L) {
            var3 = this.datalen;
         }

         return new SharedFileInputStream(this.sf, this.start + (long)((int)var1), (long)((int)(var3 - var1)), this.bufsize);
      }
   }

   protected void finalize() throws Throwable {
      super.finalize();
      this.close();
   }

   class SharedFile {
      private int cnt;
      private RandomAccessFile in;

      SharedFile(String var2) throws IOException {
         this.in = new RandomAccessFile(var2, "r");
      }

      SharedFile(File var2) throws IOException {
         this.in = new RandomAccessFile(var2, "r");
      }

      public RandomAccessFile open() {
         ++this.cnt;
         return this.in;
      }

      public synchronized void close() throws IOException {
         if (this.cnt > 0 && --this.cnt <= 0) {
            this.in.close();
         }

      }

      public synchronized void forceClose() throws IOException {
         if (this.cnt > 0) {
            this.cnt = 0;
            this.in.close();
         } else {
            try {
               this.in.close();
            } catch (IOException var2) {
            }
         }

      }

      protected void finalize() throws Throwable {
         super.finalize();
         this.in.close();
      }
   }
}
