package javax.mail.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import javax.activation.DataSource;
import javax.mail.internet.ContentType;
import javax.mail.internet.MimeUtility;
import javax.mail.internet.ParseException;

public class ByteArrayDataSource implements DataSource {
   private byte[] data;
   private String type;
   private String name = "";

   public ByteArrayDataSource(InputStream var1, String var2) throws IOException {
      ByteArrayOutputStream var3 = new ByteArrayOutputStream();
      byte[] var4 = new byte[8192];

      int var5;
      while((var5 = var1.read(var4)) > 0) {
         var3.write(var4, 0, var5);
      }

      this.data = var3.toByteArray();
      this.type = var2;
   }

   public ByteArrayDataSource(byte[] var1, String var2) {
      this.data = var1;
      this.type = var2;
   }

   public ByteArrayDataSource(String var1, String var2) throws IOException {
      String var3 = null;

      try {
         ContentType var4 = new ContentType(var2);
         var3 = var4.getParameter("charset");
      } catch (ParseException var5) {
      }

      if (var3 == null) {
         var3 = MimeUtility.getDefaultJavaCharset();
      }

      this.data = var1.getBytes(var3);
      this.type = var2;
   }

   public InputStream getInputStream() throws IOException {
      if (this.data == null) {
         throw new IOException("no data");
      } else {
         return new ByteArrayInputStream(this.data);
      }
   }

   public OutputStream getOutputStream() throws IOException {
      throw new IOException("cannot do this");
   }

   public String getContentType() {
      return this.type;
   }

   public String getName() {
      return this.name;
   }

   public void setName(String var1) {
      this.name = var1;
   }
}
