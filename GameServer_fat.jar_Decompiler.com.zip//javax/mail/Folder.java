package javax.mail;

import java.util.Vector;
import javax.mail.event.ConnectionEvent;
import javax.mail.event.ConnectionListener;
import javax.mail.event.FolderEvent;
import javax.mail.event.FolderListener;
import javax.mail.event.MailEvent;
import javax.mail.event.MessageChangedEvent;
import javax.mail.event.MessageChangedListener;
import javax.mail.event.MessageCountEvent;
import javax.mail.event.MessageCountListener;
import javax.mail.search.SearchTerm;

public abstract class Folder {
   protected Store store;
   protected int mode = -1;
   public static final int HOLDS_MESSAGES = 1;
   public static final int HOLDS_FOLDERS = 2;
   public static final int READ_ONLY = 1;
   public static final int READ_WRITE = 2;
   private volatile Vector connectionListeners = null;
   private volatile Vector folderListeners = null;
   private volatile Vector messageCountListeners = null;
   private volatile Vector messageChangedListeners = null;
   private EventQueue q;
   private Object qLock = new Object();

   protected Folder(Store var1) {
      this.store = var1;
   }

   public abstract String getName();

   public abstract String getFullName();

   public URLName getURLName() throws MessagingException {
      URLName var1 = this.getStore().getURLName();
      String var2 = this.getFullName();
      StringBuffer var3 = new StringBuffer();
      char var4 = this.getSeparator();
      if (var2 != null) {
         var3.append(var2);
      }

      return new URLName(var1.getProtocol(), var1.getHost(), var1.getPort(), var3.toString(), var1.getUsername(), (String)null);
   }

   public Store getStore() {
      return this.store;
   }

   public abstract Folder getParent() throws MessagingException;

   public abstract boolean exists() throws MessagingException;

   public abstract Folder[] list(String var1) throws MessagingException;

   public Folder[] listSubscribed(String var1) throws MessagingException {
      return this.list(var1);
   }

   public Folder[] list() throws MessagingException {
      return this.list("%");
   }

   public Folder[] listSubscribed() throws MessagingException {
      return this.listSubscribed("%");
   }

   public abstract char getSeparator() throws MessagingException;

   public abstract int getType() throws MessagingException;

   public abstract boolean create(int var1) throws MessagingException;

   public boolean isSubscribed() {
      return true;
   }

   public void setSubscribed(boolean var1) throws MessagingException {
      throw new MethodNotSupportedException();
   }

   public abstract boolean hasNewMessages() throws MessagingException;

   public abstract Folder getFolder(String var1) throws MessagingException;

   public abstract boolean delete(boolean var1) throws MessagingException;

   public abstract boolean renameTo(Folder var1) throws MessagingException;

   public abstract void open(int var1) throws MessagingException;

   public abstract void close(boolean var1) throws MessagingException;

   public abstract boolean isOpen();

   public int getMode() {
      if (!this.isOpen()) {
         throw new IllegalStateException("Folder not open");
      } else {
         return this.mode;
      }
   }

   public abstract Flags getPermanentFlags();

   public abstract int getMessageCount() throws MessagingException;

   public synchronized int getNewMessageCount() throws MessagingException {
      if (!this.isOpen()) {
         return -1;
      } else {
         int var1 = 0;
         int var2 = this.getMessageCount();

         for(int var3 = 1; var3 <= var2; ++var3) {
            try {
               if (this.getMessage(var3).isSet(Flags.Flag.RECENT)) {
                  ++var1;
               }
            } catch (MessageRemovedException var5) {
            }
         }

         return var1;
      }
   }

   public synchronized int getUnreadMessageCount() throws MessagingException {
      if (!this.isOpen()) {
         return -1;
      } else {
         int var1 = 0;
         int var2 = this.getMessageCount();

         for(int var3 = 1; var3 <= var2; ++var3) {
            try {
               if (!this.getMessage(var3).isSet(Flags.Flag.SEEN)) {
                  ++var1;
               }
            } catch (MessageRemovedException var5) {
            }
         }

         return var1;
      }
   }

   public synchronized int getDeletedMessageCount() throws MessagingException {
      if (!this.isOpen()) {
         return -1;
      } else {
         int var1 = 0;
         int var2 = this.getMessageCount();

         for(int var3 = 1; var3 <= var2; ++var3) {
            try {
               if (this.getMessage(var3).isSet(Flags.Flag.DELETED)) {
                  ++var1;
               }
            } catch (MessageRemovedException var5) {
            }
         }

         return var1;
      }
   }

   public abstract Message getMessage(int var1) throws MessagingException;

   public synchronized Message[] getMessages(int var1, int var2) throws MessagingException {
      Message[] var3 = new Message[var2 - var1 + 1];

      for(int var4 = var1; var4 <= var2; ++var4) {
         var3[var4 - var1] = this.getMessage(var4);
      }

      return var3;
   }

   public synchronized Message[] getMessages(int[] var1) throws MessagingException {
      int var2 = var1.length;
      Message[] var3 = new Message[var2];

      for(int var4 = 0; var4 < var2; ++var4) {
         var3[var4] = this.getMessage(var1[var4]);
      }

      return var3;
   }

   public synchronized Message[] getMessages() throws MessagingException {
      if (!this.isOpen()) {
         throw new IllegalStateException("Folder not open");
      } else {
         int var1 = this.getMessageCount();
         Message[] var2 = new Message[var1];

         for(int var3 = 1; var3 <= var1; ++var3) {
            var2[var3 - 1] = this.getMessage(var3);
         }

         return var2;
      }
   }

   public abstract void appendMessages(Message[] var1) throws MessagingException;

   public void fetch(Message[] var1, FetchProfile var2) throws MessagingException {
   }

   public synchronized void setFlags(Message[] var1, Flags var2, boolean var3) throws MessagingException {
      for(int var4 = 0; var4 < var1.length; ++var4) {
         try {
            var1[var4].setFlags(var2, var3);
         } catch (MessageRemovedException var6) {
         }
      }

   }

   public synchronized void setFlags(int var1, int var2, Flags var3, boolean var4) throws MessagingException {
      for(int var5 = var1; var5 <= var2; ++var5) {
         try {
            Message var6 = this.getMessage(var5);
            var6.setFlags(var3, var4);
         } catch (MessageRemovedException var7) {
         }
      }

   }

   public synchronized void setFlags(int[] var1, Flags var2, boolean var3) throws MessagingException {
      for(int var4 = 0; var4 < var1.length; ++var4) {
         try {
            Message var5 = this.getMessage(var1[var4]);
            var5.setFlags(var2, var3);
         } catch (MessageRemovedException var6) {
         }
      }

   }

   public void copyMessages(Message[] var1, Folder var2) throws MessagingException {
      if (!var2.exists()) {
         throw new FolderNotFoundException(var2.getFullName() + " does not exist", var2);
      } else {
         var2.appendMessages(var1);
      }
   }

   public abstract Message[] expunge() throws MessagingException;

   public Message[] search(SearchTerm var1) throws MessagingException {
      return this.search(var1, this.getMessages());
   }

   public Message[] search(SearchTerm var1, Message[] var2) throws MessagingException {
      Vector var3 = new Vector();

      for(int var4 = 0; var4 < var2.length; ++var4) {
         try {
            if (var2[var4].match(var1)) {
               var3.addElement(var2[var4]);
            }
         } catch (MessageRemovedException var6) {
         }
      }

      Message[] var5 = new Message[var3.size()];
      var3.copyInto(var5);
      return var5;
   }

   public synchronized void addConnectionListener(ConnectionListener var1) {
      if (this.connectionListeners == null) {
         this.connectionListeners = new Vector();
      }

      this.connectionListeners.addElement(var1);
   }

   public synchronized void removeConnectionListener(ConnectionListener var1) {
      if (this.connectionListeners != null) {
         this.connectionListeners.removeElement(var1);
      }

   }

   protected void notifyConnectionListeners(int var1) {
      if (this.connectionListeners != null) {
         ConnectionEvent var2 = new ConnectionEvent(this, var1);
         this.queueEvent(var2, this.connectionListeners);
      }

      if (var1 == 3) {
         this.terminateQueue();
      }

   }

   public synchronized void addFolderListener(FolderListener var1) {
      if (this.folderListeners == null) {
         this.folderListeners = new Vector();
      }

      this.folderListeners.addElement(var1);
   }

   public synchronized void removeFolderListener(FolderListener var1) {
      if (this.folderListeners != null) {
         this.folderListeners.removeElement(var1);
      }

   }

   protected void notifyFolderListeners(int var1) {
      if (this.folderListeners != null) {
         FolderEvent var2 = new FolderEvent(this, this, var1);
         this.queueEvent(var2, this.folderListeners);
      }

      this.store.notifyFolderListeners(var1, this);
   }

   protected void notifyFolderRenamedListeners(Folder var1) {
      if (this.folderListeners != null) {
         FolderEvent var2 = new FolderEvent(this, this, var1, 3);
         this.queueEvent(var2, this.folderListeners);
      }

      this.store.notifyFolderRenamedListeners(this, var1);
   }

   public synchronized void addMessageCountListener(MessageCountListener var1) {
      if (this.messageCountListeners == null) {
         this.messageCountListeners = new Vector();
      }

      this.messageCountListeners.addElement(var1);
   }

   public synchronized void removeMessageCountListener(MessageCountListener var1) {
      if (this.messageCountListeners != null) {
         this.messageCountListeners.removeElement(var1);
      }

   }

   protected void notifyMessageAddedListeners(Message[] var1) {
      if (this.messageCountListeners != null) {
         MessageCountEvent var2 = new MessageCountEvent(this, 1, false, var1);
         this.queueEvent(var2, this.messageCountListeners);
      }
   }

   protected void notifyMessageRemovedListeners(boolean var1, Message[] var2) {
      if (this.messageCountListeners != null) {
         MessageCountEvent var3 = new MessageCountEvent(this, 2, var1, var2);
         this.queueEvent(var3, this.messageCountListeners);
      }
   }

   public synchronized void addMessageChangedListener(MessageChangedListener var1) {
      if (this.messageChangedListeners == null) {
         this.messageChangedListeners = new Vector();
      }

      this.messageChangedListeners.addElement(var1);
   }

   public synchronized void removeMessageChangedListener(MessageChangedListener var1) {
      if (this.messageChangedListeners != null) {
         this.messageChangedListeners.removeElement(var1);
      }

   }

   protected void notifyMessageChangedListeners(int var1, Message var2) {
      if (this.messageChangedListeners != null) {
         MessageChangedEvent var3 = new MessageChangedEvent(this, var1, var2);
         this.queueEvent(var3, this.messageChangedListeners);
      }
   }

   private void queueEvent(MailEvent var1, Vector var2) {
      Object var3 = this.qLock;
      synchronized(var3) {
         if (this.q == null) {
            this.q = new EventQueue();
         }
      }

      Vector var4 = (Vector)var2.clone();
      this.q.enqueue(var1, var4);
   }

   private void terminateQueue() {
      Object var1 = this.qLock;
      synchronized(var1) {
         if (this.q != null) {
            Vector var2 = new Vector();
            var2.setSize(1);
            this.q.enqueue(new Folder.TerminatorEvent(), var2);
            this.q = null;
         }

      }
   }

   protected void finalize() throws Throwable {
      super.finalize();
      this.terminateQueue();
   }

   public String toString() {
      String var1 = this.getFullName();
      return var1 != null ? var1 : super.toString();
   }

   static class TerminatorEvent extends MailEvent {
      private static final long serialVersionUID = 3765761925441296565L;

      TerminatorEvent() {
         super(new Object());
      }

      public void dispatch(Object var1) {
         Thread.currentThread().interrupt();
      }
   }
}
