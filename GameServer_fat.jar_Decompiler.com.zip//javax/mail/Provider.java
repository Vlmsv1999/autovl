package javax.mail;

public class Provider {
   private Provider.Type type;
   private String protocol;
   private String className;
   private String vendor;
   private String version;

   public Provider(Provider.Type var1, String var2, String var3, String var4, String var5) {
      this.type = var1;
      this.protocol = var2;
      this.className = var3;
      this.vendor = var4;
      this.version = var5;
   }

   public Provider.Type getType() {
      return this.type;
   }

   public String getProtocol() {
      return this.protocol;
   }

   public String getClassName() {
      return this.className;
   }

   public String getVendor() {
      return this.vendor;
   }

   public String getVersion() {
      return this.version;
   }

   public String toString() {
      String var1 = "javax.mail.Provider[" + this.type + "," + this.protocol + "," + this.className;
      if (this.vendor != null) {
         var1 = var1 + "," + this.vendor;
      }

      if (this.version != null) {
         var1 = var1 + "," + this.version;
      }

      var1 = var1 + "]";
      return var1;
   }

   public static class Type {
      public static final Provider.Type STORE = new Provider.Type("STORE");
      public static final Provider.Type TRANSPORT = new Provider.Type("TRANSPORT");
      private String type;

      private Type(String var1) {
         this.type = var1;
      }

      public String toString() {
         return this.type;
      }
   }
}
