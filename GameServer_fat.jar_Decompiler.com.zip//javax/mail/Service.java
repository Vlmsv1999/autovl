package javax.mail;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Vector;
import javax.mail.event.ConnectionEvent;
import javax.mail.event.ConnectionListener;
import javax.mail.event.MailEvent;

public abstract class Service {
   protected Session session;
   protected URLName url = null;
   protected boolean debug = false;
   private boolean connected = false;
   private Vector connectionListeners = null;
   private EventQueue q;
   private Object qLock = new Object();

   protected Service(Session var1, URLName var2) {
      this.session = var1;
      this.url = var2;
      this.debug = var1.getDebug();
   }

   public void connect() throws MessagingException {
      this.connect((String)null, (String)null, (String)null);
   }

   public void connect(String var1, String var2, String var3) throws MessagingException {
      this.connect(var1, -1, var2, var3);
   }

   public void connect(String var1, String var2) throws MessagingException {
      this.connect((String)null, var1, var2);
   }

   public void connect(String var1, int var2, String var3, String var4) throws MessagingException {
      if (this.isConnected()) {
         throw new IllegalStateException("already connected");
      } else {
         boolean var6 = false;
         boolean var7 = false;
         String var8 = null;
         String var9 = null;
         if (this.url != null) {
            var8 = this.url.getProtocol();
            if (var1 == null) {
               var1 = this.url.getHost();
            }

            if (var2 == -1) {
               var2 = this.url.getPort();
            }

            if (var3 == null) {
               var3 = this.url.getUsername();
               if (var4 == null) {
                  var4 = this.url.getPassword();
               }
            } else if (var4 == null && var3.equals(this.url.getUsername())) {
               var4 = this.url.getPassword();
            }

            var9 = this.url.getFile();
         }

         if (var8 != null) {
            if (var1 == null) {
               var1 = this.session.getProperty("mail." + var8 + ".host");
            }

            if (var3 == null) {
               var3 = this.session.getProperty("mail." + var8 + ".user");
            }
         }

         if (var1 == null) {
            var1 = this.session.getProperty("mail.host");
         }

         if (var3 == null) {
            var3 = this.session.getProperty("mail.user");
         }

         if (var3 == null) {
            try {
               var3 = System.getProperty("user.name");
            } catch (SecurityException var15) {
               if (this.debug) {
                  var15.printStackTrace(this.session.getDebugOut());
               }
            }
         }

         PasswordAuthentication var5;
         if (var4 == null && this.url != null) {
            this.setURLName(new URLName(var8, var1, var2, var9, var3, var4));
            var5 = this.session.getPasswordAuthentication(this.getURLName());
            if (var5 != null) {
               if (var3 == null) {
                  var3 = var5.getUserName();
                  var4 = var5.getPassword();
               } else if (var3.equals(var5.getUserName())) {
                  var4 = var5.getPassword();
               }
            } else {
               var7 = true;
            }
         }

         AuthenticationFailedException var10 = null;

         try {
            var6 = this.protocolConnect(var1, var2, var3, var4);
         } catch (AuthenticationFailedException var14) {
            var10 = var14;
         }

         if (!var6) {
            InetAddress var11;
            try {
               var11 = InetAddress.getByName(var1);
            } catch (UnknownHostException var13) {
               var11 = null;
            }

            var5 = this.session.requestPasswordAuthentication(var11, var2, var8, (String)null, var3);
            if (var5 != null) {
               var3 = var5.getUserName();
               var4 = var5.getPassword();
               var6 = this.protocolConnect(var1, var2, var3, var4);
            }
         }

         if (!var6) {
            if (var10 != null) {
               throw var10;
            } else {
               throw new AuthenticationFailedException();
            }
         } else {
            this.setURLName(new URLName(var8, var1, var2, var9, var3, var4));
            if (var7) {
               this.session.setPasswordAuthentication(this.getURLName(), new PasswordAuthentication(var3, var4));
            }

            this.setConnected(true);
            this.notifyConnectionListeners(1);
         }
      }
   }

   protected boolean protocolConnect(String var1, int var2, String var3, String var4) throws MessagingException {
      return false;
   }

   public boolean isConnected() {
      return this.connected;
   }

   protected void setConnected(boolean var1) {
      this.connected = var1;
   }

   public synchronized void close() throws MessagingException {
      this.setConnected(false);
      this.notifyConnectionListeners(3);
   }

   public URLName getURLName() {
      return this.url == null || this.url.getPassword() == null && this.url.getFile() == null ? this.url : new URLName(this.url.getProtocol(), this.url.getHost(), this.url.getPort(), (String)null, this.url.getUsername(), (String)null);
   }

   protected void setURLName(URLName var1) {
      this.url = var1;
   }

   public synchronized void addConnectionListener(ConnectionListener var1) {
      if (this.connectionListeners == null) {
         this.connectionListeners = new Vector();
      }

      this.connectionListeners.addElement(var1);
   }

   public synchronized void removeConnectionListener(ConnectionListener var1) {
      if (this.connectionListeners != null) {
         this.connectionListeners.removeElement(var1);
      }

   }

   protected synchronized void notifyConnectionListeners(int var1) {
      if (this.connectionListeners != null) {
         ConnectionEvent var2 = new ConnectionEvent(this, var1);
         this.queueEvent(var2, this.connectionListeners);
      }

      if (var1 == 3) {
         this.terminateQueue();
      }

   }

   public String toString() {
      URLName var1 = this.getURLName();
      return var1 != null ? var1.toString() : super.toString();
   }

   protected void queueEvent(MailEvent var1, Vector var2) {
      Object var3 = this.qLock;
      synchronized(var3) {
         if (this.q == null) {
            this.q = new EventQueue();
         }
      }

      Vector var4 = (Vector)var2.clone();
      this.q.enqueue(var1, var4);
   }

   private void terminateQueue() {
      Object var1 = this.qLock;
      synchronized(var1) {
         if (this.q != null) {
            Vector var2 = new Vector();
            var2.setSize(1);
            this.q.enqueue(new Service.TerminatorEvent(), var2);
            this.q = null;
         }

      }
   }

   protected void finalize() throws Throwable {
      super.finalize();
      this.terminateQueue();
   }

   static class TerminatorEvent extends MailEvent {
      private static final long serialVersionUID = 5542172141759168416L;

      TerminatorEvent() {
         super(new Object());
      }

      public void dispatch(Object var1) {
         Thread.currentThread().interrupt();
      }
   }
}
