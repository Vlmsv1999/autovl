package javax.mail;

public class Quota {
   public String quotaRoot;
   public Quota.Resource[] resources;

   public Quota(String var1) {
      this.quotaRoot = var1;
   }

   public void setResourceLimit(String var1, long var2) {
      if (this.resources == null) {
         this.resources = new Quota.Resource[1];
         this.resources[0] = new Quota.Resource(var1, 0L, var2);
      } else {
         for(int var4 = 0; var4 < this.resources.length; ++var4) {
            if (this.resources[var4].name.equalsIgnoreCase(var1)) {
               this.resources[var4].limit = var2;
               return;
            }
         }

         Quota.Resource[] var5 = new Quota.Resource[this.resources.length + 1];
         System.arraycopy(this.resources, 0, var5, 0, this.resources.length);
         var5[var5.length - 1] = new Quota.Resource(var1, 0L, var2);
         this.resources = var5;
      }
   }

   public static class Resource {
      public String name;
      public long usage;
      public long limit;

      public Resource(String var1, long var2, long var4) {
         this.name = var1;
         this.usage = var2;
         this.limit = var4;
      }
   }
}
