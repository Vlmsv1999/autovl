package javax.mail;

import com.sun.mail.util.LineInputStream;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.lang.reflect.Constructor;
import java.net.InetAddress;
import java.net.URL;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Vector;

public final class Session {
   private final Properties props;
   private final Authenticator authenticator;
   private final Hashtable authTable = new Hashtable();
   private boolean debug = false;
   private PrintStream out;
   private final Vector providers = new Vector();
   private final Hashtable providersByProtocol = new Hashtable();
   private final Hashtable providersByClassName = new Hashtable();
   private final Properties addressMap = new Properties();
   private static Session defaultSession = null;
   private static final String version = "1.4ea";
   // $FF: synthetic field
   static Class class$javax$mail$Session;
   // $FF: synthetic field
   static Class class$javax$mail$URLName;

   private Session(Properties var1, Authenticator var2) {
      this.props = var1;
      this.authenticator = var2;
      if (Boolean.valueOf(var1.getProperty("mail.debug"))) {
         this.debug = true;
      }

      if (this.debug) {
         this.pr("DEBUG: JavaMail version 1.4ea");
      }

      Class var3;
      if (var2 != null) {
         var3 = var2.getClass();
      } else {
         var3 = this.getClass();
      }

      this.loadProviders(var3);
      this.loadAddressMap(var3);
   }

   public static Session getInstance(Properties var0, Authenticator var1) {
      return new Session(var0, var1);
   }

   public static Session getInstance(Properties var0) {
      return new Session(var0, (Authenticator)null);
   }

   public static synchronized Session getDefaultInstance(Properties var0, Authenticator var1) {
      if (defaultSession == null) {
         defaultSession = new Session(var0, var1);
      } else if (defaultSession.authenticator != var1 && (defaultSession.authenticator == null || var1 == null || defaultSession.authenticator.getClass().getClassLoader() != var1.getClass().getClassLoader())) {
         throw new SecurityException("Access to default session denied");
      }

      return defaultSession;
   }

   public static Session getDefaultInstance(Properties var0) {
      return getDefaultInstance(var0, (Authenticator)null);
   }

   public synchronized void setDebug(boolean var1) {
      this.debug = var1;
      if (var1) {
         this.pr("DEBUG: setDebug: JavaMail version 1.4ea");
      }

   }

   public synchronized boolean getDebug() {
      return this.debug;
   }

   public synchronized void setDebugOut(PrintStream var1) {
      this.out = var1;
   }

   public synchronized PrintStream getDebugOut() {
      return this.out == null ? System.out : this.out;
   }

   public synchronized Provider[] getProviders() {
      Provider[] var1 = new Provider[this.providers.size()];
      this.providers.copyInto(var1);
      return var1;
   }

   public synchronized Provider getProvider(String var1) throws NoSuchProviderException {
      if (var1 != null && var1.length() > 0) {
         Provider var2 = null;
         String var3 = this.props.getProperty("mail." + var1 + ".class");
         if (var3 != null) {
            if (this.debug) {
               this.pr("DEBUG: mail." + var1 + ".class property exists and points to " + var3);
            }

            var2 = (Provider)this.providersByClassName.get(var3);
         }

         if (var2 != null) {
            return var2;
         } else {
            var2 = (Provider)this.providersByProtocol.get(var1);
            if (var2 == null) {
               throw new NoSuchProviderException("No provider for " + var1);
            } else {
               if (this.debug) {
                  this.pr("DEBUG: getProvider() returning " + var2.toString());
               }

               return var2;
            }
         }
      } else {
         throw new NoSuchProviderException("Invalid protocol: null");
      }
   }

   public synchronized void setProvider(Provider var1) throws NoSuchProviderException {
      if (var1 == null) {
         throw new NoSuchProviderException("Can't set null provider");
      } else {
         this.providersByProtocol.put(var1.getProtocol(), var1);
         this.props.put("mail." + var1.getProtocol() + ".class", var1.getClassName());
      }
   }

   public Store getStore() throws NoSuchProviderException {
      return this.getStore(this.getProperty("mail.store.protocol"));
   }

   public Store getStore(String var1) throws NoSuchProviderException {
      return this.getStore(new URLName(var1, (String)null, -1, (String)null, (String)null, (String)null));
   }

   public Store getStore(URLName var1) throws NoSuchProviderException {
      String var2 = var1.getProtocol();
      Provider var3 = this.getProvider(var2);
      return this.getStore(var3, var1);
   }

   public Store getStore(Provider var1) throws NoSuchProviderException {
      return this.getStore(var1, (URLName)null);
   }

   private Store getStore(Provider var1, URLName var2) throws NoSuchProviderException {
      if (var1 != null && var1.getType() == Provider.Type.STORE) {
         try {
            return (Store)this.getService(var1, var2);
         } catch (ClassCastException var4) {
            throw new NoSuchProviderException("incorrect class");
         }
      } else {
         throw new NoSuchProviderException("invalid provider");
      }
   }

   public Folder getFolder(URLName var1) throws MessagingException {
      Store var2 = this.getStore(var1);
      var2.connect();
      return var2.getFolder(var1);
   }

   public Transport getTransport() throws NoSuchProviderException {
      return this.getTransport(this.getProperty("mail.transport.protocol"));
   }

   public Transport getTransport(String var1) throws NoSuchProviderException {
      return this.getTransport(new URLName(var1, (String)null, -1, (String)null, (String)null, (String)null));
   }

   public Transport getTransport(URLName var1) throws NoSuchProviderException {
      String var2 = var1.getProtocol();
      Provider var3 = this.getProvider(var2);
      return this.getTransport(var3, var1);
   }

   public Transport getTransport(Provider var1) throws NoSuchProviderException {
      return this.getTransport(var1, (URLName)null);
   }

   public Transport getTransport(Address var1) throws NoSuchProviderException {
      String var2 = (String)this.addressMap.get(var1.getType());
      if (var2 == null) {
         throw new NoSuchProviderException("No provider for Address type: " + var1.getType());
      } else {
         return this.getTransport(var2);
      }
   }

   private Transport getTransport(Provider var1, URLName var2) throws NoSuchProviderException {
      if (var1 != null && var1.getType() == Provider.Type.TRANSPORT) {
         try {
            return (Transport)this.getService(var1, var2);
         } catch (ClassCastException var4) {
            throw new NoSuchProviderException("incorrect class");
         }
      } else {
         throw new NoSuchProviderException("invalid provider");
      }
   }

   private Object getService(Provider var1, URLName var2) throws NoSuchProviderException {
      if (var1 == null) {
         throw new NoSuchProviderException("null");
      } else {
         if (var2 == null) {
            var2 = new URLName(var1.getProtocol(), (String)null, -1, (String)null, (String)null, (String)null);
         }

         Object var3 = null;
         ClassLoader var4;
         if (this.authenticator != null) {
            var4 = this.authenticator.getClass().getClassLoader();
         } else {
            var4 = this.getClass().getClassLoader();
         }

         Class var5 = null;

         try {
            ClassLoader var6 = getContextClassLoader();
            if (var6 != null) {
               try {
                  var5 = var6.loadClass(var1.getClassName());
               } catch (ClassNotFoundException var9) {
               }
            }

            if (var5 == null) {
               var5 = var4.loadClass(var1.getClassName());
            }
         } catch (Exception var11) {
            try {
               var5 = Class.forName(var1.getClassName());
            } catch (Exception var10) {
               if (this.debug) {
                  var10.printStackTrace(this.getDebugOut());
               }

               throw new NoSuchProviderException(var1.getProtocol());
            }
         }

         try {
            Class[] var13 = new Class[]{class$javax$mail$Session == null ? (class$javax$mail$Session = class$("javax.mail.Session")) : class$javax$mail$Session, class$javax$mail$URLName == null ? (class$javax$mail$URLName = class$("javax.mail.URLName")) : class$javax$mail$URLName};
            Constructor var7 = var5.getConstructor(var13);
            Object[] var8 = new Object[]{this, var2};
            var3 = var7.newInstance(var8);
            return var3;
         } catch (Exception var12) {
            if (this.debug) {
               var12.printStackTrace(this.getDebugOut());
            }

            throw new NoSuchProviderException(var1.getProtocol());
         }
      }
   }

   public void setPasswordAuthentication(URLName var1, PasswordAuthentication var2) {
      if (var2 == null) {
         this.authTable.remove(var1);
      } else {
         this.authTable.put(var1, var2);
      }

   }

   public PasswordAuthentication getPasswordAuthentication(URLName var1) {
      return (PasswordAuthentication)this.authTable.get(var1);
   }

   public PasswordAuthentication requestPasswordAuthentication(InetAddress var1, int var2, String var3, String var4, String var5) {
      return this.authenticator != null ? this.authenticator.requestPasswordAuthentication(var1, var2, var3, var4, var5) : null;
   }

   public Properties getProperties() {
      return this.props;
   }

   public String getProperty(String var1) {
      return this.props.getProperty(var1);
   }

   private void loadProviders(Class var1) {
      StreamLoader var2 = new StreamLoader() {
         public void load(InputStream var1) throws IOException {
            Session.this.loadProvidersFromStream(var1);
         }
      };

      try {
         String var3 = System.getProperty("java.home") + File.separator + "lib" + File.separator + "javamail.providers";
         this.loadFile(var3, var2);
      } catch (SecurityException var4) {
         if (this.debug) {
            this.pr("DEBUG: can't get java.home: " + var4);
         }
      }

      this.loadAllResources("META-INF/javamail.providers", var1, var2);
      this.loadResource("/META-INF/javamail.default.providers", var1, var2);
      if (this.providers.size() == 0) {
         if (this.debug) {
            this.pr("DEBUG: failed to load any providers, using defaults");
         }

         this.addProvider(new Provider(Provider.Type.STORE, "imap", "com.sun.mail.imap.IMAPStore", "Sun Microsystems, Inc.", "1.4ea"));
         this.addProvider(new Provider(Provider.Type.STORE, "imaps", "com.sun.mail.imap.IMAPSSLStore", "Sun Microsystems, Inc.", "1.4ea"));
         this.addProvider(new Provider(Provider.Type.STORE, "pop3", "com.sun.mail.pop3.POP3Store", "Sun Microsystems, Inc.", "1.4ea"));
         this.addProvider(new Provider(Provider.Type.STORE, "pop3s", "com.sun.mail.pop3.POP3SSLStore", "Sun Microsystems, Inc.", "1.4ea"));
         this.addProvider(new Provider(Provider.Type.TRANSPORT, "smtp", "com.sun.mail.smtp.SMTPTransport", "Sun Microsystems, Inc.", "1.4ea"));
         this.addProvider(new Provider(Provider.Type.TRANSPORT, "smtps", "com.sun.mail.smtp.SMTPSSLTransport", "Sun Microsystems, Inc.", "1.4ea"));
      }

      if (this.debug) {
         this.pr("DEBUG: Tables of loaded providers");
         this.pr("DEBUG: Providers Listed By Class Name: " + this.providersByClassName.toString());
         this.pr("DEBUG: Providers Listed By Protocol: " + this.providersByProtocol.toString());
      }

   }

   private void loadProvidersFromStream(InputStream var1) throws IOException {
      if (var1 != null) {
         LineInputStream var2 = new LineInputStream(var1);

         while(true) {
            while(true) {
               String var3;
               do {
                  if ((var3 = var2.readLine()) == null) {
                     return;
                  }
               } while(var3.startsWith("#"));

               Provider.Type var4 = null;
               String var5 = null;
               String var6 = null;
               String var7 = null;
               String var8 = null;
               StringTokenizer var9 = new StringTokenizer(var3, ";");

               while(var9.hasMoreTokens()) {
                  String var10 = var9.nextToken().trim();
                  int var11 = var10.indexOf("=");
                  if (var10.startsWith("protocol=")) {
                     var5 = var10.substring(var11 + 1);
                  } else if (var10.startsWith("type=")) {
                     String var12 = var10.substring(var11 + 1);
                     if (var12.equalsIgnoreCase("store")) {
                        var4 = Provider.Type.STORE;
                     } else if (var12.equalsIgnoreCase("transport")) {
                        var4 = Provider.Type.TRANSPORT;
                     }
                  } else if (var10.startsWith("class=")) {
                     var6 = var10.substring(var11 + 1);
                  } else if (var10.startsWith("vendor=")) {
                     var7 = var10.substring(var11 + 1);
                  } else if (var10.startsWith("version=")) {
                     var8 = var10.substring(var11 + 1);
                  }
               }

               if (var4 != null && var5 != null && var6 != null && var5.length() > 0 && var6.length() > 0) {
                  Provider var13 = new Provider(var4, var5, var6, var7, var8);
                  this.addProvider(var13);
               } else if (this.debug) {
                  this.pr("DEBUG: Bad provider entry: " + var3);
               }
            }
         }
      }
   }

   public synchronized void addProvider(Provider var1) {
      this.providers.addElement(var1);
      this.providersByClassName.put(var1.getClassName(), var1);
      if (!this.providersByProtocol.containsKey(var1.getProtocol())) {
         this.providersByProtocol.put(var1.getProtocol(), var1);
      }

   }

   private void loadAddressMap(Class var1) {
      StreamLoader var2 = new StreamLoader() {
         public void load(InputStream var1) throws IOException {
            Session.this.addressMap.load(var1);
         }
      };
      this.loadResource("/META-INF/javamail.default.address.map", var1, var2);
      this.loadAllResources("META-INF/javamail.address.map", var1, var2);

      try {
         String var3 = System.getProperty("java.home") + File.separator + "lib" + File.separator + "javamail.address.map";
         this.loadFile(var3, var2);
      } catch (SecurityException var4) {
         if (this.debug) {
            this.pr("DEBUG: can't get java.home: " + var4);
         }
      }

      if (this.addressMap.isEmpty()) {
         if (this.debug) {
            this.pr("DEBUG: failed to load address map, using defaults");
         }

         this.addressMap.put("rfc822", "smtp");
      }

   }

   public synchronized void setProtocolForAddress(String var1, String var2) {
      if (var2 == null) {
         this.addressMap.remove(var1);
      } else {
         this.addressMap.put(var1, var2);
      }

   }

   private void loadFile(String var1, StreamLoader var2) {
      BufferedInputStream var3 = null;

      try {
         var3 = new BufferedInputStream(new FileInputStream(var1));
         if (var3 != null) {
            var2.load(var3);
            if (this.debug) {
               this.pr("DEBUG: successfully loaded file: " + var1);
            }
         } else if (this.debug) {
            this.pr("DEBUG: not loading file: " + var1);
         }
      } catch (IOException var17) {
         if (this.debug) {
            this.pr("DEBUG: " + var17);
         }
      } catch (SecurityException var18) {
         if (this.debug) {
            this.pr("DEBUG: " + var18);
         }
      } finally {
         try {
            if (var3 != null) {
               var3.close();
            }
         } catch (IOException var16) {
         }

      }

   }

   private void loadResource(String var1, Class var2, StreamLoader var3) {
      InputStream var4 = null;

      try {
         var4 = getResourceAsStream(var2, var1);
         if (var4 != null) {
            var3.load(var4);
            if (this.debug) {
               this.pr("DEBUG: successfully loaded resource: " + var1);
            }
         } else if (this.debug) {
            this.pr("DEBUG: not loading resource: " + var1);
         }
      } catch (IOException var18) {
         if (this.debug) {
            this.pr("DEBUG: " + var18);
         }
      } catch (SecurityException var19) {
         if (this.debug) {
            this.pr("DEBUG: " + var19);
         }
      } finally {
         try {
            if (var4 != null) {
               var4.close();
            }
         } catch (IOException var17) {
         }

      }

   }

   private void loadAllResources(String var1, Class var2, StreamLoader var3) {
      boolean var4 = false;

      try {
         ClassLoader var6 = null;
         var6 = getContextClassLoader();
         if (var6 == null) {
            var6 = var2.getClassLoader();
         }

         URL[] var5;
         if (var6 != null) {
            var5 = getResources(var6, var1);
         } else {
            var5 = getSystemResources(var1);
         }

         if (var5 != null) {
            for(int var7 = 0; var7 < var5.length; ++var7) {
               URL var8 = var5[var7];
               InputStream var9 = null;
               if (this.debug) {
                  this.pr("DEBUG: URL " + var8);
               }

               try {
                  var9 = openStream(var8);
                  if (var9 != null) {
                     var3.load(var9);
                     var4 = true;
                     if (this.debug) {
                        this.pr("DEBUG: successfully loaded resource: " + var8);
                     }
                  } else if (this.debug) {
                     this.pr("DEBUG: not loading resource: " + var8);
                  }
               } catch (IOException var24) {
                  if (this.debug) {
                     this.pr("DEBUG: " + var24);
                  }
               } catch (SecurityException var25) {
                  if (this.debug) {
                     this.pr("DEBUG: " + var25);
                  }
               } finally {
                  try {
                     if (var9 != null) {
                        var9.close();
                     }
                  } catch (IOException var23) {
                  }

               }
            }
         }
      } catch (Exception var27) {
         if (this.debug) {
            this.pr("DEBUG: " + var27);
         }
      }

      if (!var4) {
         if (this.debug) {
            this.pr("DEBUG: !anyLoaded");
         }

         this.loadResource("/" + var1, var2, var3);
      }

   }

   private void pr(String var1) {
      this.getDebugOut().println(var1);
   }

   private static ClassLoader getContextClassLoader() {
      return (ClassLoader)AccessController.doPrivileged(new PrivilegedAction() {
         public Object run() {
            ClassLoader var1 = null;

            try {
               var1 = Thread.currentThread().getContextClassLoader();
            } catch (SecurityException var3) {
            }

            return var1;
         }
      });
   }

   private static InputStream getResourceAsStream(final Class var0, final String var1) throws IOException {
      try {
         return (InputStream)AccessController.doPrivileged(new PrivilegedExceptionAction() {
            public Object run() throws IOException {
               return var0.getResourceAsStream(var1);
            }
         });
      } catch (PrivilegedActionException var3) {
         throw (IOException)var3.getException();
      }
   }

   private static URL[] getResources(final ClassLoader var0, final String var1) {
      return (URL[])AccessController.doPrivileged(new PrivilegedAction() {
         public Object run() {
            URL[] var1x = null;

            try {
               Vector var2 = new Vector();
               Enumeration var3 = var0.getResources(var1);

               while(var3 != null && var3.hasMoreElements()) {
                  URL var4 = (URL)var3.nextElement();
                  if (var4 != null) {
                     var2.addElement(var4);
                  }
               }

               if (var2.size() > 0) {
                  var1x = new URL[var2.size()];
                  var2.copyInto(var1x);
               }
            } catch (IOException var5) {
            } catch (SecurityException var6) {
            }

            return var1x;
         }
      });
   }

   private static URL[] getSystemResources(final String var0) {
      return (URL[])AccessController.doPrivileged(new PrivilegedAction() {
         public Object run() {
            URL[] var1 = null;

            try {
               Vector var2 = new Vector();
               Enumeration var3 = ClassLoader.getSystemResources(var0);

               while(var3 != null && var3.hasMoreElements()) {
                  URL var4 = (URL)var3.nextElement();
                  if (var4 != null) {
                     var2.addElement(var4);
                  }
               }

               if (var2.size() > 0) {
                  var1 = new URL[var2.size()];
                  var2.copyInto(var1);
               }
            } catch (IOException var5) {
            } catch (SecurityException var6) {
            }

            return var1;
         }
      });
   }

   private static InputStream openStream(final URL var0) throws IOException {
      try {
         return (InputStream)AccessController.doPrivileged(new PrivilegedExceptionAction() {
            public Object run() throws IOException {
               return var0.openStream();
            }
         });
      } catch (PrivilegedActionException var2) {
         throw (IOException)var2.getException();
      }
   }

   // $FF: synthetic method
   static Class class$(String var0) {
      try {
         return Class.forName(var0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }
}
