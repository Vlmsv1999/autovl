package javax.mail.internet;

import com.sun.mail.util.LineInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import javax.mail.Header;
import javax.mail.MessagingException;

public class InternetHeaders {
   protected List headers = new ArrayList(40);

   public InternetHeaders() {
      this.headers.add(new InternetHeaders.InternetHeader("Return-Path", (String)null));
      this.headers.add(new InternetHeaders.InternetHeader("Received", (String)null));
      this.headers.add(new InternetHeaders.InternetHeader("Resent-Date", (String)null));
      this.headers.add(new InternetHeaders.InternetHeader("Resent-From", (String)null));
      this.headers.add(new InternetHeaders.InternetHeader("Resent-Sender", (String)null));
      this.headers.add(new InternetHeaders.InternetHeader("Resent-To", (String)null));
      this.headers.add(new InternetHeaders.InternetHeader("Resent-Cc", (String)null));
      this.headers.add(new InternetHeaders.InternetHeader("Resent-Bcc", (String)null));
      this.headers.add(new InternetHeaders.InternetHeader("Resent-Message-Id", (String)null));
      this.headers.add(new InternetHeaders.InternetHeader("Date", (String)null));
      this.headers.add(new InternetHeaders.InternetHeader("From", (String)null));
      this.headers.add(new InternetHeaders.InternetHeader("Sender", (String)null));
      this.headers.add(new InternetHeaders.InternetHeader("Reply-To", (String)null));
      this.headers.add(new InternetHeaders.InternetHeader("To", (String)null));
      this.headers.add(new InternetHeaders.InternetHeader("Cc", (String)null));
      this.headers.add(new InternetHeaders.InternetHeader("Bcc", (String)null));
      this.headers.add(new InternetHeaders.InternetHeader("Message-Id", (String)null));
      this.headers.add(new InternetHeaders.InternetHeader("In-Reply-To", (String)null));
      this.headers.add(new InternetHeaders.InternetHeader("References", (String)null));
      this.headers.add(new InternetHeaders.InternetHeader("Subject", (String)null));
      this.headers.add(new InternetHeaders.InternetHeader("Comments", (String)null));
      this.headers.add(new InternetHeaders.InternetHeader("Keywords", (String)null));
      this.headers.add(new InternetHeaders.InternetHeader("Errors-To", (String)null));
      this.headers.add(new InternetHeaders.InternetHeader("MIME-Version", (String)null));
      this.headers.add(new InternetHeaders.InternetHeader("Content-Type", (String)null));
      this.headers.add(new InternetHeaders.InternetHeader("Content-Transfer-Encoding", (String)null));
      this.headers.add(new InternetHeaders.InternetHeader("Content-MD5", (String)null));
      this.headers.add(new InternetHeaders.InternetHeader(":", (String)null));
      this.headers.add(new InternetHeaders.InternetHeader("Content-Length", (String)null));
      this.headers.add(new InternetHeaders.InternetHeader("Status", (String)null));
   }

   public InternetHeaders(InputStream var1) throws MessagingException {
      this.load(var1);
   }

   public void load(InputStream var1) throws MessagingException {
      LineInputStream var3 = new LineInputStream(var1);
      String var4 = null;
      StringBuffer var5 = new StringBuffer();

      try {
         String var2;
         do {
            var2 = var3.readLine();
            if (var2 != null && (var2.startsWith(" ") || var2.startsWith("\t"))) {
               if (var4 != null) {
                  var5.append(var4);
                  var4 = null;
               }

               var5.append("\r\n");
               var5.append(var2);
            } else {
               if (var4 != null) {
                  this.addHeaderLine(var4);
               } else if (var5.length() > 0) {
                  this.addHeaderLine(var5.toString());
                  var5.setLength(0);
               }

               var4 = var2;
            }
         } while(var2 != null && var2.length() > 0);

      } catch (IOException var7) {
         throw new MessagingException("Error in input stream", var7);
      }
   }

   public String[] getHeader(String var1) {
      Iterator var2 = this.headers.iterator();
      ArrayList var3 = new ArrayList();

      while(var2.hasNext()) {
         InternetHeaders.InternetHeader var4 = (InternetHeaders.InternetHeader)var2.next();
         if (var1.equalsIgnoreCase(var4.getName()) && var4.line != null) {
            var3.add(var4.getValue());
         }
      }

      if (var3.size() == 0) {
         return null;
      } else {
         String[] var5 = new String[var3.size()];
         var5 = (String[])var3.toArray(var5);
         return var5;
      }
   }

   public String getHeader(String var1, String var2) {
      String[] var3 = this.getHeader(var1);
      if (var3 == null) {
         return null;
      } else if (var3.length != 1 && var2 != null) {
         StringBuffer var4 = new StringBuffer(var3[0]);

         for(int var5 = 1; var5 < var3.length; ++var5) {
            var4.append(var2);
            var4.append(var3[var5]);
         }

         return var4.toString();
      } else {
         return var3[0];
      }
   }

   public void setHeader(String var1, String var2) {
      boolean var3 = false;

      for(int var4 = 0; var4 < this.headers.size(); ++var4) {
         InternetHeaders.InternetHeader var5 = (InternetHeaders.InternetHeader)this.headers.get(var4);
         if (var1.equalsIgnoreCase(var5.getName())) {
            if (var3) {
               this.headers.remove(var4);
               --var4;
            } else {
               int var6;
               if (var5.line != null && (var6 = var5.line.indexOf(58)) >= 0) {
                  var5.line = var5.line.substring(0, var6 + 1) + " " + var2;
               } else {
                  var5.line = var1 + ": " + var2;
               }

               var3 = true;
            }
         }
      }

      if (!var3) {
         this.addHeader(var1, var2);
      }

   }

   public void addHeader(String var1, String var2) {
      int var3 = this.headers.size();
      boolean var4 = var1.equalsIgnoreCase("Received") || var1.equalsIgnoreCase("Return-Path");
      if (var4) {
         var3 = 0;
      }

      for(int var5 = this.headers.size() - 1; var5 >= 0; --var5) {
         InternetHeaders.InternetHeader var6 = (InternetHeaders.InternetHeader)this.headers.get(var5);
         if (var1.equalsIgnoreCase(var6.getName())) {
            if (!var4) {
               this.headers.add(var5 + 1, new InternetHeaders.InternetHeader(var1, var2));
               return;
            }

            var3 = var5;
         }

         if (var6.getName().equals(":")) {
            var3 = var5;
         }
      }

      this.headers.add(var3, new InternetHeaders.InternetHeader(var1, var2));
   }

   public void removeHeader(String var1) {
      for(int var2 = 0; var2 < this.headers.size(); ++var2) {
         InternetHeaders.InternetHeader var3 = (InternetHeaders.InternetHeader)this.headers.get(var2);
         if (var1.equalsIgnoreCase(var3.getName())) {
            var3.line = null;
         }
      }

   }

   public Enumeration getAllHeaders() {
      return new InternetHeaders.matchEnum(this.headers, (String[])null, false, false);
   }

   public Enumeration getMatchingHeaders(String[] var1) {
      return new InternetHeaders.matchEnum(this.headers, var1, true, false);
   }

   public Enumeration getNonMatchingHeaders(String[] var1) {
      return new InternetHeaders.matchEnum(this.headers, var1, false, false);
   }

   public void addHeaderLine(String var1) {
      try {
         char var2 = var1.charAt(0);
         if (var2 != ' ' && var2 != '\t') {
            this.headers.add(new InternetHeaders.InternetHeader(var1));
         } else {
            InternetHeaders.InternetHeader var3 = (InternetHeaders.InternetHeader)this.headers.get(this.headers.size() - 1);
            var3.line = var3.line + "\r\n" + var1;
         }
      } catch (StringIndexOutOfBoundsException var4) {
         return;
      } catch (NoSuchElementException var5) {
      }

   }

   public Enumeration getAllHeaderLines() {
      return this.getNonMatchingHeaderLines((String[])null);
   }

   public Enumeration getMatchingHeaderLines(String[] var1) {
      return new InternetHeaders.matchEnum(this.headers, var1, true, true);
   }

   public Enumeration getNonMatchingHeaderLines(String[] var1) {
      return new InternetHeaders.matchEnum(this.headers, var1, false, true);
   }

   static class matchEnum implements Enumeration {
      private Iterator e;
      private String[] names;
      private boolean match;
      private boolean want_line;
      private InternetHeaders.InternetHeader next_header;

      matchEnum(List var1, String[] var2, boolean var3, boolean var4) {
         this.e = var1.iterator();
         this.names = var2;
         this.match = var3;
         this.want_line = var4;
         this.next_header = null;
      }

      public boolean hasMoreElements() {
         if (this.next_header == null) {
            this.next_header = this.nextMatch();
         }

         return this.next_header != null;
      }

      public Object nextElement() {
         if (this.next_header == null) {
            this.next_header = this.nextMatch();
         }

         if (this.next_header == null) {
            throw new NoSuchElementException("No more headers");
         } else {
            InternetHeaders.InternetHeader var1 = this.next_header;
            this.next_header = null;
            return this.want_line ? var1.line : new Header(var1.getName(), var1.getValue());
         }
      }

      private InternetHeaders.InternetHeader nextMatch() {
         label42:
         while(this.e.hasNext()) {
            InternetHeaders.InternetHeader var1 = (InternetHeaders.InternetHeader)this.e.next();
            if (var1.line != null) {
               if (this.names == null) {
                  return this.match ? null : var1;
               }

               for(int var2 = 0; var2 < this.names.length; ++var2) {
                  if (this.names[var2].equalsIgnoreCase(var1.getName())) {
                     if (!this.match) {
                        continue label42;
                     }

                     return var1;
                  }
               }

               if (!this.match) {
                  return var1;
               }
            }
         }

         return null;
      }
   }

   protected static final class InternetHeader extends Header {
      String line;

      public InternetHeader(String var1) {
         super("", "");
         int var2 = var1.indexOf(58);
         if (var2 < 0) {
            this.name = var1.trim();
         } else {
            this.name = var1.substring(0, var2).trim();
         }

         this.line = var1;
      }

      public InternetHeader(String var1, String var2) {
         super(var1, "");
         if (var2 != null) {
            this.line = var1 + ": " + var2;
         } else {
            this.line = null;
         }

      }

      public String getValue() {
         int var1 = this.line.indexOf(58);
         if (var1 < 0) {
            return this.line;
         } else {
            int var2;
            for(var2 = var1 + 1; var2 < this.line.length(); ++var2) {
               char var3 = this.line.charAt(var2);
               if (var3 != ' ' && var3 != '\t' && var3 != '\r' && var3 != '\n') {
                  break;
               }
            }

            return this.line.substring(var2);
         }
      }
   }
}
