package javax.mail.internet;

import java.text.FieldPosition;
import java.text.NumberFormat;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

public class MailDateFormat extends SimpleDateFormat {
   private static final long serialVersionUID = -8148227605210628779L;
   static boolean debug = false;
   private static TimeZone tz = TimeZone.getTimeZone("GMT");
   private static Calendar cal;

   public MailDateFormat() {
      super("EEE, d MMM yyyy HH:mm:ss 'XXXXX' (z)", Locale.US);
   }

   public StringBuffer format(Date var1, StringBuffer var2, FieldPosition var3) {
      int var4 = var2.length();
      super.format(var1, var2, var3);
      boolean var5 = false;

      int var10;
      for(var10 = var4 + 25; var2.charAt(var10) != 'X'; ++var10) {
      }

      this.calendar.clear();
      this.calendar.setTime(var1);
      int var6 = this.calendar.get(15) + this.calendar.get(16);
      if (var6 < 0) {
         var2.setCharAt(var10++, '-');
         var6 = -var6;
      } else {
         var2.setCharAt(var10++, '+');
      }

      int var7 = var6 / 60 / 1000;
      int var8 = var7 / 60;
      int var9 = var7 % 60;
      var2.setCharAt(var10++, Character.forDigit(var8 / 10, 10));
      var2.setCharAt(var10++, Character.forDigit(var8 % 10, 10));
      var2.setCharAt(var10++, Character.forDigit(var9 / 10, 10));
      var2.setCharAt(var10++, Character.forDigit(var9 % 10, 10));
      return var2;
   }

   public Date parse(String var1, ParsePosition var2) {
      return parseDate(var1.toCharArray(), var2, this.isLenient());
   }

   private static Date parseDate(char[] var0, ParsePosition var1, boolean var2) {
      try {
         boolean var3 = true;
         boolean var4 = true;
         boolean var5 = true;
         boolean var6 = false;
         boolean var7 = false;
         int var8 = 0;
         int var9 = 0;
         MailDateParser var10 = new MailDateParser(var0);
         var10.skipUntilNumber();
         int var14 = var10.parseNumber();
         if (!var10.skipIfChar('-')) {
            var10.skipWhiteSpace();
         }

         int var15 = var10.parseMonth();
         if (!var10.skipIfChar('-')) {
            var10.skipWhiteSpace();
         }

         int var16 = var10.parseNumber();
         if (var16 < 50) {
            var16 += 2000;
         } else if (var16 < 100) {
            var16 += 1900;
         }

         var10.skipWhiteSpace();
         int var17 = var10.parseNumber();
         var10.skipChar(':');
         int var18 = var10.parseNumber();
         if (var10.skipIfChar(':')) {
            var8 = var10.parseNumber();
         }

         try {
            var10.skipWhiteSpace();
            var9 = var10.parseTimeZone();
         } catch (java.text.ParseException var12) {
            if (debug) {
               System.out.println("No timezone? : '" + var0 + "'");
            }
         }

         var1.setIndex(var10.getIndex());
         Date var11 = ourUTC(var16, var15, var14, var17, var18, var8, var9, var2);
         return var11;
      } catch (Exception var13) {
         if (debug) {
            System.out.println("Bad date: '" + var0 + "'");
            var13.printStackTrace();
         }

         var1.setIndex(1);
         return null;
      }
   }

   private static synchronized Date ourUTC(int var0, int var1, int var2, int var3, int var4, int var5, int var6, boolean var7) {
      cal.clear();
      cal.setLenient(var7);
      cal.set(1, var0);
      cal.set(2, var1);
      cal.set(5, var2);
      cal.set(11, var3);
      cal.set(12, var4 + var6);
      cal.set(13, var5);
      return cal.getTime();
   }

   public void setCalendar(Calendar var1) {
      throw new RuntimeException("Method setCalendar() shouldn't be called");
   }

   public void setNumberFormat(NumberFormat var1) {
      throw new RuntimeException("Method setNumberFormat() shouldn't be called");
   }

   static {
      cal = new GregorianCalendar(tz);
   }
}
