package javax.mail.internet;

public class HeaderTokenizer {
   private String string;
   private boolean skipComments;
   private String delimiters;
   private int currentPos;
   private int maxPos;
   private int nextPos;
   private int peekPos;
   public static final String RFC822 = "()<>@,;:\\\"\t .[]";
   public static final String MIME = "()<>@,;:\\\"\t []/?=";
   private static final HeaderTokenizer.Token EOFToken = new HeaderTokenizer.Token(-4, (String)null);

   public HeaderTokenizer(String var1, String var2, boolean var3) {
      this.string = var1 == null ? "" : var1;
      this.skipComments = var3;
      this.delimiters = var2;
      this.currentPos = this.nextPos = this.peekPos = 0;
      this.maxPos = this.string.length();
   }

   public HeaderTokenizer(String var1, String var2) {
      this(var1, var2, true);
   }

   public HeaderTokenizer(String var1) {
      this(var1, "()<>@,;:\\\"\t .[]");
   }

   public HeaderTokenizer.Token next() throws ParseException {
      this.currentPos = this.nextPos;
      HeaderTokenizer.Token var1 = this.getNext();
      this.nextPos = this.peekPos = this.currentPos;
      return var1;
   }

   public HeaderTokenizer.Token peek() throws ParseException {
      this.currentPos = this.peekPos;
      HeaderTokenizer.Token var1 = this.getNext();
      this.peekPos = this.currentPos;
      return var1;
   }

   public String getRemainder() {
      return this.string.substring(this.nextPos);
   }

   private HeaderTokenizer.Token getNext() throws ParseException {
      if (this.currentPos >= this.maxPos) {
         return EOFToken;
      } else if (this.skipWhiteSpace() == -4) {
         return EOFToken;
      } else {
         boolean var3 = false;

         char var1;
         int var2;
         for(var1 = this.string.charAt(this.currentPos); var1 == '('; var1 = this.string.charAt(this.currentPos)) {
            var2 = ++this.currentPos;

            int var4;
            for(var4 = 1; var4 > 0 && this.currentPos < this.maxPos; ++this.currentPos) {
               var1 = this.string.charAt(this.currentPos);
               if (var1 == '\\') {
                  ++this.currentPos;
                  var3 = true;
               } else if (var1 == '\r') {
                  var3 = true;
               } else if (var1 == '(') {
                  ++var4;
               } else if (var1 == ')') {
                  --var4;
               }
            }

            if (var4 != 0) {
               throw new ParseException("Unbalanced comments");
            }

            if (!this.skipComments) {
               String var5;
               if (var3) {
                  var5 = filterToken(this.string, var2, this.currentPos - 1);
               } else {
                  var5 = this.string.substring(var2, this.currentPos - 1);
               }

               return new HeaderTokenizer.Token(-3, var5);
            }

            if (this.skipWhiteSpace() == -4) {
               return EOFToken;
            }
         }

         if (var1 == '"') {
            for(var2 = ++this.currentPos; this.currentPos < this.maxPos; ++this.currentPos) {
               var1 = this.string.charAt(this.currentPos);
               if (var1 == '\\') {
                  ++this.currentPos;
                  var3 = true;
               } else if (var1 == '\r') {
                  var3 = true;
               } else if (var1 == '"') {
                  ++this.currentPos;
                  String var7;
                  if (var3) {
                     var7 = filterToken(this.string, var2, this.currentPos - 1);
                  } else {
                     var7 = this.string.substring(var2, this.currentPos - 1);
                  }

                  return new HeaderTokenizer.Token(-2, var7);
               }
            }

            throw new ParseException("Unbalanced quoted string");
         } else if (var1 >= ' ' && var1 < 127 && this.delimiters.indexOf(var1) < 0) {
            for(var2 = this.currentPos; this.currentPos < this.maxPos; ++this.currentPos) {
               var1 = this.string.charAt(this.currentPos);
               if (var1 < ' ' || var1 >= 127 || var1 == '(' || var1 == ' ' || var1 == '"' || this.delimiters.indexOf(var1) >= 0) {
                  break;
               }
            }

            return new HeaderTokenizer.Token(-1, this.string.substring(var2, this.currentPos));
         } else {
            ++this.currentPos;
            char[] var6 = new char[]{var1};
            return new HeaderTokenizer.Token(var1, new String(var6));
         }
      }
   }

   private int skipWhiteSpace() {
      while(this.currentPos < this.maxPos) {
         char var1;
         if ((var1 = this.string.charAt(this.currentPos)) != ' ' && var1 != '\t' && var1 != '\r' && var1 != '\n') {
            return this.currentPos;
         }

         ++this.currentPos;
      }

      return -4;
   }

   private static String filterToken(String var0, int var1, int var2) {
      StringBuffer var3 = new StringBuffer();
      boolean var5 = false;
      boolean var6 = false;

      for(int var7 = var1; var7 < var2; ++var7) {
         char var4 = var0.charAt(var7);
         if (var4 == '\n' && var6) {
            var6 = false;
         } else {
            var6 = false;
            if (!var5) {
               if (var4 == '\\') {
                  var5 = true;
               } else if (var4 == '\r') {
                  var6 = true;
               } else {
                  var3.append(var4);
               }
            } else {
               var3.append(var4);
               var5 = false;
            }
         }
      }

      return var3.toString();
   }

   public static class Token {
      private int type;
      private String value;
      public static final int ATOM = -1;
      public static final int QUOTEDSTRING = -2;
      public static final int COMMENT = -3;
      public static final int EOF = -4;

      public Token(int var1, String var2) {
         this.type = var1;
         this.value = var2;
      }

      public int getType() {
         return this.type;
      }

      public String getValue() {
         return this.value;
      }
   }
}
