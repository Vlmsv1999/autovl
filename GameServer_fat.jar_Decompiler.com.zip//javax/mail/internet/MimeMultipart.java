package javax.mail.internet;

import com.sun.mail.util.ASCIIUtility;
import com.sun.mail.util.LineInputStream;
import com.sun.mail.util.LineOutputStream;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import javax.activation.DataSource;
import javax.mail.BodyPart;
import javax.mail.MessageAware;
import javax.mail.MessageContext;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.MultipartDataSource;

public class MimeMultipart extends Multipart {
   private static boolean ignoreMissingEndBoundary = true;
   private static boolean ignoreMissingBoundaryParameter = true;
   private static boolean bmparse = true;
   protected DataSource ds;
   protected boolean parsed;
   private boolean complete;
   private String preamble;

   public MimeMultipart() {
      this("mixed");
   }

   public MimeMultipart(String var1) {
      this.ds = null;
      this.parsed = true;
      this.complete = true;
      this.preamble = null;
      String var2 = UniqueValue.getUniqueBoundaryValue();
      ContentType var3 = new ContentType("multipart", var1, (ParameterList)null);
      var3.setParameter("boundary", var2);
      this.contentType = var3.toString();
   }

   public MimeMultipart(DataSource var1) throws MessagingException {
      this.ds = null;
      this.parsed = true;
      this.complete = true;
      this.preamble = null;
      if (var1 instanceof MessageAware) {
         MessageContext var2 = ((MessageAware)var1).getMessageContext();
         this.setParent(var2.getPart());
      }

      if (var1 instanceof MultipartDataSource) {
         this.setMultipartDataSource((MultipartDataSource)var1);
      } else {
         this.parsed = false;
         this.ds = var1;
         this.contentType = var1.getContentType();
      }
   }

   public synchronized void setSubType(String var1) throws MessagingException {
      ContentType var2 = new ContentType(this.contentType);
      var2.setSubType(var1);
      this.contentType = var2.toString();
   }

   public synchronized int getCount() throws MessagingException {
      this.parse();
      return super.getCount();
   }

   public synchronized BodyPart getBodyPart(int var1) throws MessagingException {
      this.parse();
      return super.getBodyPart(var1);
   }

   public synchronized BodyPart getBodyPart(String var1) throws MessagingException {
      this.parse();
      int var2 = this.getCount();

      for(int var3 = 0; var3 < var2; ++var3) {
         MimeBodyPart var4 = (MimeBodyPart)this.getBodyPart(var3);
         String var5 = var4.getContentID();
         if (var5 != null && var5.equals(var1)) {
            return var4;
         }
      }

      return null;
   }

   public boolean isComplete() throws MessagingException {
      this.parse();
      return this.complete;
   }

   public String getPreamble() throws MessagingException {
      this.parse();
      return this.preamble;
   }

   public void setPreamble(String var1) throws MessagingException {
      this.preamble = var1;
   }

   protected void updateHeaders() throws MessagingException {
      for(int var1 = 0; var1 < this.parts.size(); ++var1) {
         ((MimeBodyPart)this.parts.elementAt(var1)).updateHeaders();
      }

   }

   public void writeTo(OutputStream var1) throws IOException, MessagingException {
      this.parse();
      String var2 = "--" + (new ContentType(this.contentType)).getParameter("boundary");
      LineOutputStream var3 = new LineOutputStream(var1);
      if (this.preamble != null) {
         byte[] var4 = ASCIIUtility.getBytes(this.preamble);
         var3.write(var4);
         if (var4.length > 0 && var4[var4.length - 1] != 13 && var4[var4.length - 1] != 10) {
            var3.writeln();
         }
      }

      for(int var5 = 0; var5 < this.parts.size(); ++var5) {
         var3.writeln(var2);
         ((MimeBodyPart)this.parts.elementAt(var5)).writeTo(var1);
         var3.writeln();
      }

      var3.writeln(var2 + "--");
   }

   protected synchronized void parse() throws MessagingException {
      if (!this.parsed) {
         if (bmparse) {
            this.parsebm();
         } else {
            Object var1 = null;
            SharedInputStream var2 = null;
            long var3 = 0L;
            long var5 = 0L;

            try {
               var1 = this.ds.getInputStream();
               if (!(var1 instanceof ByteArrayInputStream) && !(var1 instanceof BufferedInputStream) && !(var1 instanceof SharedInputStream)) {
                  var1 = new BufferedInputStream((InputStream)var1);
               }
            } catch (Exception var35) {
               throw new MessagingException("No inputstream from datasource");
            }

            if (var1 instanceof SharedInputStream) {
               var2 = (SharedInputStream)var1;
            }

            ContentType var7 = new ContentType(this.contentType);
            String var8 = null;
            String var9 = var7.getParameter("boundary");
            if (var9 != null) {
               var8 = "--" + var9;
            } else if (!ignoreMissingBoundaryParameter) {
               throw new MessagingException("Missing boundary parameter");
            }

            try {
               LineInputStream var10 = new LineInputStream((InputStream)var1);
               String var12 = null;

               String var11;
               while((var11 = var10.readLine()) != null) {
                  int var13;
                  for(var13 = var11.length() - 1; var13 >= 0; --var13) {
                     char var14 = var11.charAt(var13);
                     if (var14 != ' ' && var14 != '\t') {
                        break;
                     }
                  }

                  var11 = var11.substring(0, var13 + 1);
                  if (var8 != null) {
                     if (var11.equals(var8)) {
                        break;
                     }
                  } else if (var11.startsWith("--")) {
                     var8 = var11;
                     break;
                  }

                  if (var11.length() > 0) {
                     if (var12 == null) {
                        try {
                           var12 = System.getProperty("line.separator", "\n");
                        } catch (SecurityException var34) {
                           var12 = "\n";
                        }
                     }

                     if (this.preamble == null) {
                        this.preamble = var11 + var12;
                     } else {
                        this.preamble = this.preamble + var11 + var12;
                     }
                  }
               }

               if (var11 == null) {
                  throw new MessagingException("Missing start boundary");
               }

               byte[] var38 = ASCIIUtility.getBytes(var8);
               int var39 = var38.length;

               MimeBodyPart var40;
               for(boolean var15 = false; !var15; this.addBodyPart(var40)) {
                  InternetHeaders var16 = null;
                  if (var2 != null) {
                     var3 = var2.getPosition();

                     while((var11 = var10.readLine()) != null && var11.length() > 0) {
                     }

                     if (var11 == null) {
                        if (!ignoreMissingEndBoundary) {
                           throw new MessagingException("missing multipart end boundary");
                        }

                        this.complete = false;
                        break;
                     }
                  } else {
                     var16 = this.createInternetHeaders((InputStream)var1);
                  }

                  if (!((InputStream)var1).markSupported()) {
                     throw new MessagingException("Stream doesn't support mark");
                  }

                  ByteArrayOutputStream var17 = null;
                  if (var2 == null) {
                     var17 = new ByteArrayOutputStream();
                  } else {
                     var5 = var2.getPosition();
                  }

                  boolean var19 = true;
                  int var20 = -1;
                  int var21 = -1;

                  label437:
                  while(true) {
                     if (var19) {
                        ((InputStream)var1).mark(var39 + 4 + 1000);

                        int var22;
                        for(var22 = 0; var22 < var39 && ((InputStream)var1).read() == (var38[var22] & 255); ++var22) {
                        }

                        if (var22 == var39) {
                           int var23 = ((InputStream)var1).read();
                           if (var23 == 45 && ((InputStream)var1).read() == 45) {
                              this.complete = true;
                              var15 = true;
                              break;
                           }

                           while(true) {
                              if (var23 != 32 && var23 != 9) {
                                 if (var23 == 10) {
                                    break label437;
                                 }

                                 if (var23 == 13) {
                                    ((InputStream)var1).mark(1);
                                    if (((InputStream)var1).read() != 10) {
                                       ((InputStream)var1).reset();
                                    }
                                    break label437;
                                 }
                                 break;
                              }

                              var23 = ((InputStream)var1).read();
                           }
                        }

                        ((InputStream)var1).reset();
                        if (var17 != null && var20 != -1) {
                           var17.write(var20);
                           if (var21 != -1) {
                              var17.write(var21);
                           }

                           var21 = -1;
                           var20 = -1;
                        }
                     }

                     int var18;
                     if ((var18 = ((InputStream)var1).read()) < 0) {
                        if (!ignoreMissingEndBoundary) {
                           throw new MessagingException("missing multipart end boundary");
                        }

                        this.complete = false;
                        var15 = true;
                        break;
                     }

                     if (var18 != 13 && var18 != 10) {
                        var19 = false;
                        if (var17 != null) {
                           var17.write(var18);
                        }
                     } else {
                        var19 = true;
                        if (var2 != null) {
                           var5 = var2.getPosition() - 1L;
                        }

                        var20 = var18;
                        if (var18 == 13) {
                           ((InputStream)var1).mark(1);
                           if ((var18 = ((InputStream)var1).read()) == 10) {
                              var21 = var18;
                           } else {
                              ((InputStream)var1).reset();
                           }
                        }
                     }
                  }

                  if (var2 != null) {
                     var40 = this.createMimeBodyPart(var2.newStream(var3, var5));
                  } else {
                     var40 = this.createMimeBodyPart(var16, var17.toByteArray());
                  }
               }
            } catch (IOException var36) {
               throw new MessagingException("IO Error", var36);
            } finally {
               try {
                  ((InputStream)var1).close();
               } catch (IOException var33) {
               }

            }

            this.parsed = true;
         }
      }
   }

   private synchronized void parsebm() throws MessagingException {
      if (!this.parsed) {
         Object var1 = null;
         SharedInputStream var2 = null;
         long var3 = 0L;
         long var5 = 0L;

         try {
            var1 = this.ds.getInputStream();
            if (!(var1 instanceof ByteArrayInputStream) && !(var1 instanceof BufferedInputStream) && !(var1 instanceof SharedInputStream)) {
               var1 = new BufferedInputStream((InputStream)var1);
            }
         } catch (Exception var43) {
            throw new MessagingException("No inputstream from datasource");
         }

         if (var1 instanceof SharedInputStream) {
            var2 = (SharedInputStream)var1;
         }

         ContentType var7 = new ContentType(this.contentType);
         String var8 = null;
         String var9 = var7.getParameter("boundary");
         if (var9 != null) {
            var8 = "--" + var9;
         } else if (!ignoreMissingBoundaryParameter) {
            throw new MessagingException("Missing boundary parameter");
         }

         try {
            LineInputStream var10 = new LineInputStream((InputStream)var1);
            String var12 = null;

            String var11;
            while((var11 = var10.readLine()) != null) {
               int var13;
               for(var13 = var11.length() - 1; var13 >= 0; --var13) {
                  char var14 = var11.charAt(var13);
                  if (var14 != ' ' && var14 != '\t') {
                     break;
                  }
               }

               var11 = var11.substring(0, var13 + 1);
               if (var8 != null) {
                  if (var11.equals(var8)) {
                     break;
                  }
               } else if (var11.startsWith("--")) {
                  var8 = var11;
                  break;
               }

               if (var11.length() > 0) {
                  if (var12 == null) {
                     try {
                        var12 = System.getProperty("line.separator", "\n");
                     } catch (SecurityException var42) {
                        var12 = "\n";
                     }
                  }

                  if (this.preamble == null) {
                     this.preamble = var11 + var12;
                  } else {
                     this.preamble = this.preamble + var11 + var12;
                  }
               }
            }

            if (var11 == null) {
               throw new MessagingException("Missing start boundary");
            }

            byte[] var46 = ASCIIUtility.getBytes(var8);
            int var47 = var46.length;
            int[] var15 = new int[256];

            for(int var16 = 0; var16 < var47; ++var16) {
               var15[var46[var16]] = var16 + 1;
            }

            int[] var17 = new int[var47];

            label538:
            for(int var18 = var47; var18 > 0; --var18) {
               int var19;
               for(var19 = var47 - 1; var19 >= var18; --var19) {
                  if (var46[var19] != var46[var19 - var18]) {
                     continue label538;
                  }

                  var17[var19 - 1] = var18;
               }

               while(var19 > 0) {
                  --var19;
                  var17[var19] = var18;
               }
            }

            var17[var47 - 1] = 1;

            MimeBodyPart var50;
            for(boolean var48 = false; !var48; this.addBodyPart(var50)) {
               InternetHeaders var20 = null;
               if (var2 == null) {
                  var20 = this.createInternetHeaders((InputStream)var1);
               } else {
                  var3 = var2.getPosition();

                  while((var11 = var10.readLine()) != null && var11.length() > 0) {
                  }

                  if (var11 == null) {
                     if (!ignoreMissingEndBoundary) {
                        throw new MessagingException("missing multipart end boundary");
                     }

                     this.complete = false;
                     break;
                  }
               }

               if (!((InputStream)var1).markSupported()) {
                  throw new MessagingException("Stream doesn't support mark");
               }

               ByteArrayOutputStream var21 = null;
               if (var2 == null) {
                  var21 = new ByteArrayOutputStream();
               } else {
                  var5 = var2.getPosition();
               }

               byte[] var23 = new byte[var47];
               byte[] var24 = new byte[var47];
               boolean var25 = false;
               int var26 = 0;
               boolean var28 = true;

               byte var27;
               int var49;
               while(true) {
                  ((InputStream)var1).mark(var47 + 4 + 1000);
                  var27 = 0;
                  var49 = ((InputStream)var1).read(var23, 0, var47);
                  if (var49 < var47) {
                     if (!ignoreMissingEndBoundary) {
                        throw new MessagingException("missing multipart end boundary");
                     }

                     if (var2 != null) {
                        var5 = var2.getPosition();
                     }

                     this.complete = false;
                     var48 = true;
                     break;
                  }

                  int var29;
                  for(var29 = var47 - 1; var29 >= 0 && var23[var29] == var46[var29]; --var29) {
                  }

                  int var30;
                  if (var29 < 0) {
                     var27 = 0;
                     if (!var28) {
                        byte var22 = var24[var26 - 1];
                        if (var22 == 13 || var22 == 10) {
                           var27 = 1;
                           if (var22 == 10 && var26 >= 2) {
                              var22 = var24[var26 - 2];
                              if (var22 == 13) {
                                 var27 = 2;
                              }
                           }
                        }
                     }

                     if (var28 || var27 > 0) {
                        if (var2 != null) {
                           var5 = var2.getPosition() - (long)var47 - (long)var27;
                        }

                        var30 = ((InputStream)var1).read();
                        if (var30 == 45 && ((InputStream)var1).read() == 45) {
                           this.complete = true;
                           var48 = true;
                           break;
                        }

                        while(var30 == 32 || var30 == 9) {
                           var30 = ((InputStream)var1).read();
                        }

                        if (var30 == 10) {
                           break;
                        }

                        if (var30 == 13) {
                           ((InputStream)var1).mark(1);
                           if (((InputStream)var1).read() != 10) {
                              ((InputStream)var1).reset();
                           }
                           break;
                        }
                     }

                     var29 = 0;
                  }

                  var30 = Math.max(var29 + 1 - var15[var23[var29] & 127], var17[var29]);
                  if (var30 < 2) {
                     if (var2 == null && var26 > 1) {
                        var21.write(var24, 0, var26 - 1);
                     }

                     ((InputStream)var1).reset();
                     ((InputStream)var1).skip(1L);
                     if (var26 >= 1) {
                        var24[0] = var24[var26 - 1];
                        var24[1] = var23[0];
                        var26 = 2;
                     } else {
                        var24[0] = var23[0];
                        var26 = 1;
                     }
                  } else {
                     if (var26 > 0 && var2 == null) {
                        var21.write(var24, 0, var26);
                     }

                     var26 = var30;
                     ((InputStream)var1).reset();
                     ((InputStream)var1).skip((long)var30);
                     byte[] var31 = var23;
                     var23 = var24;
                     var24 = var31;
                  }

                  var28 = false;
               }

               if (var2 != null) {
                  var50 = this.createMimeBodyPart(var2.newStream(var3, var5));
               } else {
                  if (var26 - var27 > 0) {
                     var21.write(var24, 0, var26 - var27);
                  }

                  if (!this.complete && var49 > 0) {
                     var21.write(var23, 0, var49);
                  }

                  var50 = this.createMimeBodyPart(var20, var21.toByteArray());
               }
            }
         } catch (IOException var44) {
            throw new MessagingException("IO Error", var44);
         } finally {
            try {
               ((InputStream)var1).close();
            } catch (IOException var41) {
            }

         }

         this.parsed = true;
      }
   }

   protected InternetHeaders createInternetHeaders(InputStream var1) throws MessagingException {
      return new InternetHeaders(var1);
   }

   protected MimeBodyPart createMimeBodyPart(InternetHeaders var1, byte[] var2) throws MessagingException {
      return new MimeBodyPart(var1, var2);
   }

   protected MimeBodyPart createMimeBodyPart(InputStream var1) throws MessagingException {
      return new MimeBodyPart(var1);
   }

   static {
      try {
         String var0 = System.getProperty("mail.mime.multipart.ignoremissingendboundary");
         ignoreMissingEndBoundary = var0 == null || !var0.equalsIgnoreCase("false");
         var0 = System.getProperty("mail.mime.multipart.ignoremissingboundaryparameter");
         ignoreMissingBoundaryParameter = var0 == null || !var0.equalsIgnoreCase("false");
         var0 = System.getProperty("mail.mime.multipart.bmparse");
         bmparse = var0 == null || !var0.equalsIgnoreCase("false");
      } catch (SecurityException var1) {
      }

   }
}
