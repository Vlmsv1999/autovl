package javax.mail.internet;

import com.sun.mail.util.ASCIIUtility;
import com.sun.mail.util.BASE64DecoderStream;
import com.sun.mail.util.BASE64EncoderStream;
import com.sun.mail.util.BEncoderStream;
import com.sun.mail.util.LineInputStream;
import com.sun.mail.util.QDecoderStream;
import com.sun.mail.util.QEncoderStream;
import com.sun.mail.util.QPDecoderStream;
import com.sun.mail.util.QPEncoderStream;
import com.sun.mail.util.UUDecoderStream;
import com.sun.mail.util.UUEncoderStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.Hashtable;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.mail.MessagingException;

public class MimeUtility {
   public static final int ALL = -1;
   private static boolean decodeStrict = true;
   private static boolean encodeEolStrict = false;
   private static boolean foldEncodedWords = false;
   private static boolean foldText = true;
   private static String defaultJavaCharset;
   private static String defaultMIMECharset;
   private static Hashtable mime2java;
   private static Hashtable java2mime;
   static final int ALL_ASCII = 1;
   static final int MOSTLY_ASCII = 2;
   static final int MOSTLY_NONASCII = 3;
   // $FF: synthetic field
   static Class class$javax$mail$internet$MimeUtility;

   private MimeUtility() {
   }

   public static String getEncoding(DataSource var0) {
      ContentType var1 = null;
      InputStream var2 = null;
      String var3 = null;

      try {
         var1 = new ContentType(var0.getContentType());
         var2 = var0.getInputStream();
      } catch (Exception var8) {
         return "base64";
      }

      boolean var4 = var1.match("text/*");
      int var5 = checkAscii(var2, -1, !var4);
      switch(var5) {
      case 1:
         var3 = "7bit";
         break;
      case 2:
         var3 = "quoted-printable";
         break;
      default:
         var3 = "base64";
      }

      try {
         var2.close();
      } catch (IOException var7) {
      }

      return var3;
   }

   public static String getEncoding(DataHandler var0) {
      ContentType var1 = null;
      String var2 = null;
      if (var0.getName() != null) {
         return getEncoding(var0.getDataSource());
      } else {
         try {
            var1 = new ContentType(var0.getContentType());
         } catch (Exception var7) {
            return "base64";
         }

         AsciiOutputStream var3;
         if (var1.match("text/*")) {
            var3 = new AsciiOutputStream(false, false);

            try {
               var0.writeTo(var3);
            } catch (IOException var6) {
            }

            switch(var3.getAscii()) {
            case 1:
               var2 = "7bit";
               break;
            case 2:
               var2 = "quoted-printable";
               break;
            default:
               var2 = "base64";
            }
         } else {
            var3 = new AsciiOutputStream(true, encodeEolStrict);

            try {
               var0.writeTo(var3);
            } catch (IOException var5) {
            }

            if (var3.getAscii() == 1) {
               var2 = "7bit";
            } else {
               var2 = "base64";
            }
         }

         return var2;
      }
   }

   public static InputStream decode(InputStream var0, String var1) throws MessagingException {
      if (var1.equalsIgnoreCase("base64")) {
         return new BASE64DecoderStream(var0);
      } else if (var1.equalsIgnoreCase("quoted-printable")) {
         return new QPDecoderStream(var0);
      } else if (!var1.equalsIgnoreCase("uuencode") && !var1.equalsIgnoreCase("x-uuencode") && !var1.equalsIgnoreCase("x-uue")) {
         if (!var1.equalsIgnoreCase("binary") && !var1.equalsIgnoreCase("7bit") && !var1.equalsIgnoreCase("8bit")) {
            throw new MessagingException("Unknown encoding: " + var1);
         } else {
            return var0;
         }
      } else {
         return new UUDecoderStream(var0);
      }
   }

   public static OutputStream encode(OutputStream var0, String var1) throws MessagingException {
      if (var1 == null) {
         return var0;
      } else if (var1.equalsIgnoreCase("base64")) {
         return new BASE64EncoderStream(var0);
      } else if (var1.equalsIgnoreCase("quoted-printable")) {
         return new QPEncoderStream(var0);
      } else if (!var1.equalsIgnoreCase("uuencode") && !var1.equalsIgnoreCase("x-uuencode") && !var1.equalsIgnoreCase("x-uue")) {
         if (!var1.equalsIgnoreCase("binary") && !var1.equalsIgnoreCase("7bit") && !var1.equalsIgnoreCase("8bit")) {
            throw new MessagingException("Unknown encoding: " + var1);
         } else {
            return var0;
         }
      } else {
         return new UUEncoderStream(var0);
      }
   }

   public static OutputStream encode(OutputStream var0, String var1, String var2) throws MessagingException {
      if (var1 == null) {
         return var0;
      } else if (var1.equalsIgnoreCase("base64")) {
         return new BASE64EncoderStream(var0);
      } else if (var1.equalsIgnoreCase("quoted-printable")) {
         return new QPEncoderStream(var0);
      } else if (!var1.equalsIgnoreCase("uuencode") && !var1.equalsIgnoreCase("x-uuencode") && !var1.equalsIgnoreCase("x-uue")) {
         if (!var1.equalsIgnoreCase("binary") && !var1.equalsIgnoreCase("7bit") && !var1.equalsIgnoreCase("8bit")) {
            throw new MessagingException("Unknown encoding: " + var1);
         } else {
            return var0;
         }
      } else {
         return new UUEncoderStream(var0, var2);
      }
   }

   public static String encodeText(String var0) throws UnsupportedEncodingException {
      return encodeText(var0, (String)null, (String)null);
   }

   public static String encodeText(String var0, String var1, String var2) throws UnsupportedEncodingException {
      return encodeWord(var0, var1, var2, false);
   }

   public static String decodeText(String var0) throws UnsupportedEncodingException {
      String var1 = " \t\n\r";
      if (var0.indexOf("=?") == -1) {
         return var0;
      } else {
         StringTokenizer var2 = new StringTokenizer(var0, var1, true);
         StringBuffer var3 = new StringBuffer();
         StringBuffer var4 = new StringBuffer();
         boolean var5 = false;

         while(true) {
            while(var2.hasMoreTokens()) {
               String var7 = var2.nextToken();
               char var6;
               if ((var6 = var7.charAt(0)) != ' ' && var6 != '\t' && var6 != '\r' && var6 != '\n') {
                  String var8;
                  try {
                     var8 = decodeWord(var7);
                     if (!var5 && var4.length() > 0) {
                        var3.append(var4);
                     }

                     var5 = true;
                  } catch (ParseException var10) {
                     var8 = var7;
                     if (!decodeStrict) {
                        var8 = decodeInnerWords(var7);
                     }

                     if (var4.length() > 0) {
                        var3.append(var4);
                     }

                     var5 = false;
                  }

                  var3.append(var8);
                  var4.setLength(0);
               } else {
                  var4.append(var6);
               }
            }

            return var3.toString();
         }
      }
   }

   public static String encodeWord(String var0) throws UnsupportedEncodingException {
      return encodeWord(var0, (String)null, (String)null);
   }

   public static String encodeWord(String var0, String var1, String var2) throws UnsupportedEncodingException {
      return encodeWord(var0, var1, var2, true);
   }

   private static String encodeWord(String var0, String var1, String var2, boolean var3) throws UnsupportedEncodingException {
      int var4 = checkAscii(var0);
      if (var4 == 1) {
         return var0;
      } else {
         String var5;
         if (var1 == null) {
            var5 = getDefaultJavaCharset();
            var1 = getDefaultMIMECharset();
         } else {
            var5 = javaCharset(var1);
         }

         if (var2 == null) {
            if (var4 != 3) {
               var2 = "Q";
            } else {
               var2 = "B";
            }
         }

         boolean var6;
         if (var2.equalsIgnoreCase("B")) {
            var6 = true;
         } else {
            if (!var2.equalsIgnoreCase("Q")) {
               throw new UnsupportedEncodingException("Unknown transfer encoding: " + var2);
            }

            var6 = false;
         }

         StringBuffer var7 = new StringBuffer();
         doEncode(var0, var6, var5, 68 - var1.length(), "=?" + var1 + "?" + var2 + "?", true, var3, var7);
         return var7.toString();
      }
   }

   private static void doEncode(String var0, boolean var1, String var2, int var3, String var4, boolean var5, boolean var6, StringBuffer var7) throws UnsupportedEncodingException {
      byte[] var8 = var0.getBytes(var2);
      int var9;
      if (var1) {
         var9 = BEncoderStream.encodedLength(var8);
      } else {
         var9 = QEncoderStream.encodedLength(var8, var6);
      }

      int var10;
      if (var9 > var3 && (var10 = var0.length()) > 1) {
         doEncode(var0.substring(0, var10 / 2), var1, var2, var3, var4, var5, var6, var7);
         doEncode(var0.substring(var10 / 2, var10), var1, var2, var3, var4, false, var6, var7);
      } else {
         ByteArrayOutputStream var11 = new ByteArrayOutputStream();
         Object var12;
         if (var1) {
            var12 = new BEncoderStream(var11);
         } else {
            var12 = new QEncoderStream(var11, var6);
         }

         try {
            ((OutputStream)var12).write(var8);
            ((OutputStream)var12).close();
         } catch (IOException var15) {
         }

         byte[] var13 = var11.toByteArray();
         if (!var5) {
            if (foldEncodedWords) {
               var7.append("\r\n ");
            } else {
               var7.append(" ");
            }
         }

         var7.append(var4);

         for(int var14 = 0; var14 < var13.length; ++var14) {
            var7.append((char)var13[var14]);
         }

         var7.append("?=");
      }

   }

   public static String decodeWord(String var0) throws ParseException, UnsupportedEncodingException {
      if (!var0.startsWith("=?")) {
         throw new ParseException();
      } else {
         byte var1 = 2;
         int var2;
         if ((var2 = var0.indexOf(63, var1)) == -1) {
            throw new ParseException();
         } else {
            String var3 = javaCharset(var0.substring(var1, var2));
            int var14 = var2 + 1;
            if ((var2 = var0.indexOf(63, var14)) == -1) {
               throw new ParseException();
            } else {
               String var4 = var0.substring(var14, var2);
               var14 = var2 + 1;
               if ((var2 = var0.indexOf("?=", var14)) == -1) {
                  throw new ParseException();
               } else {
                  String var5 = var0.substring(var14, var2);

                  try {
                     String var6;
                     if (var5.length() > 0) {
                        ByteArrayInputStream var7 = new ByteArrayInputStream(ASCIIUtility.getBytes(var5));
                        Object var8;
                        if (var4.equalsIgnoreCase("B")) {
                           var8 = new BASE64DecoderStream(var7);
                        } else {
                           if (!var4.equalsIgnoreCase("Q")) {
                              throw new UnsupportedEncodingException("unknown encoding: " + var4);
                           }

                           var8 = new QDecoderStream(var7);
                        }

                        int var9 = var7.available();
                        byte[] var10 = new byte[var9];
                        var9 = ((InputStream)var8).read(var10, 0, var9);
                        var6 = var9 <= 0 ? "" : new String(var10, 0, var9, var3);
                     } else {
                        var6 = "";
                     }

                     if (var2 + 2 < var0.length()) {
                        String var15 = var0.substring(var2 + 2);
                        if (!decodeStrict) {
                           var15 = decodeInnerWords(var15);
                        }

                        var6 = var6 + var15;
                     }

                     return var6;
                  } catch (UnsupportedEncodingException var11) {
                     throw var11;
                  } catch (IOException var12) {
                     throw new ParseException();
                  } catch (IllegalArgumentException var13) {
                     throw new UnsupportedEncodingException();
                  }
               }
            }
         }
      }
   }

   private static String decodeInnerWords(String var0) throws UnsupportedEncodingException {
      int var1 = 0;

      int var2;
      StringBuffer var3;
      int var4;
      for(var3 = new StringBuffer(); (var2 = var0.indexOf("=?", var1)) >= 0; var1 = var4 + 2) {
         var3.append(var0.substring(var1, var2));
         var4 = var0.indexOf("?=", var2);
         if (var4 < 0) {
            break;
         }

         String var5 = var0.substring(var2, var4 + 2);

         try {
            var5 = decodeWord(var5);
         } catch (ParseException var7) {
         }

         var3.append(var5);
      }

      if (var1 == 0) {
         return var0;
      } else {
         if (var1 < var0.length()) {
            var3.append(var0.substring(var1));
         }

         return var3.toString();
      }
   }

   public static String quote(String var0, String var1) {
      int var2 = var0.length();
      boolean var3 = false;

      for(int var4 = 0; var4 < var2; ++var4) {
         char var5 = var0.charAt(var4);
         if (var5 == '"' || var5 == '\\' || var5 == '\r' || var5 == '\n') {
            StringBuffer var6 = new StringBuffer(var2 + 3);
            var6.append('"');
            var6.append(var0.substring(0, var4));
            char var7 = 0;

            for(int var8 = var4; var8 < var2; ++var8) {
               char var9 = var0.charAt(var8);
               if ((var9 == '"' || var9 == '\\' || var9 == '\r' || var9 == '\n') && (var9 != '\n' || var7 != '\r')) {
                  var6.append('\\');
               }

               var6.append(var9);
               var7 = var9;
            }

            var6.append('"');
            return var6.toString();
         }

         if (var5 < ' ' || var5 >= 127 || var1.indexOf(var5) >= 0) {
            var3 = true;
         }
      }

      if (var3) {
         StringBuffer var10 = new StringBuffer(var2 + 2);
         var10.append('"').append(var0).append('"');
         return var10.toString();
      } else {
         return var0;
      }
   }

   public static String fold(int var0, String var1) {
      if (!foldText) {
         return var1;
      } else {
         int var2;
         char var3;
         for(var2 = var1.length() - 1; var2 >= 0; --var2) {
            var3 = var1.charAt(var2);
            if (var3 != ' ' && var3 != '\t' && var3 != '\r' && var3 != '\n') {
               break;
            }
         }

         if (var2 != var1.length() - 1) {
            var1 = var1.substring(0, var2 + 1);
         }

         if (var0 + var1.length() <= 76) {
            return var1;
         } else {
            StringBuffer var4 = new StringBuffer(var1.length() + 4);

            for(char var5 = 0; var0 + var1.length() > 76; var0 = 1) {
               int var6 = -1;

               for(int var7 = 0; var7 < var1.length() && (var6 == -1 || var0 + var7 <= 76); ++var7) {
                  var3 = var1.charAt(var7);
                  if ((var3 == ' ' || var3 == '\t') && var5 != ' ' && var5 != '\t') {
                     var6 = var7;
                  }

                  var5 = var3;
               }

               if (var6 == -1) {
                  var4.append(var1);
                  var1 = "";
                  boolean var8 = false;
                  break;
               }

               var4.append(var1.substring(0, var6));
               var4.append("\r\n");
               var5 = var1.charAt(var6);
               var4.append(var5);
               var1 = var1.substring(var6 + 1);
            }

            var4.append(var1);
            return var4.toString();
         }
      }
   }

   public static String unfold(String var0) {
      if (!foldText) {
         return var0;
      } else {
         StringBuffer var1 = null;

         while(true) {
            int var2;
            while((var2 = indexOfAny(var0, "\r\n")) >= 0) {
               int var3 = var2;
               int var4 = var0.length();
               ++var2;
               if (var2 < var4 && var0.charAt(var2 - 1) == '\r' && var0.charAt(var2) == '\n') {
                  ++var2;
               }

               if (var3 != 0 && var0.charAt(var3 - 1) == '\\') {
                  if (var1 == null) {
                     var1 = new StringBuffer(var0.length());
                  }

                  var1.append(var0.substring(0, var3 - 1));
                  var1.append(var0.substring(var3, var2));
                  var0 = var0.substring(var2);
               } else {
                  char var5;
                  if (var2 >= var4 || (var5 = var0.charAt(var2)) != ' ' && var5 != '\t') {
                     if (var1 == null) {
                        var1 = new StringBuffer(var0.length());
                     }

                     var1.append(var0.substring(0, var2));
                     var0 = var0.substring(var2);
                  } else {
                     ++var2;

                     while(var2 < var4 && ((var5 = var0.charAt(var2)) == ' ' || var5 == '\t')) {
                        ++var2;
                     }

                     if (var1 == null) {
                        var1 = new StringBuffer(var0.length());
                     }

                     if (var3 != 0) {
                        var1.append(var0.substring(0, var3));
                        var1.append(' ');
                     }

                     var0 = var0.substring(var2);
                  }
               }
            }

            if (var1 != null) {
               var1.append(var0);
               return var1.toString();
            }

            return var0;
         }
      }
   }

   private static int indexOfAny(String var0, String var1) {
      return indexOfAny(var0, var1, 0);
   }

   private static int indexOfAny(String var0, String var1, int var2) {
      try {
         int var3 = var0.length();

         for(int var4 = var2; var4 < var3; ++var4) {
            if (var1.indexOf(var0.charAt(var4)) >= 0) {
               return var4;
            }
         }

         return -1;
      } catch (StringIndexOutOfBoundsException var5) {
         return -1;
      }
   }

   public static String javaCharset(String var0) {
      if (mime2java != null && var0 != null) {
         String var1 = (String)mime2java.get(var0.toLowerCase());
         return var1 == null ? var0 : var1;
      } else {
         return var0;
      }
   }

   public static String mimeCharset(String var0) {
      if (java2mime != null && var0 != null) {
         String var1 = (String)java2mime.get(var0.toLowerCase());
         return var1 == null ? var0 : var1;
      } else {
         return var0;
      }
   }

   public static String getDefaultJavaCharset() {
      if (defaultJavaCharset == null) {
         String var0 = null;

         try {
            var0 = System.getProperty("mail.mime.charset");
         } catch (SecurityException var3) {
         }

         if (var0 != null && var0.length() > 0) {
            defaultJavaCharset = javaCharset(var0);
            return defaultJavaCharset;
         }

         try {
            defaultJavaCharset = System.getProperty("file.encoding", "8859_1");
         } catch (SecurityException var4) {
            class NullInputStream extends InputStream {
               public int read() {
                  return 0;
               }
            }

            InputStreamReader var2 = new InputStreamReader(new NullInputStream());
            defaultJavaCharset = var2.getEncoding();
            if (defaultJavaCharset == null) {
               defaultJavaCharset = "8859_1";
            }
         }
      }

      return defaultJavaCharset;
   }

   static String getDefaultMIMECharset() {
      if (defaultMIMECharset == null) {
         try {
            defaultMIMECharset = System.getProperty("mail.mime.charset");
         } catch (SecurityException var1) {
         }
      }

      if (defaultMIMECharset == null) {
         defaultMIMECharset = mimeCharset(getDefaultJavaCharset());
      }

      return defaultMIMECharset;
   }

   private static void loadMappings(LineInputStream var0, Hashtable var1) {
      while(true) {
         String var2;
         try {
            var2 = var0.readLine();
         } catch (IOException var7) {
            break;
         }

         if (var2 == null || var2.startsWith("--") && var2.endsWith("--")) {
            break;
         }

         if (var2.trim().length() != 0 && !var2.startsWith("#")) {
            StringTokenizer var3 = new StringTokenizer(var2, " \t");

            try {
               String var4 = var3.nextToken();
               String var5 = var3.nextToken();
               var1.put(var4.toLowerCase(), var5);
            } catch (NoSuchElementException var6) {
            }
         }
      }

   }

   static int checkAscii(String var0) {
      int var1 = 0;
      int var2 = 0;
      int var3 = var0.length();

      for(int var4 = 0; var4 < var3; ++var4) {
         if (nonascii(var0.charAt(var4))) {
            ++var2;
         } else {
            ++var1;
         }
      }

      if (var2 == 0) {
         return 1;
      } else if (var1 > var2) {
         return 2;
      } else {
         return 3;
      }
   }

   static int checkAscii(byte[] var0) {
      int var1 = 0;
      int var2 = 0;

      for(int var3 = 0; var3 < var0.length; ++var3) {
         if (nonascii(var0[var3] & 255)) {
            ++var2;
         } else {
            ++var1;
         }
      }

      if (var2 == 0) {
         return 1;
      } else if (var1 > var2) {
         return 2;
      } else {
         return 3;
      }
   }

   static int checkAscii(InputStream var0, int var1, boolean var2) {
      int var3 = 0;
      int var4 = 0;
      int var6 = 4096;
      int var7 = 0;
      boolean var8 = false;
      boolean var9 = false;
      boolean var10 = encodeEolStrict && var2;
      byte[] var11 = null;
      if (var1 != 0) {
         var6 = var1 == -1 ? 4096 : Math.min(var1, 4096);
         var11 = new byte[var6];
      }

      while(var1 != 0) {
         int var5;
         try {
            if ((var5 = var0.read(var11, 0, var6)) == -1) {
               break;
            }

            int var12 = 0;

            for(int var13 = 0; var13 < var5; ++var13) {
               int var14 = var11[var13] & 255;
               if (var10 && (var12 == 13 && var14 != 10 || var12 != 13 && var14 == 10)) {
                  var9 = true;
               }

               if (var14 != 13 && var14 != 10) {
                  ++var7;
                  if (var7 > 998) {
                     var8 = true;
                  }
               } else {
                  var7 = 0;
               }

               if (nonascii(var14)) {
                  if (var2) {
                     return 3;
                  }

                  ++var4;
               } else {
                  ++var3;
               }

               var12 = var14;
            }
         } catch (IOException var15) {
            break;
         }

         if (var1 != -1) {
            var1 -= var5;
         }
      }

      if (var1 == 0 && var2) {
         return 3;
      } else if (var4 == 0) {
         if (var9) {
            return 3;
         } else {
            return var8 ? 2 : 1;
         }
      } else {
         return var3 > var4 ? 2 : 3;
      }
   }

   static final boolean nonascii(int var0) {
      return var0 >= 127 || var0 < 32 && var0 != 13 && var0 != 10 && var0 != 9;
   }

   // $FF: synthetic method
   static Class class$(String var0) {
      try {
         return Class.forName(var0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

   static {
      try {
         String var0 = System.getProperty("mail.mime.decodetext.strict");
         decodeStrict = var0 == null || !var0.equalsIgnoreCase("false");
         var0 = System.getProperty("mail.mime.encodeeol.strict");
         encodeEolStrict = var0 != null && var0.equalsIgnoreCase("true");
         var0 = System.getProperty("mail.mime.foldencodedwords");
         foldEncodedWords = var0 != null && var0.equalsIgnoreCase("true");
         var0 = System.getProperty("mail.mime.foldtext");
         foldText = var0 == null || !var0.equalsIgnoreCase("false");
      } catch (SecurityException var12) {
      }

      java2mime = new Hashtable(40);
      mime2java = new Hashtable(10);

      try {
         Object var13 = (class$javax$mail$internet$MimeUtility == null ? (class$javax$mail$internet$MimeUtility = class$("javax.mail.internet.MimeUtility")) : class$javax$mail$internet$MimeUtility).getResourceAsStream("/META-INF/javamail.charset.map");
         if (var13 != null) {
            try {
               var13 = new LineInputStream((InputStream)var13);
               loadMappings((LineInputStream)var13, java2mime);
               loadMappings((LineInputStream)var13, mime2java);
            } finally {
               try {
                  ((InputStream)var13).close();
               } catch (Exception var9) {
               }

            }
         }
      } catch (Exception var11) {
      }

      if (java2mime.isEmpty()) {
         java2mime.put("8859_1", "ISO-8859-1");
         java2mime.put("iso8859_1", "ISO-8859-1");
         java2mime.put("iso8859-1", "ISO-8859-1");
         java2mime.put("8859_2", "ISO-8859-2");
         java2mime.put("iso8859_2", "ISO-8859-2");
         java2mime.put("iso8859-2", "ISO-8859-2");
         java2mime.put("8859_3", "ISO-8859-3");
         java2mime.put("iso8859_3", "ISO-8859-3");
         java2mime.put("iso8859-3", "ISO-8859-3");
         java2mime.put("8859_4", "ISO-8859-4");
         java2mime.put("iso8859_4", "ISO-8859-4");
         java2mime.put("iso8859-4", "ISO-8859-4");
         java2mime.put("8859_5", "ISO-8859-5");
         java2mime.put("iso8859_5", "ISO-8859-5");
         java2mime.put("iso8859-5", "ISO-8859-5");
         java2mime.put("8859_6", "ISO-8859-6");
         java2mime.put("iso8859_6", "ISO-8859-6");
         java2mime.put("iso8859-6", "ISO-8859-6");
         java2mime.put("8859_7", "ISO-8859-7");
         java2mime.put("iso8859_7", "ISO-8859-7");
         java2mime.put("iso8859-7", "ISO-8859-7");
         java2mime.put("8859_8", "ISO-8859-8");
         java2mime.put("iso8859_8", "ISO-8859-8");
         java2mime.put("iso8859-8", "ISO-8859-8");
         java2mime.put("8859_9", "ISO-8859-9");
         java2mime.put("iso8859_9", "ISO-8859-9");
         java2mime.put("iso8859-9", "ISO-8859-9");
         java2mime.put("sjis", "Shift_JIS");
         java2mime.put("jis", "ISO-2022-JP");
         java2mime.put("iso2022jp", "ISO-2022-JP");
         java2mime.put("euc_jp", "euc-jp");
         java2mime.put("koi8_r", "koi8-r");
         java2mime.put("euc_cn", "euc-cn");
         java2mime.put("euc_tw", "euc-tw");
         java2mime.put("euc_kr", "euc-kr");
      }

      if (mime2java.isEmpty()) {
         mime2java.put("iso-2022-cn", "ISO2022CN");
         mime2java.put("iso-2022-kr", "ISO2022KR");
         mime2java.put("utf-8", "UTF8");
         mime2java.put("utf8", "UTF8");
         mime2java.put("ja_jp.iso2022-7", "ISO2022JP");
         mime2java.put("ja_jp.eucjp", "EUCJIS");
         mime2java.put("euc-kr", "KSC5601");
         mime2java.put("euckr", "KSC5601");
         mime2java.put("us-ascii", "ISO-8859-1");
         mime2java.put("x-us-ascii", "ISO-8859-1");
      }

   }
}
