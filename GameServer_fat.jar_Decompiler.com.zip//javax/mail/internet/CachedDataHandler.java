package javax.mail.internet;

import javax.activation.DataHandler;

class CachedDataHandler extends DataHandler {
   public CachedDataHandler(Object var1, String var2) {
      super(var1, var2);
   }
}
