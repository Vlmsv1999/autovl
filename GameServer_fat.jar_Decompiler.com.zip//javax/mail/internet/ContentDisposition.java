package javax.mail.internet;

public class ContentDisposition {
   private String disposition;
   private ParameterList list;

   public ContentDisposition() {
   }

   public ContentDisposition(String var1, ParameterList var2) {
      this.disposition = var1;
      this.list = var2;
   }

   public ContentDisposition(String var1) throws ParseException {
      HeaderTokenizer var2 = new HeaderTokenizer(var1, "()<>@,;:\\\"\t []/?=");
      HeaderTokenizer.Token var3 = var2.next();
      if (var3.getType() != -1) {
         throw new ParseException();
      } else {
         this.disposition = var3.getValue();
         String var4 = var2.getRemainder();
         if (var4 != null) {
            this.list = new ParameterList(var4);
         }

      }
   }

   public String getDisposition() {
      return this.disposition;
   }

   public String getParameter(String var1) {
      return this.list == null ? null : this.list.get(var1);
   }

   public ParameterList getParameterList() {
      return this.list;
   }

   public void setDisposition(String var1) {
      this.disposition = var1;
   }

   public void setParameter(String var1, String var2) {
      if (this.list == null) {
         this.list = new ParameterList();
      }

      this.list.set(var1, var2);
   }

   public void setParameterList(ParameterList var1) {
      this.list = var1;
   }

   public String toString() {
      if (this.disposition == null) {
         return null;
      } else if (this.list == null) {
         return this.disposition;
      } else {
         StringBuffer var1 = new StringBuffer(this.disposition);
         var1.append(this.list.toString(var1.length() + 21));
         return var1.toString();
      }
   }
}
