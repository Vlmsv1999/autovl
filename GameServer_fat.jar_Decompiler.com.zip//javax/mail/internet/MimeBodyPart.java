package javax.mail.internet;

import com.sun.mail.util.ASCIIUtility;
import com.sun.mail.util.LineOutputStream;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.Enumeration;
import java.util.Vector;
import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;

public class MimeBodyPart extends BodyPart implements MimePart {
   private static boolean setDefaultTextCharset = true;
   private static boolean setContentTypeFileName = true;
   private static boolean encodeFileName = false;
   private static boolean decodeFileName = false;
   static boolean cacheMultipart = true;
   protected DataHandler dh;
   protected byte[] content;
   protected InputStream contentStream;
   protected InternetHeaders headers;

   public MimeBodyPart() {
      this.headers = new InternetHeaders();
   }

   public MimeBodyPart(InputStream var1) throws MessagingException {
      if (!(var1 instanceof ByteArrayInputStream) && !(var1 instanceof BufferedInputStream) && !(var1 instanceof SharedInputStream)) {
         var1 = new BufferedInputStream((InputStream)var1);
      }

      this.headers = new InternetHeaders((InputStream)var1);
      if (var1 instanceof SharedInputStream) {
         SharedInputStream var2 = (SharedInputStream)var1;
         this.contentStream = var2.newStream(var2.getPosition(), -1L);
      } else {
         try {
            this.content = ASCIIUtility.getBytes((InputStream)var1);
         } catch (IOException var3) {
            throw new MessagingException("Error reading input stream", var3);
         }
      }

   }

   public MimeBodyPart(InternetHeaders var1, byte[] var2) throws MessagingException {
      this.headers = var1;
      this.content = var2;
   }

   public int getSize() throws MessagingException {
      if (this.content != null) {
         return this.content.length;
      } else {
         if (this.contentStream != null) {
            try {
               int var1 = this.contentStream.available();
               if (var1 > 0) {
                  return var1;
               }
            } catch (IOException var2) {
            }
         }

         return -1;
      }
   }

   public int getLineCount() throws MessagingException {
      return -1;
   }

   public String getContentType() throws MessagingException {
      String var1 = this.getHeader("Content-Type", (String)null);
      if (var1 == null) {
         var1 = "text/plain";
      }

      return var1;
   }

   public boolean isMimeType(String var1) throws MessagingException {
      return isMimeType(this, var1);
   }

   public String getDisposition() throws MessagingException {
      return getDisposition(this);
   }

   public void setDisposition(String var1) throws MessagingException {
      setDisposition(this, var1);
   }

   public String getEncoding() throws MessagingException {
      return getEncoding(this);
   }

   public String getContentID() throws MessagingException {
      return this.getHeader("Content-Id", (String)null);
   }

   public void setContentID(String var1) throws MessagingException {
      if (var1 == null) {
         this.removeHeader("Content-ID");
      } else {
         this.setHeader("Content-ID", var1);
      }

   }

   public String getContentMD5() throws MessagingException {
      return this.getHeader("Content-MD5", (String)null);
   }

   public void setContentMD5(String var1) throws MessagingException {
      this.setHeader("Content-MD5", var1);
   }

   public String[] getContentLanguage() throws MessagingException {
      return getContentLanguage(this);
   }

   public void setContentLanguage(String[] var1) throws MessagingException {
      setContentLanguage(this, var1);
   }

   public String getDescription() throws MessagingException {
      return getDescription(this);
   }

   public void setDescription(String var1) throws MessagingException {
      this.setDescription(var1, (String)null);
   }

   public void setDescription(String var1, String var2) throws MessagingException {
      setDescription(this, var1, var2);
   }

   public String getFileName() throws MessagingException {
      return getFileName(this);
   }

   public void setFileName(String var1) throws MessagingException {
      setFileName(this, var1);
   }

   public InputStream getInputStream() throws IOException, MessagingException {
      return this.getDataHandler().getInputStream();
   }

   protected InputStream getContentStream() throws MessagingException {
      if (this.contentStream != null) {
         return ((SharedInputStream)this.contentStream).newStream(0L, -1L);
      } else if (this.content != null) {
         return new ByteArrayInputStream(this.content);
      } else {
         throw new MessagingException("No content");
      }
   }

   public InputStream getRawInputStream() throws MessagingException {
      return this.getContentStream();
   }

   public DataHandler getDataHandler() throws MessagingException {
      if (this.dh == null) {
         this.dh = new DataHandler(new MimePartDataSource(this));
      }

      return this.dh;
   }

   public Object getContent() throws IOException, MessagingException {
      Object var1 = this.getDataHandler().getContent();
      if (cacheMultipart && (var1 instanceof Multipart || var1 instanceof Message) && !(this.dh instanceof CachedDataHandler) && (this.content != null || this.contentStream != null)) {
         this.dh = createCachedDataHandler(var1, this.getContentType());
      }

      return var1;
   }

   public void setDataHandler(DataHandler var1) throws MessagingException {
      this.dh = var1;
      invalidateContentHeaders(this);
   }

   public void setContent(Object var1, String var2) throws MessagingException {
      if (var1 instanceof Multipart) {
         this.setContent((Multipart)var1);
      } else {
         this.setDataHandler(new DataHandler(var1, var2));
      }

   }

   public void setText(String var1) throws MessagingException {
      this.setText(var1, (String)null);
   }

   public void setText(String var1, String var2) throws MessagingException {
      setText(this, var1, var2, "plain");
   }

   public void setText(String var1, String var2, String var3) throws MessagingException {
      setText(this, var1, var2, var3);
   }

   public void setContent(Multipart var1) throws MessagingException {
      this.setDataHandler(new DataHandler(var1, var1.getContentType()));
      var1.setParent(this);
   }

   public void attachFile(File var1) throws IOException, MessagingException {
      FileDataSource var2 = new FileDataSource(var1);
      this.setDataHandler(new DataHandler(var2));
      this.setFileName(var2.getName());
   }

   public void attachFile(String var1) throws IOException, MessagingException {
      File var2 = new File(var1);
      this.attachFile(var2);
   }

   public void saveFile(File var1) throws IOException, MessagingException {
      BufferedOutputStream var2 = new BufferedOutputStream(new FileOutputStream(var1));
      InputStream var3 = this.getInputStream();

      try {
         byte[] var4 = new byte[8192];

         int var5;
         while((var5 = var3.read(var4)) > 0) {
            var2.write(var4, 0, var5);
         }
      } finally {
         try {
            if (var3 != null) {
               var3.close();
            }
         } catch (IOException var15) {
         }

         try {
            if (var2 != null) {
               var2.close();
            }
         } catch (IOException var14) {
         }

      }

   }

   public void saveFile(String var1) throws IOException, MessagingException {
      File var2 = new File(var1);
      this.saveFile(var2);
   }

   public void writeTo(OutputStream var1) throws IOException, MessagingException {
      writeTo(this, var1, (String[])null);
   }

   public String[] getHeader(String var1) throws MessagingException {
      return this.headers.getHeader(var1);
   }

   public String getHeader(String var1, String var2) throws MessagingException {
      return this.headers.getHeader(var1, var2);
   }

   public void setHeader(String var1, String var2) throws MessagingException {
      this.headers.setHeader(var1, var2);
   }

   public void addHeader(String var1, String var2) throws MessagingException {
      this.headers.addHeader(var1, var2);
   }

   public void removeHeader(String var1) throws MessagingException {
      this.headers.removeHeader(var1);
   }

   public Enumeration getAllHeaders() throws MessagingException {
      return this.headers.getAllHeaders();
   }

   public Enumeration getMatchingHeaders(String[] var1) throws MessagingException {
      return this.headers.getMatchingHeaders(var1);
   }

   public Enumeration getNonMatchingHeaders(String[] var1) throws MessagingException {
      return this.headers.getNonMatchingHeaders(var1);
   }

   public void addHeaderLine(String var1) throws MessagingException {
      this.headers.addHeaderLine(var1);
   }

   public Enumeration getAllHeaderLines() throws MessagingException {
      return this.headers.getAllHeaderLines();
   }

   public Enumeration getMatchingHeaderLines(String[] var1) throws MessagingException {
      return this.headers.getMatchingHeaderLines(var1);
   }

   public Enumeration getNonMatchingHeaderLines(String[] var1) throws MessagingException {
      return this.headers.getNonMatchingHeaderLines(var1);
   }

   protected void updateHeaders() throws MessagingException {
      updateHeaders(this);
   }

   static boolean isMimeType(MimePart var0, String var1) throws MessagingException {
      try {
         ContentType var2 = new ContentType(var0.getContentType());
         return var2.match(var1);
      } catch (ParseException var3) {
         return var0.getContentType().equalsIgnoreCase(var1);
      }
   }

   static void setText(MimePart var0, String var1, String var2, String var3) throws MessagingException {
      if (var2 == null) {
         if (MimeUtility.checkAscii(var1) != 1) {
            var2 = MimeUtility.getDefaultMIMECharset();
         } else {
            var2 = "us-ascii";
         }
      }

      var0.setContent(var1, "text/" + var3 + "; charset=" + MimeUtility.quote(var2, "()<>@,;:\\\"\t []/?="));
   }

   static String getDisposition(MimePart var0) throws MessagingException {
      String var1 = var0.getHeader("Content-Disposition", (String)null);
      if (var1 == null) {
         return null;
      } else {
         ContentDisposition var2 = new ContentDisposition(var1);
         return var2.getDisposition();
      }
   }

   static void setDisposition(MimePart var0, String var1) throws MessagingException {
      if (var1 == null) {
         var0.removeHeader("Content-Disposition");
      } else {
         String var2 = var0.getHeader("Content-Disposition", (String)null);
         if (var2 != null) {
            ContentDisposition var3 = new ContentDisposition(var2);
            var3.setDisposition(var1);
            var1 = var3.toString();
         }

         var0.setHeader("Content-Disposition", var1);
      }

   }

   static String getDescription(MimePart var0) throws MessagingException {
      String var1 = var0.getHeader("Content-Description", (String)null);
      if (var1 == null) {
         return null;
      } else {
         try {
            return MimeUtility.decodeText(MimeUtility.unfold(var1));
         } catch (UnsupportedEncodingException var3) {
            return var1;
         }
      }
   }

   static void setDescription(MimePart var0, String var1, String var2) throws MessagingException {
      if (var1 == null) {
         var0.removeHeader("Content-Description");
      } else {
         try {
            var0.setHeader("Content-Description", MimeUtility.fold(21, MimeUtility.encodeText(var1, var2, (String)null)));
         } catch (UnsupportedEncodingException var4) {
            throw new MessagingException("Encoding error", var4);
         }
      }
   }

   static String getFileName(MimePart var0) throws MessagingException {
      String var1 = null;
      String var2 = var0.getHeader("Content-Disposition", (String)null);
      if (var2 != null) {
         ContentDisposition var3 = new ContentDisposition(var2);
         var1 = var3.getParameter("filename");
      }

      if (var1 == null) {
         var2 = var0.getHeader("Content-Type", (String)null);
         if (var2 != null) {
            try {
               ContentType var6 = new ContentType(var2);
               var1 = var6.getParameter("name");
            } catch (ParseException var5) {
            }
         }
      }

      if (decodeFileName && var1 != null) {
         try {
            var1 = MimeUtility.decodeText(var1);
         } catch (UnsupportedEncodingException var4) {
            throw new MessagingException("Can't decode filename", var4);
         }
      }

      return var1;
   }

   static void setFileName(MimePart var0, String var1) throws MessagingException {
      if (encodeFileName && var1 != null) {
         try {
            var1 = MimeUtility.encodeText(var1);
         } catch (UnsupportedEncodingException var6) {
            throw new MessagingException("Can't encode filename", var6);
         }
      }

      String var2 = var0.getHeader("Content-Disposition", (String)null);
      ContentDisposition var3 = new ContentDisposition(var2 == null ? "attachment" : var2);
      var3.setParameter("filename", var1);
      var0.setHeader("Content-Disposition", var3.toString());
      if (setContentTypeFileName) {
         var2 = var0.getHeader("Content-Type", (String)null);
         if (var2 != null) {
            try {
               ContentType var4 = new ContentType(var2);
               var4.setParameter("name", var1);
               var0.setHeader("Content-Type", var4.toString());
            } catch (ParseException var5) {
            }
         }
      }

   }

   static String[] getContentLanguage(MimePart var0) throws MessagingException {
      String var1 = var0.getHeader("Content-Language", (String)null);
      if (var1 == null) {
         return null;
      } else {
         HeaderTokenizer var2 = new HeaderTokenizer(var1, "()<>@,;:\\\"\t []/?=");
         Vector var3 = new Vector();

         while(true) {
            HeaderTokenizer.Token var4 = var2.next();
            int var5 = var4.getType();
            if (var5 == -4) {
               if (var3.size() == 0) {
                  return null;
               }

               String[] var6 = new String[var3.size()];
               var3.copyInto(var6);
               return var6;
            }

            if (var5 == -1) {
               var3.addElement(var4.getValue());
            }
         }
      }
   }

   static void setContentLanguage(MimePart var0, String[] var1) throws MessagingException {
      StringBuffer var2 = new StringBuffer(var1[0]);

      for(int var3 = 1; var3 < var1.length; ++var3) {
         var2.append(',').append(var1[var3]);
      }

      var0.setHeader("Content-Language", var2.toString());
   }

   static String getEncoding(MimePart var0) throws MessagingException {
      String var1 = var0.getHeader("Content-Transfer-Encoding", (String)null);
      if (var1 == null) {
         return null;
      } else {
         var1 = var1.trim();
         if (!var1.equalsIgnoreCase("7bit") && !var1.equalsIgnoreCase("8bit") && !var1.equalsIgnoreCase("quoted-printable") && !var1.equalsIgnoreCase("binary") && !var1.equalsIgnoreCase("base64")) {
            HeaderTokenizer var2 = new HeaderTokenizer(var1, "()<>@,;:\\\"\t []/?=");

            HeaderTokenizer.Token var3;
            int var4;
            do {
               var3 = var2.next();
               var4 = var3.getType();
               if (var4 == -4) {
                  return var1;
               }
            } while(var4 != -1);

            return var3.getValue();
         } else {
            return var1;
         }
      }
   }

   static void setEncoding(MimePart var0, String var1) throws MessagingException {
      var0.setHeader("Content-Transfer-Encoding", var1);
   }

   static DataHandler createCachedDataHandler(Object var0, String var1) {
      return new CachedDataHandler(var0, var1);
   }

   static void updateHeaders(MimePart var0) throws MessagingException {
      DataHandler var1 = var0.getDataHandler();
      if (var1 != null) {
         try {
            String var2 = var1.getContentType();
            boolean var3 = false;
            boolean var4 = var0.getHeader("Content-Type") == null;
            ContentType var5 = new ContentType(var2);
            if (var5.match("multipart/*")) {
               var3 = true;
               Object var6 = var1.getContent();
               if (!(var6 instanceof MimeMultipart)) {
                  throw new MessagingException("MIME part of type \"" + var2 + "\" contains object of type " + var6.getClass().getName() + " instead of MimeMultipart");
               }

               ((MimeMultipart)var6).updateHeaders();
            } else if (var5.match("message/rfc822")) {
               var3 = true;
            }

            String var10;
            if (!var3) {
               if (var0.getHeader("Content-Transfer-Encoding") == null) {
                  setEncoding(var0, MimeUtility.getEncoding(var1));
               }

               if (var4 && setDefaultTextCharset && var5.match("text/*") && var5.getParameter("charset") == null) {
                  String var7 = var0.getEncoding();
                  if (var7 != null && var7.equalsIgnoreCase("7bit")) {
                     var10 = "us-ascii";
                  } else {
                     var10 = MimeUtility.getDefaultMIMECharset();
                  }

                  var5.setParameter("charset", var10);
                  var2 = var5.toString();
               }
            }

            if (var4) {
               var10 = var0.getHeader("Content-Disposition", (String)null);
               if (var10 != null) {
                  ContentDisposition var11 = new ContentDisposition(var10);
                  String var8 = var11.getParameter("filename");
                  if (var8 != null) {
                     var5.setParameter("name", var8);
                     var2 = var5.toString();
                  }
               }

               var0.setHeader("Content-Type", var2);
            }

         } catch (IOException var9) {
            throw new MessagingException("IOException updating headers", var9);
         }
      }
   }

   static void invalidateContentHeaders(MimePart var0) throws MessagingException {
      var0.removeHeader("Content-Type");
      var0.removeHeader("Content-Transfer-Encoding");
   }

   static void writeTo(MimePart var0, OutputStream var1, String[] var2) throws IOException, MessagingException {
      LineOutputStream var3 = null;
      if (var1 instanceof LineOutputStream) {
         var3 = (LineOutputStream)var1;
      } else {
         var3 = new LineOutputStream(var1);
      }

      Enumeration var4 = var0.getNonMatchingHeaderLines(var2);

      while(var4.hasMoreElements()) {
         var3.writeln((String)var4.nextElement());
      }

      var3.writeln();
      var1 = MimeUtility.encode(var1, var0.getEncoding());
      var0.getDataHandler().writeTo(var1);
      var1.flush();
   }

   static {
      try {
         String var0 = System.getProperty("mail.mime.setdefaulttextcharset");
         setDefaultTextCharset = var0 == null || !var0.equalsIgnoreCase("false");
         var0 = System.getProperty("mail.mime.setcontenttypefilename");
         setContentTypeFileName = var0 == null || !var0.equalsIgnoreCase("false");
         var0 = System.getProperty("mail.mime.encodefilename");
         encodeFileName = var0 != null && !var0.equalsIgnoreCase("false");
         var0 = System.getProperty("mail.mime.decodefilename");
         decodeFileName = var0 != null && !var0.equalsIgnoreCase("false");
         var0 = System.getProperty("mail.mime.cachemultipart");
         cacheMultipart = var0 == null || !var0.equalsIgnoreCase("false");
      } catch (SecurityException var1) {
      }

   }
}
