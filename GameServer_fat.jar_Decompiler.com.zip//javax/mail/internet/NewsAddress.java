package javax.mail.internet;

import java.util.StringTokenizer;
import java.util.Vector;
import javax.mail.Address;

public class NewsAddress extends Address {
   protected String newsgroup;
   protected String host;
   private static final long serialVersionUID = -4203797299824684143L;

   public NewsAddress() {
   }

   public NewsAddress(String var1) {
      this(var1, (String)null);
   }

   public NewsAddress(String var1, String var2) {
      this.newsgroup = var1;
      this.host = var2;
   }

   public String getType() {
      return "news";
   }

   public void setNewsgroup(String var1) {
      this.newsgroup = var1;
   }

   public String getNewsgroup() {
      return this.newsgroup;
   }

   public void setHost(String var1) {
      this.host = var1;
   }

   public String getHost() {
      return this.host;
   }

   public String toString() {
      return this.newsgroup;
   }

   public boolean equals(Object var1) {
      if (!(var1 instanceof NewsAddress)) {
         return false;
      } else {
         NewsAddress var2 = (NewsAddress)var1;
         return this.newsgroup.equals(var2.newsgroup) && (this.host == null && var2.host == null || this.host != null && var2.host != null && this.host.equalsIgnoreCase(var2.host));
      }
   }

   public int hashCode() {
      int var1 = 0;
      if (this.newsgroup != null) {
         var1 += this.newsgroup.hashCode();
      }

      if (this.host != null) {
         var1 += this.host.toLowerCase().hashCode();
      }

      return var1;
   }

   public static String toString(Address[] var0) {
      if (var0 != null && var0.length != 0) {
         StringBuffer var1 = new StringBuffer(((NewsAddress)var0[0]).toString());

         for(int var2 = 1; var2 < var0.length; ++var2) {
            var1.append(",").append(((NewsAddress)var0[var2]).toString());
         }

         return var1.toString();
      } else {
         return null;
      }
   }

   public static NewsAddress[] parse(String var0) throws AddressException {
      StringTokenizer var1 = new StringTokenizer(var0, ",");
      Vector var2 = new Vector();

      while(var1.hasMoreTokens()) {
         String var3 = var1.nextToken();
         var2.addElement(new NewsAddress(var3));
      }

      int var5 = var2.size();
      NewsAddress[] var4 = new NewsAddress[var5];
      if (var5 > 0) {
         var2.copyInto(var4);
      }

      return var4;
   }
}
