package javax.mail.internet;

class MailDateParser {
   int index = 0;
   char[] orig = null;

   public MailDateParser(char[] var1) {
      this.orig = var1;
   }

   public void skipUntilNumber() throws java.text.ParseException {
      try {
         while(true) {
            switch(this.orig[this.index]) {
            case '0':
            case '1':
            case '2':
            case '3':
            case '4':
            case '5':
            case '6':
            case '7':
            case '8':
            case '9':
               return;
            default:
               ++this.index;
            }
         }
      } catch (ArrayIndexOutOfBoundsException var2) {
         throw new java.text.ParseException("No Number Found", this.index);
      }
   }

   public void skipWhiteSpace() {
      int var1 = this.orig.length;

      while(this.index < var1) {
         switch(this.orig[this.index]) {
         case '\t':
         case '\n':
         case '\r':
         case ' ':
            ++this.index;
            break;
         default:
            return;
         }
      }

   }

   public int peekChar() throws java.text.ParseException {
      if (this.index < this.orig.length) {
         return this.orig[this.index];
      } else {
         throw new java.text.ParseException("No more characters", this.index);
      }
   }

   public void skipChar(char var1) throws java.text.ParseException {
      if (this.index < this.orig.length) {
         if (this.orig[this.index] == var1) {
            ++this.index;
         } else {
            throw new java.text.ParseException("Wrong char", this.index);
         }
      } else {
         throw new java.text.ParseException("No more characters", this.index);
      }
   }

   public boolean skipIfChar(char var1) throws java.text.ParseException {
      if (this.index < this.orig.length) {
         if (this.orig[this.index] == var1) {
            ++this.index;
            return true;
         } else {
            return false;
         }
      } else {
         throw new java.text.ParseException("No more characters", this.index);
      }
   }

   public int parseNumber() throws java.text.ParseException {
      int var1 = this.orig.length;
      boolean var2 = false;

      int var3;
      for(var3 = 0; this.index < var1; ++this.index) {
         switch(this.orig[this.index]) {
         case '0':
            var3 *= 10;
            var2 = true;
            break;
         case '1':
            var3 = var3 * 10 + 1;
            var2 = true;
            break;
         case '2':
            var3 = var3 * 10 + 2;
            var2 = true;
            break;
         case '3':
            var3 = var3 * 10 + 3;
            var2 = true;
            break;
         case '4':
            var3 = var3 * 10 + 4;
            var2 = true;
            break;
         case '5':
            var3 = var3 * 10 + 5;
            var2 = true;
            break;
         case '6':
            var3 = var3 * 10 + 6;
            var2 = true;
            break;
         case '7':
            var3 = var3 * 10 + 7;
            var2 = true;
            break;
         case '8':
            var3 = var3 * 10 + 8;
            var2 = true;
            break;
         case '9':
            var3 = var3 * 10 + 9;
            var2 = true;
            break;
         default:
            if (var2) {
               return var3;
            }

            throw new java.text.ParseException("No Number found", this.index);
         }
      }

      if (var2) {
         return var3;
      } else {
         throw new java.text.ParseException("No Number found", this.index);
      }
   }

   public int parseMonth() throws java.text.ParseException {
      try {
         char var1;
         switch(this.orig[this.index++]) {
         case 'A':
         case 'a':
            var1 = this.orig[this.index++];
            if (var1 != 'P' && var1 != 'p') {
               if (var1 == 'U' || var1 == 'u') {
                  var1 = this.orig[this.index++];
                  if (var1 == 'G' || var1 == 'g') {
                     return 7;
                  }
               }
            } else {
               var1 = this.orig[this.index++];
               if (var1 == 'R' || var1 == 'r') {
                  return 3;
               }
            }
         case 'B':
         case 'C':
         case 'E':
         case 'G':
         case 'H':
         case 'I':
         case 'K':
         case 'L':
         case 'P':
         case 'Q':
         case 'R':
         case 'T':
         case 'U':
         case 'V':
         case 'W':
         case 'X':
         case 'Y':
         case 'Z':
         case '[':
         case '\\':
         case ']':
         case '^':
         case '_':
         case '`':
         case 'b':
         case 'c':
         case 'e':
         case 'g':
         case 'h':
         case 'i':
         case 'k':
         case 'l':
         case 'p':
         case 'q':
         case 'r':
         default:
            break;
         case 'D':
         case 'd':
            var1 = this.orig[this.index++];
            if (var1 != 'E' && var1 != 'e') {
               break;
            }

            var1 = this.orig[this.index++];
            if (var1 != 'C' && var1 != 'c') {
               break;
            }

            return 11;
         case 'F':
         case 'f':
            var1 = this.orig[this.index++];
            if (var1 != 'E' && var1 != 'e') {
               break;
            }

            var1 = this.orig[this.index++];
            if (var1 != 'B' && var1 != 'b') {
               break;
            }

            return 1;
         case 'J':
         case 'j':
            switch(this.orig[this.index++]) {
            case 'A':
            case 'a':
               var1 = this.orig[this.index++];
               if (var1 != 'N' && var1 != 'n') {
                  throw new java.text.ParseException("Bad Month", this.index);
               }

               return 0;
            case 'U':
            case 'u':
               var1 = this.orig[this.index++];
               if (var1 != 'N' && var1 != 'n') {
                  if (var1 != 'L' && var1 != 'l') {
                     throw new java.text.ParseException("Bad Month", this.index);
                  }

                  return 6;
               }

               return 5;
            default:
               throw new java.text.ParseException("Bad Month", this.index);
            }
         case 'M':
         case 'm':
            var1 = this.orig[this.index++];
            if (var1 != 'A' && var1 != 'a') {
               break;
            }

            var1 = this.orig[this.index++];
            if (var1 != 'R' && var1 != 'r') {
               if (var1 != 'Y' && var1 != 'y') {
                  break;
               }

               return 4;
            }

            return 2;
         case 'N':
         case 'n':
            var1 = this.orig[this.index++];
            if (var1 != 'O' && var1 != 'o') {
               break;
            }

            var1 = this.orig[this.index++];
            if (var1 != 'V' && var1 != 'v') {
               break;
            }

            return 10;
         case 'O':
         case 'o':
            var1 = this.orig[this.index++];
            if (var1 != 'C' && var1 != 'c') {
               break;
            }

            var1 = this.orig[this.index++];
            if (var1 != 'T' && var1 != 't') {
               break;
            }

            return 9;
         case 'S':
         case 's':
            var1 = this.orig[this.index++];
            if (var1 == 'E' || var1 == 'e') {
               var1 = this.orig[this.index++];
               if (var1 == 'P' || var1 == 'p') {
                  return 8;
               }
            }
         }
      } catch (ArrayIndexOutOfBoundsException var3) {
      }

      throw new java.text.ParseException("Bad Month", this.index);
   }

   public int parseTimeZone() throws java.text.ParseException {
      if (this.index >= this.orig.length) {
         throw new java.text.ParseException("No more characters", this.index);
      } else {
         char var1 = this.orig[this.index];
         return var1 != '+' && var1 != '-' ? this.parseAlphaTimeZone() : this.parseNumericTimeZone();
      }
   }

   public int parseNumericTimeZone() throws java.text.ParseException {
      boolean var1 = false;
      char var2 = this.orig[this.index++];
      if (var2 == '+') {
         var1 = true;
      } else if (var2 != '-') {
         throw new java.text.ParseException("Bad Numeric TimeZone", this.index);
      }

      int var3 = this.parseNumber();
      int var4 = var3 / 100 * 60 + var3 % 100;
      return var1 ? -var4 : var4;
   }

   public int parseAlphaTimeZone() throws java.text.ParseException {
      boolean var1 = false;
      boolean var2 = false;

      char var3;
      int var6;
      try {
         switch(this.orig[this.index++]) {
         case 'C':
         case 'c':
            var6 = 360;
            var2 = true;
            break;
         case 'E':
         case 'e':
            var6 = 300;
            var2 = true;
            break;
         case 'G':
         case 'g':
            var3 = this.orig[this.index++];
            if (var3 == 'M' || var3 == 'm') {
               var3 = this.orig[this.index++];
               if (var3 == 'T' || var3 == 't') {
                  var6 = 0;
                  break;
               }
            }

            throw new java.text.ParseException("Bad Alpha TimeZone", this.index);
         case 'M':
         case 'm':
            var6 = 420;
            var2 = true;
            break;
         case 'P':
         case 'p':
            var6 = 480;
            var2 = true;
            break;
         case 'U':
         case 'u':
            var3 = this.orig[this.index++];
            if (var3 != 'T' && var3 != 't') {
               throw new java.text.ParseException("Bad Alpha TimeZone", this.index);
            }

            var6 = 0;
            break;
         default:
            throw new java.text.ParseException("Bad Alpha TimeZone", this.index);
         }
      } catch (ArrayIndexOutOfBoundsException var5) {
         throw new java.text.ParseException("Bad Alpha TimeZone", this.index);
      }

      if (var2) {
         var3 = this.orig[this.index++];
         if (var3 != 'S' && var3 != 's') {
            if (var3 == 'D' || var3 == 'd') {
               var3 = this.orig[this.index++];
               if (var3 != 'T' && var3 == 't') {
                  throw new java.text.ParseException("Bad Alpha TimeZone", this.index);
               }

               var6 -= 60;
            }
         } else {
            var3 = this.orig[this.index++];
            if (var3 != 'T' && var3 != 't') {
               throw new java.text.ParseException("Bad Alpha TimeZone", this.index);
            }
         }
      }

      return var6;
   }

   int getIndex() {
      return this.index;
   }
}
