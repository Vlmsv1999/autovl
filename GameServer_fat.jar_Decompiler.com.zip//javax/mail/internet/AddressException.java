package javax.mail.internet;

public class AddressException extends ParseException {
   protected String ref = null;
   protected int pos = -1;
   private static final long serialVersionUID = 9134583443539323120L;

   public AddressException() {
   }

   public AddressException(String var1) {
      super(var1);
   }

   public AddressException(String var1, String var2) {
      super(var1);
      this.ref = var2;
   }

   public AddressException(String var1, String var2, int var3) {
      super(var1);
      this.ref = var2;
      this.pos = var3;
   }

   public String getRef() {
      return this.ref;
   }

   public int getPos() {
      return this.pos;
   }

   public String toString() {
      String var1 = super.toString();
      if (this.ref == null) {
         return var1;
      } else {
         var1 = var1 + " in string ``" + this.ref + "''";
         return this.pos < 0 ? var1 : var1 + " at position " + this.pos;
      }
   }
}
