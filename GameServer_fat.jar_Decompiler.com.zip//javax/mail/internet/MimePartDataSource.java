package javax.mail.internet;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.UnknownServiceException;
import javax.activation.DataSource;
import javax.mail.MessageAware;
import javax.mail.MessageContext;
import javax.mail.MessagingException;

public class MimePartDataSource implements DataSource, MessageAware {
   protected MimePart part;
   private MessageContext context;
   private static boolean ignoreMultipartEncoding = true;

   public MimePartDataSource(MimePart var1) {
      this.part = var1;
   }

   public InputStream getInputStream() throws IOException {
      try {
         InputStream var1;
         if (this.part instanceof MimeBodyPart) {
            var1 = ((MimeBodyPart)this.part).getContentStream();
         } else {
            if (!(this.part instanceof MimeMessage)) {
               throw new MessagingException("Unknown part");
            }

            var1 = ((MimeMessage)this.part).getContentStream();
         }

         String var2 = restrictEncoding(this.part.getEncoding(), this.part);
         return var2 != null ? MimeUtility.decode(var1, var2) : var1;
      } catch (MessagingException var3) {
         throw new IOException(var3.getMessage());
      }
   }

   private static String restrictEncoding(String var0, MimePart var1) throws MessagingException {
      if (ignoreMultipartEncoding && var0 != null) {
         if (!var0.equalsIgnoreCase("7bit") && !var0.equalsIgnoreCase("8bit") && !var0.equalsIgnoreCase("binary")) {
            String var2 = var1.getContentType();
            if (var2 == null) {
               return var0;
            } else {
               try {
                  ContentType var3 = new ContentType(var2);
                  if (var3.match("multipart/*") || var3.match("message/*")) {
                     return null;
                  }
               } catch (ParseException var4) {
               }

               return var0;
            }
         } else {
            return var0;
         }
      } else {
         return var0;
      }
   }

   public OutputStream getOutputStream() throws IOException {
      throw new UnknownServiceException();
   }

   public String getContentType() {
      try {
         return this.part.getContentType();
      } catch (MessagingException var2) {
         return null;
      }
   }

   public String getName() {
      try {
         if (this.part instanceof MimeBodyPart) {
            return ((MimeBodyPart)this.part).getFileName();
         }
      } catch (MessagingException var2) {
      }

      return "";
   }

   public synchronized MessageContext getMessageContext() {
      if (this.context == null) {
         this.context = new MessageContext(this.part);
      }

      return this.context;
   }

   static {
      try {
         String var0 = System.getProperty("mail.mime.ignoremultipartencoding");
         ignoreMultipartEncoding = var0 == null || !var0.equalsIgnoreCase("false");
      } catch (SecurityException var1) {
      }

   }
}
