package javax.mail.internet;

public class ContentType {
   private String primaryType;
   private String subType;
   private ParameterList list;

   public ContentType() {
   }

   public ContentType(String var1, String var2, ParameterList var3) {
      this.primaryType = var1;
      this.subType = var2;
      this.list = var3;
   }

   public ContentType(String var1) throws ParseException {
      HeaderTokenizer var2 = new HeaderTokenizer(var1, "()<>@,;:\\\"\t []/?=");
      HeaderTokenizer.Token var3 = var2.next();
      if (var3.getType() != -1) {
         throw new ParseException();
      } else {
         this.primaryType = var3.getValue();
         var3 = var2.next();
         if ((char)var3.getType() != '/') {
            throw new ParseException();
         } else {
            var3 = var2.next();
            if (var3.getType() != -1) {
               throw new ParseException();
            } else {
               this.subType = var3.getValue();
               String var4 = var2.getRemainder();
               if (var4 != null) {
                  this.list = new ParameterList(var4);
               }

            }
         }
      }
   }

   public String getPrimaryType() {
      return this.primaryType;
   }

   public String getSubType() {
      return this.subType;
   }

   public String getBaseType() {
      return this.primaryType + '/' + this.subType;
   }

   public String getParameter(String var1) {
      return this.list == null ? null : this.list.get(var1);
   }

   public ParameterList getParameterList() {
      return this.list;
   }

   public void setPrimaryType(String var1) {
      this.primaryType = var1;
   }

   public void setSubType(String var1) {
      this.subType = var1;
   }

   public void setParameter(String var1, String var2) {
      if (this.list == null) {
         this.list = new ParameterList();
      }

      this.list.set(var1, var2);
   }

   public void setParameterList(ParameterList var1) {
      this.list = var1;
   }

   public String toString() {
      if (this.primaryType != null && this.subType != null) {
         StringBuffer var1 = new StringBuffer();
         var1.append(this.primaryType).append('/').append(this.subType);
         if (this.list != null) {
            var1.append(this.list.toString(var1.length() + 14));
         }

         return var1.toString();
      } else {
         return null;
      }
   }

   public boolean match(ContentType var1) {
      if (!this.primaryType.equalsIgnoreCase(var1.getPrimaryType())) {
         return false;
      } else {
         String var2 = var1.getSubType();
         if (this.subType.charAt(0) != '*' && var2.charAt(0) != '*') {
            return this.subType.equalsIgnoreCase(var2);
         } else {
            return true;
         }
      }
   }

   public boolean match(String var1) {
      try {
         return this.match(new ContentType(var1));
      } catch (ParseException var3) {
         return false;
      }
   }
}
