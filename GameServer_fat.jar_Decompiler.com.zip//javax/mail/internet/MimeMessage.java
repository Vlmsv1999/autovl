package javax.mail.internet;

import com.sun.mail.util.ASCIIUtility;
import com.sun.mail.util.LineOutputStream;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectStreamException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.Enumeration;
import java.util.Vector;
import javax.activation.DataHandler;
import javax.mail.Address;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.util.SharedByteArrayInputStream;

public class MimeMessage extends Message implements MimePart {
   protected DataHandler dh;
   protected byte[] content;
   protected InputStream contentStream;
   protected InternetHeaders headers;
   protected Flags flags;
   protected boolean modified;
   protected boolean saved;
   private static MailDateFormat mailDateFormat = new MailDateFormat();
   private boolean strict;
   private static final Flags answeredFlag;

   public MimeMessage(Session var1) {
      super(var1);
      this.modified = false;
      this.saved = false;
      this.strict = true;
      this.modified = true;
      this.headers = new InternetHeaders();
      this.flags = new Flags();
      this.initStrict();
   }

   public MimeMessage(Session var1, InputStream var2) throws MessagingException {
      super(var1);
      this.modified = false;
      this.saved = false;
      this.strict = true;
      this.flags = new Flags();
      this.initStrict();
      this.parse(var2);
      this.saved = true;
   }

   public MimeMessage(MimeMessage var1) throws MessagingException {
      super(var1.session);
      this.modified = false;
      this.saved = false;
      this.strict = true;
      this.flags = var1.getFlags();
      int var3 = var1.getSize();
      ByteArrayOutputStream var2;
      if (var3 > 0) {
         var2 = new ByteArrayOutputStream(var3);
      } else {
         var2 = new ByteArrayOutputStream();
      }

      try {
         this.strict = var1.strict;
         var1.writeTo(var2);
         var2.close();
         SharedByteArrayInputStream var4 = new SharedByteArrayInputStream(var2.toByteArray());
         this.parse(var4);
         var4.close();
         this.saved = true;
      } catch (IOException var5) {
         throw new MessagingException("IOException while copying message", var5);
      }
   }

   protected MimeMessage(Folder var1, int var2) {
      super(var1, var2);
      this.modified = false;
      this.saved = false;
      this.strict = true;
      this.flags = new Flags();
      this.saved = true;
      this.initStrict();
   }

   protected MimeMessage(Folder var1, InputStream var2, int var3) throws MessagingException {
      this(var1, var3);
      this.initStrict();
      this.parse(var2);
   }

   protected MimeMessage(Folder var1, InternetHeaders var2, byte[] var3, int var4) throws MessagingException {
      this(var1, var4);
      this.headers = var2;
      this.content = var3;
      this.initStrict();
   }

   private void initStrict() {
      if (this.session != null) {
         String var1 = this.session.getProperty("mail.mime.address.strict");
         this.strict = var1 == null || !var1.equalsIgnoreCase("false");
      }

   }

   protected void parse(InputStream var1) throws MessagingException {
      if (!(var1 instanceof ByteArrayInputStream) && !(var1 instanceof BufferedInputStream) && !(var1 instanceof SharedInputStream)) {
         var1 = new BufferedInputStream((InputStream)var1);
      }

      this.headers = this.createInternetHeaders((InputStream)var1);
      if (var1 instanceof SharedInputStream) {
         SharedInputStream var2 = (SharedInputStream)var1;
         this.contentStream = var2.newStream(var2.getPosition(), -1L);
      } else {
         try {
            this.content = ASCIIUtility.getBytes((InputStream)var1);
         } catch (IOException var3) {
            throw new MessagingException("IOException", var3);
         }
      }

      this.modified = false;
   }

   public Address[] getFrom() throws MessagingException {
      Address[] var1 = this.getAddressHeader("From");
      if (var1 == null) {
         var1 = this.getAddressHeader("Sender");
      }

      return var1;
   }

   public void setFrom(Address var1) throws MessagingException {
      if (var1 == null) {
         this.removeHeader("From");
      } else {
         this.setHeader("From", var1.toString());
      }

   }

   public void setFrom() throws MessagingException {
      InternetAddress var1 = InternetAddress.getLocalAddress(this.session);
      if (var1 != null) {
         this.setFrom(var1);
      } else {
         throw new MessagingException("No From address");
      }
   }

   public void addFrom(Address[] var1) throws MessagingException {
      this.addAddressHeader("From", var1);
   }

   public Address getSender() throws MessagingException {
      Address[] var1 = this.getAddressHeader("Sender");
      return var1 != null && var1.length != 0 ? var1[0] : null;
   }

   public void setSender(Address var1) throws MessagingException {
      if (var1 == null) {
         this.removeHeader("Sender");
      } else {
         this.setHeader("Sender", var1.toString());
      }

   }

   public Address[] getRecipients(Message.RecipientType var1) throws MessagingException {
      if (var1 == MimeMessage.RecipientType.NEWSGROUPS) {
         String var2 = this.getHeader("Newsgroups", ",");
         return var2 == null ? null : NewsAddress.parse(var2);
      } else {
         return this.getAddressHeader(this.getHeaderName(var1));
      }
   }

   public Address[] getAllRecipients() throws MessagingException {
      Address[] var1 = super.getAllRecipients();
      Address[] var2 = this.getRecipients(MimeMessage.RecipientType.NEWSGROUPS);
      if (var2 == null) {
         return var1;
      } else {
         int var3 = (var1 != null ? var1.length : 0) + (var2 != null ? var2.length : 0);
         Address[] var4 = new Address[var3];
         int var5 = 0;
         if (var1 != null) {
            System.arraycopy(var1, 0, var4, var5, var1.length);
            var5 += var1.length;
         }

         if (var2 != null) {
            System.arraycopy(var2, 0, var4, var5, var2.length);
            int var10000 = var5 + var2.length;
         }

         return var4;
      }
   }

   public void setRecipients(Message.RecipientType var1, Address[] var2) throws MessagingException {
      if (var1 == MimeMessage.RecipientType.NEWSGROUPS) {
         if (var2 != null && var2.length != 0) {
            this.setHeader("Newsgroups", NewsAddress.toString(var2));
         } else {
            this.removeHeader("Newsgroups");
         }
      } else {
         this.setAddressHeader(this.getHeaderName(var1), var2);
      }

   }

   public void setRecipients(Message.RecipientType var1, String var2) throws MessagingException {
      if (var1 == MimeMessage.RecipientType.NEWSGROUPS) {
         if (var2 != null && var2.length() != 0) {
            this.setHeader("Newsgroups", var2);
         } else {
            this.removeHeader("Newsgroups");
         }
      } else {
         this.setAddressHeader(this.getHeaderName(var1), InternetAddress.parse(var2));
      }

   }

   public void addRecipients(Message.RecipientType var1, Address[] var2) throws MessagingException {
      if (var1 == MimeMessage.RecipientType.NEWSGROUPS) {
         String var3 = NewsAddress.toString(var2);
         if (var3 != null) {
            this.addHeader("Newsgroups", var3);
         }
      } else {
         this.addAddressHeader(this.getHeaderName(var1), var2);
      }

   }

   public void addRecipients(Message.RecipientType var1, String var2) throws MessagingException {
      if (var1 == MimeMessage.RecipientType.NEWSGROUPS) {
         if (var2 != null && var2.length() != 0) {
            this.addHeader("Newsgroups", var2);
         }
      } else {
         this.addAddressHeader(this.getHeaderName(var1), InternetAddress.parse(var2));
      }

   }

   public Address[] getReplyTo() throws MessagingException {
      Address[] var1 = this.getAddressHeader("Reply-To");
      if (var1 == null) {
         var1 = this.getFrom();
      }

      return var1;
   }

   public void setReplyTo(Address[] var1) throws MessagingException {
      this.setAddressHeader("Reply-To", var1);
   }

   private Address[] getAddressHeader(String var1) throws MessagingException {
      String var2 = this.getHeader(var1, ",");
      return var2 == null ? null : InternetAddress.parseHeader(var2, this.strict);
   }

   private void setAddressHeader(String var1, Address[] var2) throws MessagingException {
      String var3 = InternetAddress.toString(var2);
      if (var3 == null) {
         this.removeHeader(var1);
      } else {
         this.setHeader(var1, var3);
      }

   }

   private void addAddressHeader(String var1, Address[] var2) throws MessagingException {
      String var3 = InternetAddress.toString(var2);
      if (var3 != null) {
         this.addHeader(var1, var3);
      }
   }

   public String getSubject() throws MessagingException {
      String var1 = this.getHeader("Subject", (String)null);
      if (var1 == null) {
         return null;
      } else {
         try {
            return MimeUtility.decodeText(MimeUtility.unfold(var1));
         } catch (UnsupportedEncodingException var3) {
            return var1;
         }
      }
   }

   public void setSubject(String var1) throws MessagingException {
      this.setSubject(var1, (String)null);
   }

   public void setSubject(String var1, String var2) throws MessagingException {
      if (var1 == null) {
         this.removeHeader("Subject");
      }

      try {
         this.setHeader("Subject", MimeUtility.fold(9, MimeUtility.encodeText(var1, var2, (String)null)));
      } catch (UnsupportedEncodingException var4) {
         throw new MessagingException("Encoding error", var4);
      }
   }

   public Date getSentDate() throws MessagingException {
      String var1 = this.getHeader("Date", (String)null);
      if (var1 != null) {
         try {
            MailDateFormat var2 = mailDateFormat;
            synchronized(var2) {
               Date var3 = mailDateFormat.parse(var1);
               return var3;
            }
         } catch (java.text.ParseException var6) {
            return null;
         }
      } else {
         return null;
      }
   }

   public void setSentDate(Date var1) throws MessagingException {
      if (var1 == null) {
         this.removeHeader("Date");
      } else {
         MailDateFormat var2 = mailDateFormat;
         synchronized(var2) {
            this.setHeader("Date", mailDateFormat.format(var1));
         }
      }

   }

   public Date getReceivedDate() throws MessagingException {
      return null;
   }

   public int getSize() throws MessagingException {
      if (this.content != null) {
         return this.content.length;
      } else {
         if (this.contentStream != null) {
            try {
               int var1 = this.contentStream.available();
               if (var1 > 0) {
                  return var1;
               }
            } catch (IOException var2) {
            }
         }

         return -1;
      }
   }

   public int getLineCount() throws MessagingException {
      return -1;
   }

   public String getContentType() throws MessagingException {
      String var1 = this.getHeader("Content-Type", (String)null);
      return var1 == null ? "text/plain" : var1;
   }

   public boolean isMimeType(String var1) throws MessagingException {
      return MimeBodyPart.isMimeType(this, var1);
   }

   public String getDisposition() throws MessagingException {
      return MimeBodyPart.getDisposition(this);
   }

   public void setDisposition(String var1) throws MessagingException {
      MimeBodyPart.setDisposition(this, var1);
   }

   public String getEncoding() throws MessagingException {
      return MimeBodyPart.getEncoding(this);
   }

   public String getContentID() throws MessagingException {
      return this.getHeader("Content-Id", (String)null);
   }

   public void setContentID(String var1) throws MessagingException {
      if (var1 == null) {
         this.removeHeader("Content-ID");
      } else {
         this.setHeader("Content-ID", var1);
      }

   }

   public String getContentMD5() throws MessagingException {
      return this.getHeader("Content-MD5", (String)null);
   }

   public void setContentMD5(String var1) throws MessagingException {
      this.setHeader("Content-MD5", var1);
   }

   public String getDescription() throws MessagingException {
      return MimeBodyPart.getDescription(this);
   }

   public void setDescription(String var1) throws MessagingException {
      this.setDescription(var1, (String)null);
   }

   public void setDescription(String var1, String var2) throws MessagingException {
      MimeBodyPart.setDescription(this, var1, var2);
   }

   public String[] getContentLanguage() throws MessagingException {
      return MimeBodyPart.getContentLanguage(this);
   }

   public void setContentLanguage(String[] var1) throws MessagingException {
      MimeBodyPart.setContentLanguage(this, var1);
   }

   public String getMessageID() throws MessagingException {
      return this.getHeader("Message-ID", (String)null);
   }

   public String getFileName() throws MessagingException {
      return MimeBodyPart.getFileName(this);
   }

   public void setFileName(String var1) throws MessagingException {
      MimeBodyPart.setFileName(this, var1);
   }

   private String getHeaderName(Message.RecipientType var1) throws MessagingException {
      String var2;
      if (var1 == Message.RecipientType.TO) {
         var2 = "To";
      } else if (var1 == Message.RecipientType.CC) {
         var2 = "Cc";
      } else if (var1 == Message.RecipientType.BCC) {
         var2 = "Bcc";
      } else {
         if (var1 != MimeMessage.RecipientType.NEWSGROUPS) {
            throw new MessagingException("Invalid Recipient Type");
         }

         var2 = "Newsgroups";
      }

      return var2;
   }

   public InputStream getInputStream() throws IOException, MessagingException {
      return this.getDataHandler().getInputStream();
   }

   protected InputStream getContentStream() throws MessagingException {
      if (this.contentStream != null) {
         return ((SharedInputStream)this.contentStream).newStream(0L, -1L);
      } else if (this.content != null) {
         return new SharedByteArrayInputStream(this.content);
      } else {
         throw new MessagingException("No content");
      }
   }

   public InputStream getRawInputStream() throws MessagingException {
      return this.getContentStream();
   }

   public synchronized DataHandler getDataHandler() throws MessagingException {
      if (this.dh == null) {
         this.dh = new DataHandler(new MimePartDataSource(this));
      }

      return this.dh;
   }

   public Object getContent() throws IOException, MessagingException {
      Object var1 = this.getDataHandler().getContent();
      if (MimeBodyPart.cacheMultipart && (var1 instanceof Multipart || var1 instanceof Message) && !(this.dh instanceof CachedDataHandler) && (this.content != null || this.contentStream != null)) {
         this.dh = MimeBodyPart.createCachedDataHandler(var1, this.getContentType());
      }

      return var1;
   }

   public synchronized void setDataHandler(DataHandler var1) throws MessagingException {
      this.dh = var1;
      MimeBodyPart.invalidateContentHeaders(this);
   }

   public void setContent(Object var1, String var2) throws MessagingException {
      this.setDataHandler(new DataHandler(var1, var2));
   }

   public void setText(String var1) throws MessagingException {
      this.setText(var1, (String)null);
   }

   public void setText(String var1, String var2) throws MessagingException {
      MimeBodyPart.setText(this, var1, var2, "plain");
   }

   public void setText(String var1, String var2, String var3) throws MessagingException {
      MimeBodyPart.setText(this, var1, var2, var3);
   }

   public void setContent(Multipart var1) throws MessagingException {
      this.setDataHandler(new DataHandler(var1, var1.getContentType()));
      var1.setParent(this);
   }

   public Message reply(boolean var1) throws MessagingException {
      MimeMessage var2 = this.createMimeMessage(this.session);
      String var3 = this.getHeader("Subject", (String)null);
      if (var3 != null) {
         if (!var3.regionMatches(true, 0, "Re: ", 0, 4)) {
            var3 = "Re: " + var3;
         }

         var2.setHeader("Subject", var3);
      }

      Address[] var4 = this.getReplyTo();
      var2.setRecipients(Message.RecipientType.TO, var4);
      if (var1) {
         Vector var5 = new Vector();
         InternetAddress var6 = InternetAddress.getLocalAddress(this.session);
         if (var6 != null) {
            var5.addElement(var6);
         }

         String var7 = null;
         if (this.session != null) {
            var7 = this.session.getProperty("mail.alternates");
         }

         if (var7 != null) {
            this.eliminateDuplicates(var5, InternetAddress.parse(var7, false));
         }

         String var8 = null;
         if (this.session != null) {
            var8 = this.session.getProperty("mail.replyallcc");
         }

         boolean var9 = var8 != null && var8.equalsIgnoreCase("true");
         this.eliminateDuplicates(var5, var4);
         var4 = this.getRecipients(Message.RecipientType.TO);
         var4 = this.eliminateDuplicates(var5, var4);
         if (var4 != null && var4.length > 0) {
            if (var9) {
               var2.addRecipients(Message.RecipientType.CC, var4);
            } else {
               var2.addRecipients(Message.RecipientType.TO, var4);
            }
         }

         var4 = this.getRecipients(Message.RecipientType.CC);
         var4 = this.eliminateDuplicates(var5, var4);
         if (var4 != null && var4.length > 0) {
            var2.addRecipients(Message.RecipientType.CC, var4);
         }

         var4 = this.getRecipients(MimeMessage.RecipientType.NEWSGROUPS);
         if (var4 != null && var4.length > 0) {
            var2.setRecipients(MimeMessage.RecipientType.NEWSGROUPS, (Address[])var4);
         }
      }

      String var11 = this.getHeader("Message-Id", (String)null);
      if (var11 != null) {
         var2.setHeader("In-Reply-To", var11);
      }

      try {
         this.setFlags(answeredFlag, true);
      } catch (MessagingException var10) {
      }

      return var2;
   }

   private Address[] eliminateDuplicates(Vector var1, Address[] var2) {
      if (var2 == null) {
         return null;
      } else {
         int var3 = 0;

         int var6;
         for(int var4 = 0; var4 < ((Object[])var2).length; ++var4) {
            boolean var5 = false;

            for(var6 = 0; var6 < var1.size(); ++var6) {
               if (((InternetAddress)var1.elementAt(var6)).equals(((Object[])var2)[var4])) {
                  var5 = true;
                  ++var3;
                  ((Object[])var2)[var4] = null;
                  break;
               }
            }

            if (!var5) {
               var1.addElement(((Object[])var2)[var4]);
            }
         }

         if (var3 != 0) {
            Object var8;
            if (var2 instanceof InternetAddress[]) {
               var8 = new InternetAddress[((Object[])var2).length - var3];
            } else {
               var8 = new Address[((Object[])var2).length - var3];
            }

            var6 = 0;

            for(int var7 = 0; var6 < ((Object[])var2).length; ++var6) {
               if (((Object[])var2)[var6] != null) {
                  ((Object[])var8)[var7++] = ((Object[])var2)[var6];
               }
            }

            var2 = var8;
         }

         return (Address[])var2;
      }
   }

   public void writeTo(OutputStream var1) throws IOException, MessagingException {
      this.writeTo(var1, (String[])null);
   }

   public void writeTo(OutputStream var1, String[] var2) throws IOException, MessagingException {
      if (!this.saved) {
         this.saveChanges();
      }

      if (this.modified) {
         MimeBodyPart.writeTo(this, var1, var2);
      } else {
         Enumeration var3 = this.getNonMatchingHeaderLines(var2);
         LineOutputStream var4 = new LineOutputStream(var1);

         while(var3.hasMoreElements()) {
            var4.writeln((String)var3.nextElement());
         }

         var4.writeln();
         if (this.content == null) {
            InputStream var5 = this.getContentStream();
            byte[] var6 = new byte[8192];

            int var7;
            while((var7 = var5.read(var6)) > 0) {
               var1.write(var6, 0, var7);
            }

            var5.close();
            Object var8 = null;
         } else {
            var1.write(this.content);
         }

         var1.flush();
      }
   }

   public String[] getHeader(String var1) throws MessagingException {
      return this.headers.getHeader(var1);
   }

   public String getHeader(String var1, String var2) throws MessagingException {
      return this.headers.getHeader(var1, var2);
   }

   public void setHeader(String var1, String var2) throws MessagingException {
      this.headers.setHeader(var1, var2);
   }

   public void addHeader(String var1, String var2) throws MessagingException {
      this.headers.addHeader(var1, var2);
   }

   public void removeHeader(String var1) throws MessagingException {
      this.headers.removeHeader(var1);
   }

   public Enumeration getAllHeaders() throws MessagingException {
      return this.headers.getAllHeaders();
   }

   public Enumeration getMatchingHeaders(String[] var1) throws MessagingException {
      return this.headers.getMatchingHeaders(var1);
   }

   public Enumeration getNonMatchingHeaders(String[] var1) throws MessagingException {
      return this.headers.getNonMatchingHeaders(var1);
   }

   public void addHeaderLine(String var1) throws MessagingException {
      this.headers.addHeaderLine(var1);
   }

   public Enumeration getAllHeaderLines() throws MessagingException {
      return this.headers.getAllHeaderLines();
   }

   public Enumeration getMatchingHeaderLines(String[] var1) throws MessagingException {
      return this.headers.getMatchingHeaderLines(var1);
   }

   public Enumeration getNonMatchingHeaderLines(String[] var1) throws MessagingException {
      return this.headers.getNonMatchingHeaderLines(var1);
   }

   public synchronized Flags getFlags() throws MessagingException {
      return (Flags)this.flags.clone();
   }

   public synchronized boolean isSet(Flags.Flag var1) throws MessagingException {
      return this.flags.contains(var1);
   }

   public synchronized void setFlags(Flags var1, boolean var2) throws MessagingException {
      if (var2) {
         this.flags.add(var1);
      } else {
         this.flags.remove(var1);
      }

   }

   public void saveChanges() throws MessagingException {
      this.modified = true;
      this.saved = true;
      this.updateHeaders();
   }

   protected void updateMessageID() throws MessagingException {
      this.setHeader("Message-ID", "<" + UniqueValue.getUniqueMessageIDValue(this.session) + ">");
   }

   protected void updateHeaders() throws MessagingException {
      MimeBodyPart.updateHeaders(this);
      this.setHeader("MIME-Version", "1.0");
      this.updateMessageID();
   }

   protected InternetHeaders createInternetHeaders(InputStream var1) throws MessagingException {
      return new InternetHeaders(var1);
   }

   protected MimeMessage createMimeMessage(Session var1) throws MessagingException {
      return new MimeMessage(var1);
   }

   static {
      answeredFlag = new Flags(Flags.Flag.ANSWERED);
   }

   public static class RecipientType extends Message.RecipientType {
      private static final long serialVersionUID = -5468290701714395543L;
      public static final MimeMessage.RecipientType NEWSGROUPS = new MimeMessage.RecipientType("Newsgroups");

      protected RecipientType(String var1) {
         super(var1);
      }

      protected Object readResolve() throws ObjectStreamException {
         return this.type.equals("Newsgroups") ? NEWSGROUPS : super.readResolve();
      }
   }
}
