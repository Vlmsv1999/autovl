package javax.mail.internet;

import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.StringTokenizer;
import java.util.Vector;
import javax.mail.Address;
import javax.mail.Session;

public class InternetAddress extends Address implements Cloneable {
   protected String address;
   protected String personal;
   protected String encodedPersonal;
   private static final long serialVersionUID = -7507595530758302903L;
   private static final String rfc822phrase = "()<>@,;:\\\"\t .[]".replace(' ', '\u0000').replace('\t', '\u0000');
   private static final String specialsNoDotNoAt = "()<>,;:\\\"[]";
   private static final String specialsNoDot = "()<>,;:\\\"[]@";

   public InternetAddress() {
   }

   public InternetAddress(String var1) throws AddressException {
      InternetAddress[] var2 = parse(var1, true);
      if (var2.length != 1) {
         throw new AddressException("Illegal address", var1);
      } else {
         this.address = var2[0].address;
         this.personal = var2[0].personal;
         this.encodedPersonal = var2[0].encodedPersonal;
      }
   }

   public InternetAddress(String var1, boolean var2) throws AddressException {
      this(var1);
      if (var2) {
         checkAddress(this.address, true, true);
      }

   }

   public InternetAddress(String var1, String var2) throws UnsupportedEncodingException {
      this(var1, var2, (String)null);
   }

   public InternetAddress(String var1, String var2, String var3) throws UnsupportedEncodingException {
      this.address = var1;
      this.setPersonal(var2, var3);
   }

   public Object clone() {
      InternetAddress var1 = null;

      try {
         var1 = (InternetAddress)super.clone();
      } catch (CloneNotSupportedException var3) {
      }

      return var1;
   }

   public String getType() {
      return "rfc822";
   }

   public void setAddress(String var1) {
      this.address = var1;
   }

   public void setPersonal(String var1, String var2) throws UnsupportedEncodingException {
      this.personal = var1;
      if (var1 != null) {
         this.encodedPersonal = MimeUtility.encodeWord(var1, var2, (String)null);
      } else {
         this.encodedPersonal = null;
      }

   }

   public void setPersonal(String var1) throws UnsupportedEncodingException {
      this.personal = var1;
      if (var1 != null) {
         this.encodedPersonal = MimeUtility.encodeWord(var1);
      } else {
         this.encodedPersonal = null;
      }

   }

   public String getAddress() {
      return this.address;
   }

   public String getPersonal() {
      if (this.personal != null) {
         return this.personal;
      } else if (this.encodedPersonal != null) {
         try {
            this.personal = MimeUtility.decodeText(this.encodedPersonal);
            return this.personal;
         } catch (Exception var2) {
            return this.encodedPersonal;
         }
      } else {
         return null;
      }
   }

   public String toString() {
      if (this.encodedPersonal == null && this.personal != null) {
         try {
            this.encodedPersonal = MimeUtility.encodeWord(this.personal);
         } catch (UnsupportedEncodingException var2) {
         }
      }

      if (this.encodedPersonal != null) {
         return quotePhrase(this.encodedPersonal) + " <" + this.address + ">";
      } else {
         return !this.isGroup() && !this.isSimple() ? "<" + this.address + ">" : this.address;
      }
   }

   public String toUnicodeString() {
      String var1 = this.getPersonal();
      if (var1 != null) {
         return quotePhrase(var1) + " <" + this.address + ">";
      } else {
         return !this.isGroup() && !this.isSimple() ? "<" + this.address + ">" : this.address;
      }
   }

   private static String quotePhrase(String var0) {
      int var1 = var0.length();
      boolean var2 = false;

      for(int var3 = 0; var3 < var1; ++var3) {
         char var4 = var0.charAt(var3);
         if (var4 == '"' || var4 == '\\') {
            StringBuffer var5 = new StringBuffer(var1 + 3);
            var5.append('"');

            for(int var6 = 0; var6 < var1; ++var6) {
               char var7 = var0.charAt(var6);
               if (var7 == '"' || var7 == '\\') {
                  var5.append('\\');
               }

               var5.append(var7);
            }

            var5.append('"');
            return var5.toString();
         }

         if (var4 < ' ' && var4 != '\r' && var4 != '\n' && var4 != '\t' || var4 >= 127 || rfc822phrase.indexOf(var4) >= 0) {
            var2 = true;
         }
      }

      if (var2) {
         StringBuffer var8 = new StringBuffer(var1 + 2);
         var8.append('"').append(var0).append('"');
         return var8.toString();
      } else {
         return var0;
      }
   }

   private static String unquote(String var0) {
      if (var0.startsWith("\"") && var0.endsWith("\"")) {
         var0 = var0.substring(1, var0.length() - 1);
         if (var0.indexOf(92) >= 0) {
            StringBuffer var1 = new StringBuffer(var0.length());

            for(int var2 = 0; var2 < var0.length(); ++var2) {
               char var3 = var0.charAt(var2);
               if (var3 == '\\' && var2 < var0.length() - 1) {
                  ++var2;
                  var3 = var0.charAt(var2);
               }

               var1.append(var3);
            }

            var0 = var1.toString();
         }
      }

      return var0;
   }

   public boolean equals(Object var1) {
      if (!(var1 instanceof InternetAddress)) {
         return false;
      } else {
         String var2 = ((InternetAddress)var1).getAddress();
         if (var2 == this.address) {
            return true;
         } else {
            return this.address != null && this.address.equalsIgnoreCase(var2);
         }
      }
   }

   public int hashCode() {
      return this.address == null ? 0 : this.address.toLowerCase().hashCode();
   }

   public static String toString(Address[] var0) {
      return toString(var0, 0);
   }

   public static String toString(Address[] var0, int var1) {
      if (var0 != null && var0.length != 0) {
         StringBuffer var2 = new StringBuffer();

         for(int var3 = 0; var3 < var0.length; ++var3) {
            if (var3 != 0) {
               var2.append(", ");
               var1 += 2;
            }

            String var4 = var0[var3].toString();
            int var5 = lengthOfFirstSegment(var4);
            if (var1 + var5 > 76) {
               var2.append("\r\n\t");
               var1 = 8;
            }

            var2.append(var4);
            var1 = lengthOfLastSegment(var4, var1);
         }

         return var2.toString();
      } else {
         return null;
      }
   }

   private static int lengthOfFirstSegment(String var0) {
      int var1;
      return (var1 = var0.indexOf("\r\n")) != -1 ? var1 : var0.length();
   }

   private static int lengthOfLastSegment(String var0, int var1) {
      int var2;
      return (var2 = var0.lastIndexOf("\r\n")) != -1 ? var0.length() - var2 - 2 : var0.length() + var1;
   }

   public static InternetAddress getLocalAddress(Session var0) {
      String var1 = null;
      String var2 = null;
      String var3 = null;

      try {
         if (var0 == null) {
            var1 = System.getProperty("user.name");
            var2 = InetAddress.getLocalHost().getHostName();
         } else {
            var3 = var0.getProperty("mail.from");
            if (var3 == null) {
               var1 = var0.getProperty("mail.user");
               if (var1 == null || var1.length() == 0) {
                  var1 = var0.getProperty("user.name");
               }

               if (var1 == null || var1.length() == 0) {
                  var1 = System.getProperty("user.name");
               }

               var2 = var0.getProperty("mail.host");
               if (var2 == null || var2.length() == 0) {
                  InetAddress var4 = InetAddress.getLocalHost();
                  if (var4 != null) {
                     var2 = var4.getHostName();
                  }
               }
            }
         }

         if (var3 == null && var1 != null && var1.length() != 0 && var2 != null && var2.length() != 0) {
            var3 = var1 + "@" + var2;
         }

         if (var3 != null) {
            return new InternetAddress(var3);
         }
      } catch (SecurityException var7) {
      } catch (AddressException var8) {
      } catch (UnknownHostException var9) {
      }

      return null;
   }

   public static InternetAddress[] parse(String var0) throws AddressException {
      return parse(var0, true);
   }

   public static InternetAddress[] parse(String var0, boolean var1) throws AddressException {
      return parse(var0, var1, false);
   }

   public static InternetAddress[] parseHeader(String var0, boolean var1) throws AddressException {
      return parse(var0, var1, true);
   }

   private static InternetAddress[] parse(String var0, boolean var1, boolean var2) throws AddressException {
      int var7 = -1;
      int var8 = -1;
      int var9 = var0.length();
      boolean var10 = false;
      boolean var11 = false;
      boolean var12 = false;
      Vector var14 = new Vector();
      int var4 = -1;
      int var3 = -1;

      int var5;
      InternetAddress var15;
      for(var5 = 0; var5 < var9; ++var5) {
         char var13 = var0.charAt(var5);
         switch(var13) {
         case '\t':
         case '\n':
         case '\r':
         case ' ':
            break;
         case '"':
            var12 = true;
            if (var3 == -1) {
               var3 = var5;
            }

            ++var5;

            label214:
            while(var5 < var9) {
               var13 = var0.charAt(var5);
               switch(var13) {
               case '"':
                  break label214;
               case '\\':
                  ++var5;
               default:
                  ++var5;
               }
            }

            if (var5 >= var9) {
               throw new AddressException("Missing '\"'", var0, var5);
            }
            break;
         case '(':
            var12 = true;
            if (var3 >= 0 && var4 == -1) {
               var4 = var5;
            }

            if (var7 == -1) {
               var7 = var5 + 1;
            }

            ++var5;

            int var6;
            for(var6 = 1; var5 < var9 && var6 > 0; ++var5) {
               var13 = var0.charAt(var5);
               switch(var13) {
               case '(':
                  ++var6;
                  break;
               case ')':
                  --var6;
                  break;
               case '\\':
                  ++var5;
               }
            }

            if (var6 > 0) {
               throw new AddressException("Missing ')'", var0, var5);
            }

            --var5;
            if (var8 == -1) {
               var8 = var5;
            }
            break;
         case ')':
            throw new AddressException("Missing '('", var0, var5);
         case ',':
            if (var3 == -1) {
               var11 = false;
               var12 = false;
               var4 = -1;
               var3 = -1;
            } else if (var10) {
               var11 = false;
            } else {
               if (var4 == -1) {
                  var4 = var5;
               }

               String var17 = var0.substring(var3, var4).trim();
               if (!var12 && !var1 && !var2) {
                  StringTokenizer var18 = new StringTokenizer(var17);

                  while(var18.hasMoreTokens()) {
                     String var19 = var18.nextToken();
                     checkAddress(var19, false, false);
                     var15 = new InternetAddress();
                     var15.setAddress(var19);
                     var14.addElement(var15);
                  }
               } else {
                  if (var1 || !var2) {
                     checkAddress(var17, var11, false);
                  }

                  var15 = new InternetAddress();
                  var15.setAddress(var17);
                  if (var7 >= 0) {
                     var15.encodedPersonal = unquote(var0.substring(var7, var8).trim());
                     var8 = -1;
                     var7 = -1;
                  }

                  var14.addElement(var15);
               }

               var11 = false;
               var12 = false;
               var4 = -1;
               var3 = -1;
            }
            break;
         case ':':
            var12 = true;
            if (var10) {
               throw new AddressException("Nested group", var0, var5);
            }

            var10 = true;
            if (var3 == -1) {
               var3 = var5;
            }
            break;
         case ';':
            if (var3 == -1) {
               var3 = var5;
            }

            if (!var10) {
               throw new AddressException("Illegal semicolon, not in group", var0, var5);
            }

            var10 = false;
            if (var3 == -1) {
               var3 = var5;
            }

            var15 = new InternetAddress();
            var4 = var5 + 1;
            var15.setAddress(var0.substring(var3, var4).trim());
            var14.addElement(var15);
            var11 = false;
            var4 = -1;
            var3 = -1;
            break;
         case '<':
            var12 = true;
            if (var11) {
               throw new AddressException("Extra route-addr", var0, var5);
            }

            if (!var10) {
               var7 = var3;
               if (var3 >= 0) {
                  var8 = var5;
               }

               var3 = var5 + 1;
            }

            boolean var16 = false;
            ++var5;

            label196:
            for(; var5 < var9; ++var5) {
               var13 = var0.charAt(var5);
               switch(var13) {
               case '"':
                  var16 = !var16;
                  break;
               case '>':
                  if (!var16) {
                     break label196;
                  }
                  break;
               case '\\':
                  ++var5;
               }
            }

            if (var5 >= var9) {
               if (var16) {
                  throw new AddressException("Missing '\"'", var0, var5);
               }

               throw new AddressException("Missing '>'", var0, var5);
            }

            var11 = true;
            var4 = var5;
            break;
         case '>':
            throw new AddressException("Missing '<'", var0, var5);
         case '[':
            var12 = true;
            ++var5;

            label205:
            while(var5 < var9) {
               var13 = var0.charAt(var5);
               switch(var13) {
               case '\\':
                  ++var5;
               default:
                  ++var5;
                  break;
               case ']':
                  break label205;
               }
            }

            if (var5 >= var9) {
               throw new AddressException("Missing ']'", var0, var5);
            }
            break;
         default:
            if (var3 == -1) {
               var3 = var5;
            }
         }
      }

      if (var3 >= 0) {
         if (var4 == -1) {
            var4 = var5;
         }

         String var20 = var0.substring(var3, var4).trim();
         if (!var12 && !var1 && !var2) {
            StringTokenizer var22 = new StringTokenizer(var20);

            while(var22.hasMoreTokens()) {
               String var23 = var22.nextToken();
               checkAddress(var23, false, false);
               var15 = new InternetAddress();
               var15.setAddress(var23);
               var14.addElement(var15);
            }
         } else {
            if (var1 || !var2) {
               checkAddress(var20, var11, false);
            }

            var15 = new InternetAddress();
            var15.setAddress(var20);
            if (var7 >= 0) {
               var15.encodedPersonal = unquote(var0.substring(var7, var8).trim());
            }

            var14.addElement(var15);
         }
      }

      InternetAddress[] var21 = new InternetAddress[var14.size()];
      var14.copyInto(var21);
      return var21;
   }

   public void validate() throws AddressException {
      checkAddress(this.getAddress(), true, true);
   }

   private static void checkAddress(String var0, boolean var1, boolean var2) throws AddressException {
      int var4 = 0;
      if (var0.indexOf(34) < 0) {
         int var3;
         if (var1) {
            for(var4 = 0; (var3 = indexOfAny(var0, ",:", var4)) >= 0; var4 = var3 + 1) {
               if (var0.charAt(var4) != '@') {
                  throw new AddressException("Illegal route-addr", var0);
               }

               if (var0.charAt(var3) == ':') {
                  var4 = var3 + 1;
                  break;
               }
            }
         }

         String var5;
         String var6;
         if ((var3 = var0.indexOf(64, var4)) >= 0) {
            if (var3 == var4) {
               throw new AddressException("Missing local name", var0);
            }

            if (var3 == var0.length() - 1) {
               throw new AddressException("Missing domain", var0);
            }

            var5 = var0.substring(var4, var3);
            var6 = var0.substring(var3 + 1);
         } else {
            if (var2) {
               throw new AddressException("Missing final '@domain'", var0);
            }

            var5 = var0;
            var6 = null;
         }

         if (indexOfAny(var0, " \t\n\r") >= 0) {
            throw new AddressException("Illegal whitespace in address", var0);
         } else if (indexOfAny(var5, "()<>,;:\\\"[]@") >= 0) {
            throw new AddressException("Illegal character in local name", var0);
         } else if (var6 != null && var6.indexOf(91) < 0 && indexOfAny(var6, "()<>,;:\\\"[]@") >= 0) {
            throw new AddressException("Illegal character in domain", var0);
         }
      }
   }

   private boolean isSimple() {
      return this.address == null || indexOfAny(this.address, "()<>,;:\\\"[]") < 0;
   }

   public boolean isGroup() {
      return this.address != null && this.address.endsWith(";") && this.address.indexOf(58) > 0;
   }

   public InternetAddress[] getGroup(boolean var1) throws AddressException {
      Object var2 = null;
      String var3 = this.getAddress();
      if (!var3.endsWith(";")) {
         return null;
      } else {
         int var4 = var3.indexOf(58);
         if (var4 < 0) {
            return null;
         } else {
            String var5 = var3.substring(var4 + 1, var3.length() - 1);
            return parseHeader(var5, var1);
         }
      }
   }

   private static int indexOfAny(String var0, String var1) {
      return indexOfAny(var0, var1, 0);
   }

   private static int indexOfAny(String var0, String var1, int var2) {
      try {
         int var3 = var0.length();

         for(int var4 = var2; var4 < var3; ++var4) {
            if (var1.indexOf(var0.charAt(var4)) >= 0) {
               return var4;
            }
         }

         return -1;
      } catch (StringIndexOutOfBoundsException var5) {
         return -1;
      }
   }
}
