package javax.mail.internet;

import java.io.UnsupportedEncodingException;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

public class ParameterList {
   private Map list = new LinkedHashMap();
   private static boolean encodeParameters = false;
   private static boolean decodeParameters = false;
   private static boolean decodeParametersStrict = false;
   private static final char[] hex;

   public ParameterList() {
   }

   public ParameterList(String var1) throws ParseException {
      HeaderTokenizer var2 = new HeaderTokenizer(var1, "()<>@,;:\\\"\t []/?=");

      while(true) {
         HeaderTokenizer.Token var3 = var2.next();
         int var4 = var3.getType();
         if (var4 == -4) {
            return;
         }

         if ((char)var4 != ';') {
            throw new ParseException("Expected ';', got \"" + var3.getValue() + "\"");
         }

         var3 = var2.next();
         if (var3.getType() == -4) {
            return;
         }

         if (var3.getType() != -1) {
            throw new ParseException("Expected parameter name, got \"" + var3.getValue() + "\"");
         }

         String var5 = var3.getValue().toLowerCase();
         var3 = var2.next();
         if ((char)var3.getType() != '=') {
            throw new ParseException("Expected '=', got \"" + var3.getValue() + "\"");
         }

         var3 = var2.next();
         var4 = var3.getType();
         if (var4 != -1 && var4 != -2) {
            throw new ParseException("Expected parameter value, got \"" + var3.getValue() + "\"");
         }

         String var6 = var3.getValue();
         if (decodeParameters && var5.endsWith("*")) {
            var5 = var5.substring(0, var5.length() - 1);
            this.list.put(var5, this.decodeValue(var6));
         } else {
            this.list.put(var5, var6);
         }
      }
   }

   public int size() {
      return this.list.size();
   }

   public String get(String var1) {
      Object var3 = this.list.get(var1.trim().toLowerCase());
      String var2;
      if (var3 instanceof ParameterList.Value) {
         var2 = ((ParameterList.Value)var3).value;
      } else {
         var2 = (String)var3;
      }

      return var2;
   }

   public void set(String var1, String var2) {
      this.list.put(var1.trim().toLowerCase(), var2);
   }

   public void set(String var1, String var2, String var3) {
      if (encodeParameters) {
         ParameterList.Value var4 = this.encodeValue(var2, var3);
         if (var4 != null) {
            this.list.put(var1.trim().toLowerCase(), var4);
         } else {
            this.set(var1, var2);
         }
      } else {
         this.set(var1, var2);
      }

   }

   public void remove(String var1) {
      this.list.remove(var1.trim().toLowerCase());
   }

   public Enumeration getNames() {
      return new ParameterList.ParamEnum(this.list.keySet().iterator());
   }

   public String toString() {
      return this.toString(0);
   }

   public String toString(int var1) {
      StringBuffer var2 = new StringBuffer();
      Iterator var3 = this.list.keySet().iterator();

      while(var3.hasNext()) {
         String var4 = (String)var3.next();
         Object var6 = this.list.get(var4);
         String var5;
         if (var6 instanceof ParameterList.Value) {
            var5 = ((ParameterList.Value)var6).encodedValue;
            var4 = var4 + '*';
         } else {
            var5 = (String)var6;
         }

         var5 = this.quote(var5);
         var2.append("; ");
         var1 += 2;
         int var7 = var4.length() + var5.length() + 1;
         if (var1 + var7 > 76) {
            var2.append("\r\n\t");
            var1 = 8;
         }

         var2.append(var4).append('=');
         var1 += var4.length() + 1;
         if (var1 + var5.length() > 76) {
            String var8 = MimeUtility.fold(var1, var5);
            var2.append(var8);
            int var9 = var8.lastIndexOf(10);
            if (var9 >= 0) {
               var1 += var8.length() - var9 - 1;
            } else {
               var1 += var8.length();
            }
         } else {
            var2.append(var5);
            var1 += var5.length();
         }
      }

      return var2.toString();
   }

   private String quote(String var1) {
      return MimeUtility.quote(var1, "()<>@,;:\\\"\t []/?=");
   }

   private ParameterList.Value encodeValue(String var1, String var2) {
      if (MimeUtility.checkAscii(var1) == 1) {
         return null;
      } else {
         byte[] var3;
         try {
            var3 = var1.getBytes(MimeUtility.javaCharset(var2));
         } catch (UnsupportedEncodingException var7) {
            return null;
         }

         StringBuffer var4 = new StringBuffer(var3.length + var2.length() + 2);
         var4.append(var2).append("''");

         for(int var5 = 0; var5 < var3.length; ++var5) {
            char var6 = (char)(var3[var5] & 255);
            if (var6 > ' ' && var6 < 127 && var6 != '*' && var6 != '\'' && var6 != '%' && "()<>@,;:\\\"\t []/?=".indexOf(var6) < 0) {
               var4.append(var6);
            } else {
               var4.append('%').append(hex[var6 >> 4]).append(hex[var6 & 15]);
            }
         }

         ParameterList.Value var8 = new ParameterList.Value();
         var8.value = var1;
         var8.encodedValue = var4.toString();
         return var8;
      }
   }

   private ParameterList.Value decodeValue(String var1) throws ParseException {
      ParameterList.Value var2 = new ParameterList.Value();
      var2.encodedValue = var1;
      var2.value = var1;

      try {
         int var3 = var1.indexOf(39);
         if (var3 <= 0) {
            if (decodeParametersStrict) {
               throw new ParseException("Missing charset in encoded value: " + var1);
            }

            return var2;
         }

         String var4 = var1.substring(0, var3);
         int var5 = var1.indexOf(39, var3 + 1);
         if (var5 < 0) {
            if (decodeParametersStrict) {
               throw new ParseException("Missing language in encoded value: " + var1);
            }

            return var2;
         }

         var1.substring(var3 + 1, var5);
         var1 = var1.substring(var5 + 1);
         byte[] var7 = new byte[var1.length()];
         var3 = 0;

         int var8;
         for(var8 = 0; var3 < var1.length(); ++var3) {
            char var9 = var1.charAt(var3);
            if (var9 == '%') {
               String var10 = var1.substring(var3 + 1, var3 + 3);
               var9 = (char)Integer.parseInt(var10, 16);
               var3 += 2;
            }

            var7[var8++] = (byte)var9;
         }

         var2.value = new String(var7, 0, var8, MimeUtility.javaCharset(var4));
      } catch (NumberFormatException var11) {
         if (decodeParametersStrict) {
            throw new ParseException(var11.toString());
         }
      } catch (UnsupportedEncodingException var12) {
         if (decodeParametersStrict) {
            throw new ParseException(var12.toString());
         }
      } catch (StringIndexOutOfBoundsException var13) {
         if (decodeParametersStrict) {
            throw new ParseException(var13.toString());
         }
      }

      return var2;
   }

   static {
      try {
         String var0 = System.getProperty("mail.mime.encodeparameters");
         encodeParameters = var0 != null && var0.equalsIgnoreCase("true");
         var0 = System.getProperty("mail.mime.decodeparameters");
         decodeParameters = var0 != null && var0.equalsIgnoreCase("true");
         var0 = System.getProperty("mail.mime.decodeparameters.strict");
         decodeParametersStrict = var0 != null && var0.equalsIgnoreCase("true");
      } catch (SecurityException var1) {
      }

      hex = new char[]{'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};
   }

   private static class ParamEnum implements Enumeration {
      private Iterator it;

      ParamEnum(Iterator var1) {
         this.it = var1;
      }

      public boolean hasMoreElements() {
         return this.it.hasNext();
      }

      public Object nextElement() {
         return this.it.next();
      }
   }

   private static class Value {
      String value;
      String encodedValue;

      private Value() {
      }

      // $FF: synthetic method
      Value(Object var1) {
         this();
      }
   }
}
