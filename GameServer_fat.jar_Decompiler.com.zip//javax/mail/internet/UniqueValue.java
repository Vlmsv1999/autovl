package javax.mail.internet;

import javax.mail.Session;

class UniqueValue {
   private static int part = 0;
   private static int id = 0;

   public static String getUniqueBoundaryValue() {
      StringBuffer var0 = new StringBuffer();
      var0.append("----=_Part_").append(part++).append("_").append(var0.hashCode()).append('.').append(System.currentTimeMillis());
      return var0.toString();
   }

   public static String getUniqueMessageIDValue(Session var0) {
      String var1 = null;
      InternetAddress var2 = InternetAddress.getLocalAddress(var0);
      if (var2 != null) {
         var1 = var2.getAddress();
      } else {
         var1 = "javamailuser@localhost";
      }

      StringBuffer var3 = new StringBuffer();
      var3.append(var3.hashCode()).append('.').append(id++).append(System.currentTimeMillis()).append('.').append("JavaMail.").append(var1);
      return var3.toString();
   }
}
