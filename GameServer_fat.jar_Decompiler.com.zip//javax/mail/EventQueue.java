package javax.mail;

import java.util.Vector;
import javax.mail.event.MailEvent;

class EventQueue implements Runnable {
   private EventQueue.QueueElement head = null;
   private EventQueue.QueueElement tail = null;
   private Thread qThread = new Thread(this, "JavaMail-EventQueue");

   public EventQueue() {
      this.qThread.setDaemon(true);
      this.qThread.start();
   }

   public synchronized void enqueue(MailEvent var1, Vector var2) {
      EventQueue.QueueElement var3 = new EventQueue.QueueElement(var1, var2);
      if (this.head == null) {
         this.head = var3;
         this.tail = var3;
      } else {
         var3.next = this.head;
         this.head.prev = var3;
         this.head = var3;
      }

      this.notify();
   }

   private synchronized EventQueue.QueueElement dequeue() throws InterruptedException {
      while(this.tail == null) {
         this.wait();
      }

      EventQueue.QueueElement var1 = this.tail;
      this.tail = var1.prev;
      if (this.tail == null) {
         this.head = null;
      } else {
         this.tail.next = null;
      }

      var1.prev = var1.next = null;
      return var1;
   }

   public void run() {
      label33:
      while(true) {
         try {
            EventQueue.QueueElement var1;
            if ((var1 = this.dequeue()) != null) {
               MailEvent var2 = var1.event;
               Vector var3 = var1.vector;
               int var4 = 0;

               while(true) {
                  if (var4 >= var3.size()) {
                     var1 = null;
                     var2 = null;
                     var3 = null;
                     continue label33;
                  }

                  try {
                     var2.dispatch(var3.elementAt(var4));
                  } catch (Throwable var6) {
                     if (var6 instanceof InterruptedException) {
                        break;
                     }
                  }

                  ++var4;
               }
            }
         } catch (InterruptedException var7) {
         }

         return;
      }
   }

   void stop() {
      if (this.qThread != null) {
         this.qThread.interrupt();
         this.qThread = null;
      }

   }

   class QueueElement {
      EventQueue.QueueElement next = null;
      EventQueue.QueueElement prev = null;
      MailEvent event = null;
      Vector vector = null;

      QueueElement(MailEvent var2, Vector var3) {
         this.event = var2;
         this.vector = var3;
      }
   }
}
