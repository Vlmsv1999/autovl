package javax.mail;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import javax.mail.event.TransportEvent;
import javax.mail.event.TransportListener;

public abstract class Transport extends Service {
   private Vector transportListeners = null;

   public Transport(Session var1, URLName var2) {
      super(var1, var2);
   }

   public static void send(Message var0) throws MessagingException {
      var0.saveChanges();
      send0(var0, var0.getAllRecipients());
   }

   public static void send(Message var0, Address[] var1) throws MessagingException {
      var0.saveChanges();
      send0(var0, var1);
   }

   private static void send0(Message var0, Address[] var1) throws MessagingException {
      if (var1 != null && var1.length != 0) {
         Hashtable var2 = new Hashtable();
         Vector var3 = new Vector();
         Vector var4 = new Vector();
         Vector var5 = new Vector();

         for(int var6 = 0; var6 < var1.length; ++var6) {
            Vector var7;
            if (var2.containsKey(var1[var6].getType())) {
               var7 = (Vector)var2.get(var1[var6].getType());
               var7.addElement(var1[var6]);
            } else {
               var7 = new Vector();
               var7.addElement(var1[var6]);
               var2.put(var1[var6].getType(), var7);
            }
         }

         int var35 = var2.size();
         if (var35 == 0) {
            throw new SendFailedException("No recipient addresses");
         } else {
            Session var8 = var0.session != null ? var0.session : Session.getDefaultInstance(System.getProperties(), (Authenticator)null);
            Transport var9;
            if (var35 == 1) {
               var9 = var8.getTransport(var1[0]);

               try {
                  var9.connect();
                  var9.sendMessage(var0, var1);
               } finally {
                  var9.close();
               }

            } else {
               Object var10 = null;
               boolean var11 = false;
               Enumeration var12 = var2.elements();

               while(true) {
                  Address[] var14;
                  while(var12.hasMoreElements()) {
                     Vector var13 = (Vector)var12.nextElement();
                     var14 = new Address[var13.size()];
                     var13.copyInto(var14);
                     if ((var9 = var8.getTransport(var14[0])) == null) {
                        for(int var15 = 0; var15 < var14.length; ++var15) {
                           var3.addElement(var14[var15]);
                        }
                     } else {
                        try {
                           var9.connect();
                           var9.sendMessage(var0, var14);
                        } catch (SendFailedException var32) {
                           var11 = true;
                           if (var10 == null) {
                              var10 = var32;
                           } else {
                              ((MessagingException)var10).setNextException(var32);
                           }

                           Address[] var16 = var32.getInvalidAddresses();
                           if (var16 != null) {
                              for(int var17 = 0; var17 < var16.length; ++var17) {
                                 var3.addElement(var16[var17]);
                              }
                           }

                           var16 = var32.getValidSentAddresses();
                           if (var16 != null) {
                              for(int var18 = 0; var18 < var16.length; ++var18) {
                                 var4.addElement(var16[var18]);
                              }
                           }

                           Address[] var19 = var32.getValidUnsentAddresses();
                           if (var19 != null) {
                              for(int var20 = 0; var20 < var19.length; ++var20) {
                                 var5.addElement(var19[var20]);
                              }
                           }
                        } catch (MessagingException var33) {
                           var11 = true;
                           if (var10 == null) {
                              var10 = var33;
                           } else {
                              ((MessagingException)var10).setNextException(var33);
                           }
                        } finally {
                           var9.close();
                        }
                     }
                  }

                  if (!var11 && var3.size() == 0 && var5.size() == 0) {
                     return;
                  }

                  Address[] var36 = null;
                  var14 = null;
                  Address[] var37 = null;
                  if (var4.size() > 0) {
                     var36 = new Address[var4.size()];
                     var4.copyInto(var36);
                  }

                  if (var5.size() > 0) {
                     var14 = new Address[var5.size()];
                     var5.copyInto(var14);
                  }

                  if (var3.size() > 0) {
                     var37 = new Address[var3.size()];
                     var3.copyInto(var37);
                  }

                  throw new SendFailedException("Sending failed", (Exception)var10, var36, var14, var37);
               }
            }
         }
      } else {
         throw new SendFailedException("No recipient addresses");
      }
   }

   public abstract void sendMessage(Message var1, Address[] var2) throws MessagingException;

   public synchronized void addTransportListener(TransportListener var1) {
      if (this.transportListeners == null) {
         this.transportListeners = new Vector();
      }

      this.transportListeners.addElement(var1);
   }

   public synchronized void removeTransportListener(TransportListener var1) {
      if (this.transportListeners != null) {
         this.transportListeners.removeElement(var1);
      }

   }

   protected void notifyTransportListeners(int var1, Address[] var2, Address[] var3, Address[] var4, Message var5) {
      if (this.transportListeners != null) {
         TransportEvent var6 = new TransportEvent(this, var1, var2, var3, var4, var5);
         this.queueEvent(var6, this.transportListeners);
      }
   }
}
